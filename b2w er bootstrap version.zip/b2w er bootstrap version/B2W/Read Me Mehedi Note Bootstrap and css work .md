Google font er moto r o acta font add korar site er nam holo Adobe font.
er url holo:
https://fonts.adobe.com/


..................................................................................


Adobe font er acta nice font er nam holo:
Proxima Nova


..................................................................................


Clearfix class ta ki kaje lage ta jante hobe.
button ba onek jaiga te role babohar kora hoy. ta ki kaje lage?


..................................................................................



squere acta soto image k puro page er background hisebe dite hole css er body te ai code likte hobe.
background: url(../img/tile.jpg) top left repeat;


..................................................................................



h1, h2, h3, h4, h5, h6 {
    -webkit-font-smoothing : antialiased;
    text-rendering: optimizeLegibility;
}


..................................................................................



#hero .price-timeline .price {
    margin: 0 2% 0 0;
    vertical-align: top;
}



..................................................................................


#hero .price-timeline .price span {
    background-color: #101010;
    display: block;
    height: 70px;
    width: 70px;
    text-align: center;
    line-height: 70px;
    font-weight: bold;
    font-size: 24px;
    -webkit-border-radius: 100%;
    -moz-border-radius: 100%;
    border-radius: 100%;
    position: absolute;

    bottom: -35px;
    left: 50%;
    margin-left: -35px;
}
uporer code e left: 50% dara span k left e 50% sorano hoyese but se jokhon serese
toknon hiseb korese take just tar start point theke. moddo theke noy.
tai er width jehetu 70px tai pore abar 70px er half 35px k negative kora hoyese.



..................................................................................



background e kivabe parallax scrolling doya jai ta nicher link theke sekha jai.
tobe jquery function e ac ta line missing ase. so commert e seta thik kore doya ase.

https://code.tutsplus.com/tutorials/a-simple-parallax-scrolling-technique--net-27641
ba search dite hobe nicher text likhe:
A Simple Parallax Scrolling Technique



..................................................................................



<div class="col-sm-2">
    <i class="ci ci-computer"></i>
    <h4>Lifetime access to 80+ courses</h4>
</div> <!--class: col-sm-2-->

<div class="col-sm-2">
    <i class="ci ci-watch"></i>
    <h4>10+ Hours HD video content</h4>
</div> <!--class: col-sm-2-->

<div class="col-sm-2">
    <i class="ci ci-calender"></i>
    <h4>30 days money back guarantee</h4>
</div> <!--class: col-sm-2-->

<div class="col-sm-2">
    <i class="ci ci-community"></i>
    <h4>Access to community of like middle student</h4>
</div> <!--class: col-sm-2-->

<div class="col-sm-2">
    <i class="ci ci-instructor"></i>
    <h4>Director Access to the Instructore</h4>
</div> <!--class: col-sm-2-->

<div class="col-sm-2">
    <i class="ci ci-device"></i>
    <h4>Accessable content to your mobile device</h4>
</div> <!--class: col-sm-2-->

......................

i.ci {
    display: inline-block;
    height: 40px;
    width: 40px;
    background: url('../img/icon-sprite.png') no-repeat;
}
.ci.ci-computer         {background-position: 0 0;}
.ci.ci-watch         {background-position: -40px 0;}
.ci.ci-calender         {background-position: -80px 0;}
.ci.ci-community         {background-position: -120px 0;}
.ci.ci-instructor         {background-position: -160px 0;}
.ci.ci-device         {background-position: -200px 0;}


uporer code dara acta image e 6 ta icon silo and oi acta image k 
e load kore 6 ta div e vinno vinno vabe acta acta kore 6 ta image
k dekhano hoyese.




...................................

background: url(../img/brad-elvis.png) 0 0 no-repeat;
background: url(../img/brad-elvis.png) 90% -10px no-repeat;

uporer code er 1st line e bujano hoyese j kono image left e 0 and top e 0 % kore jaiga faka rakhbe.
but nicher code e background image left theke 90% dane sore jabe and top theke 10px upore chole jabe.


...................................

background: url(../img/tile.jpg) top left repeat;

uporer line data acta soro image baboahar kore full body k background e cover kora jai.
...................................

.badge.social {
	background-color: #ccc;
	font-size: 24px;
	height: 50px;
    width: 50px;
    line-height: 50px;
	text-align: center;
	margin: 0 5px 20px 0;
	padding: 0px;
	-webkit-border-radius: 50%;
	-moz-border-radius: 50%;
	border-radius: 50%;
}

uporer code data font-wasome k center e ana hoyese gol cercle kore.
e khetre obosso e height, width and line-height ek hote hobe.
padding 0 hote hobe.





...................................

#instructor .num {
    display: table;
}

#instructor .num .num-content {
    display: table-cell;
    vertical-align: middle;
}

upore 1st code e parent k display - table kore, 2nd code e child k display - table-cell kora hoyese.
ebar vertical-align - middle korar .num-content er sob kisu k vertical middle kora hoyese.


...................................

<section id="singup" data-type="background" data-speed="4">
    
</section>

section er vitorer data-type and data-speed parallax background er jonno proyojon

...................................

background: url(../img/hipster-stuff.jpg) center center repeat fixed;

jante hobe.

...................................

footer a:link,
footer a:visited {
    color: #fff;
}

link er color chang korar sohoj poddoti.

...................................

.row + .row {
    margin-top: 20px;
}

uporer code dara bujano hoyese j jodi nono jaigate row er por por e abar 1 ba ekhadik row thake
tobe 1st row bate onno row gulor margin-top : 20px hoye jao. row gulo por por hote hobe actar 
under e onno ta thakle cholbe na. onke ta "1st child bade onno child gulo select korar moto"

...................................

.feature-image {
    display: table;
    width: 100%;
}

.feature-image h1 {
    display: table-cell;
    vertical-align: middle;
    text-align: center;
    color: #fff;
}


j kono kisu k vertical and horizentally middle anar jonno