-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 05, 2019 at 05:28 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `b2w`
--

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_commentmeta`
--

CREATE TABLE `bs2wp_commentmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_comments`
--

CREATE TABLE `bs2wp_comments` (
  `comment_ID` bigint(20) UNSIGNED NOT NULL,
  `comment_post_ID` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bs2wp_comments`
--

INSERT INTO `bs2wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'A WordPress Commenter', 'wapuu@wordpress.example', 'https://wordpress.org/', '', '2019-03-20 17:21:32', '2019-03-20 17:21:32', 'Hi, this is a comment.\nTo get started with moderating, editing, and deleting comments, please visit the Comments screen in the dashboard.\nCommenter avatars come from <a href=\"https://gravatar.com\">Gravatar</a>.', 0, '1', '', '', 0, 0),
(2, 1, 'admin', 'mehedi00014@gmail.com', '', '::1', '2019-04-07 18:31:10', '2019-04-07 18:31:10', 'Assalamu Alaikum.\r\nThis is Mehedi Hassan\r\nHope its work fine.........................', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0', '', 0, 1),
(3, 1, 'Md. Mehedi Hassan', 'mehedi00014@gmail.com', '', '::1', '2019-04-07 18:38:50', '2019-04-07 18:38:50', 'Walaikum Assalam.\r\nNice', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0', '', 2, 1),
(4, 1, 'Md. Mehedi Hassan', 'mehedi00014@gmail.com', '', '::1', '2019-04-07 18:39:33', '2019-04-07 18:39:33', 'Thank You for your nice comment,,,,,,,,,,,,,,,,,,', 0, '1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_links`
--

CREATE TABLE `bs2wp_links` (
  `link_id` bigint(20) UNSIGNED NOT NULL,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) UNSIGNED NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_options`
--

CREATE TABLE `bs2wp_options` (
  `option_id` bigint(20) UNSIGNED NOT NULL,
  `option_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bs2wp_options`
--

INSERT INTO `bs2wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost/b2w', 'yes'),
(2, 'home', 'http://localhost/b2w', 'yes'),
(3, 'blogname', 'Bootstrap 2 Wordpress', 'yes'),
(4, 'blogdescription', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iste deserunt veritatis velit sint voluptate possimus eveniet eligendi at exercitationem nostrum!', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'mehedi00014@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/%category%/%year%/%monthnum%/', 'yes'),
(29, 'rewrite_rules', 'a:212:{s:11:\"^wp-json/?$\";s:22:\"index.php?rest_route=/\";s:14:\"^wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:21:\"^index.php/wp-json/?$\";s:22:\"index.php?rest_route=/\";s:24:\"^index.php/wp-json/(.*)?\";s:33:\"index.php?rest_route=/$matches[1]\";s:47:\"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:42:\"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:52:\"index.php?category_name=$matches[1]&feed=$matches[2]\";s:23:\"category/(.+?)/embed/?$\";s:46:\"index.php?category_name=$matches[1]&embed=true\";s:35:\"category/(.+?)/page/?([0-9]{1,})/?$\";s:53:\"index.php?category_name=$matches[1]&paged=$matches[2]\";s:17:\"category/(.+?)/?$\";s:35:\"index.php?category_name=$matches[1]\";s:44:\"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:39:\"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?tag=$matches[1]&feed=$matches[2]\";s:20:\"tag/([^/]+)/embed/?$\";s:36:\"index.php?tag=$matches[1]&embed=true\";s:32:\"tag/([^/]+)/page/?([0-9]{1,})/?$\";s:43:\"index.php?tag=$matches[1]&paged=$matches[2]\";s:14:\"tag/([^/]+)/?$\";s:25:\"index.php?tag=$matches[1]\";s:45:\"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:40:\"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?post_format=$matches[1]&feed=$matches[2]\";s:21:\"type/([^/]+)/embed/?$\";s:44:\"index.php?post_format=$matches[1]&embed=true\";s:33:\"type/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?post_format=$matches[1]&paged=$matches[2]\";s:15:\"type/([^/]+)/?$\";s:33:\"index.php?post_format=$matches[1]\";s:43:\"course_features/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:53:\"course_features/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:73:\"course_features/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:68:\"course_features/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:68:\"course_features/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:49:\"course_features/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:32:\"course_features/([^/]+)/embed/?$\";s:48:\"index.php?course_features=$matches[1]&embed=true\";s:36:\"course_features/([^/]+)/trackback/?$\";s:42:\"index.php?course_features=$matches[1]&tb=1\";s:44:\"course_features/([^/]+)/page/?([0-9]{1,})/?$\";s:55:\"index.php?course_features=$matches[1]&paged=$matches[2]\";s:51:\"course_features/([^/]+)/comment-page-([0-9]{1,})/?$\";s:55:\"index.php?course_features=$matches[1]&cpage=$matches[2]\";s:40:\"course_features/([^/]+)(?:/([0-9]+))?/?$\";s:54:\"index.php?course_features=$matches[1]&page=$matches[2]\";s:32:\"course_features/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:42:\"course_features/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:62:\"course_features/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"course_features/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:57:\"course_features/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:38:\"course_features/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:44:\"project_features/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:54:\"project_features/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:74:\"project_features/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:69:\"project_features/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:69:\"project_features/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:50:\"project_features/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:33:\"project_features/([^/]+)/embed/?$\";s:49:\"index.php?project_features=$matches[1]&embed=true\";s:37:\"project_features/([^/]+)/trackback/?$\";s:43:\"index.php?project_features=$matches[1]&tb=1\";s:45:\"project_features/([^/]+)/page/?([0-9]{1,})/?$\";s:56:\"index.php?project_features=$matches[1]&paged=$matches[2]\";s:52:\"project_features/([^/]+)/comment-page-([0-9]{1,})/?$\";s:56:\"index.php?project_features=$matches[1]&cpage=$matches[2]\";s:41:\"project_features/([^/]+)(?:/([0-9]+))?/?$\";s:55:\"index.php?project_features=$matches[1]&page=$matches[2]\";s:33:\"project_features/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:43:\"project_features/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:63:\"project_features/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"project_features/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:58:\"project_features/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:39:\"project_features/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:39:\"testimonial/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:49:\"testimonial/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:69:\"testimonial/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"testimonial/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:64:\"testimonial/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:45:\"testimonial/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:28:\"testimonial/([^/]+)/embed/?$\";s:44:\"index.php?testimonial=$matches[1]&embed=true\";s:32:\"testimonial/([^/]+)/trackback/?$\";s:38:\"index.php?testimonial=$matches[1]&tb=1\";s:40:\"testimonial/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?testimonial=$matches[1]&paged=$matches[2]\";s:47:\"testimonial/([^/]+)/comment-page-([0-9]{1,})/?$\";s:51:\"index.php?testimonial=$matches[1]&cpage=$matches[2]\";s:36:\"testimonial/([^/]+)(?:/([0-9]+))?/?$\";s:50:\"index.php?testimonial=$matches[1]&page=$matches[2]\";s:28:\"testimonial/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:38:\"testimonial/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:58:\"testimonial/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"testimonial/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:53:\"testimonial/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:34:\"testimonial/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:36:\"resource/[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:46:\"resource/[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:66:\"resource/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"resource/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:61:\"resource/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:42:\"resource/[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:25:\"resource/([^/]+)/embed/?$\";s:41:\"index.php?resource=$matches[1]&embed=true\";s:29:\"resource/([^/]+)/trackback/?$\";s:35:\"index.php?resource=$matches[1]&tb=1\";s:37:\"resource/([^/]+)/page/?([0-9]{1,})/?$\";s:48:\"index.php?resource=$matches[1]&paged=$matches[2]\";s:44:\"resource/([^/]+)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?resource=$matches[1]&cpage=$matches[2]\";s:33:\"resource/([^/]+)(?:/([0-9]+))?/?$\";s:47:\"index.php?resource=$matches[1]&page=$matches[2]\";s:25:\"resource/[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:35:\"resource/[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:55:\"resource/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"resource/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:50:\"resource/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:31:\"resource/[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:48:\".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$\";s:18:\"index.php?feed=old\";s:20:\".*wp-app\\.php(/.*)?$\";s:19:\"index.php?error=403\";s:18:\".*wp-register.php$\";s:23:\"index.php?register=true\";s:32:\"feed/(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:27:\"(feed|rdf|rss|rss2|atom)/?$\";s:27:\"index.php?&feed=$matches[1]\";s:8:\"embed/?$\";s:21:\"index.php?&embed=true\";s:20:\"page/?([0-9]{1,})/?$\";s:28:\"index.php?&paged=$matches[1]\";s:27:\"comment-page-([0-9]{1,})/?$\";s:39:\"index.php?&page_id=11&cpage=$matches[1]\";s:41:\"comments/feed/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:36:\"comments/(feed|rdf|rss|rss2|atom)/?$\";s:42:\"index.php?&feed=$matches[1]&withcomments=1\";s:17:\"comments/embed/?$\";s:21:\"index.php?&embed=true\";s:44:\"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:39:\"search/(.+)/(feed|rdf|rss|rss2|atom)/?$\";s:40:\"index.php?s=$matches[1]&feed=$matches[2]\";s:20:\"search/(.+)/embed/?$\";s:34:\"index.php?s=$matches[1]&embed=true\";s:32:\"search/(.+)/page/?([0-9]{1,})/?$\";s:41:\"index.php?s=$matches[1]&paged=$matches[2]\";s:14:\"search/(.+)/?$\";s:23:\"index.php?s=$matches[1]\";s:47:\"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:42:\"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:50:\"index.php?author_name=$matches[1]&feed=$matches[2]\";s:23:\"author/([^/]+)/embed/?$\";s:44:\"index.php?author_name=$matches[1]&embed=true\";s:35:\"author/([^/]+)/page/?([0-9]{1,})/?$\";s:51:\"index.php?author_name=$matches[1]&paged=$matches[2]\";s:17:\"author/([^/]+)/?$\";s:33:\"index.php?author_name=$matches[1]\";s:69:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:64:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:80:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]\";s:45:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$\";s:74:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true\";s:57:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:81:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]\";s:39:\"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$\";s:63:\"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]\";s:56:\"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:51:\"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:64:\"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]\";s:32:\"([0-9]{4})/([0-9]{1,2})/embed/?$\";s:58:\"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true\";s:44:\"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:65:\"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]\";s:26:\"([0-9]{4})/([0-9]{1,2})/?$\";s:47:\"index.php?year=$matches[1]&monthnum=$matches[2]\";s:43:\"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:38:\"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?year=$matches[1]&feed=$matches[2]\";s:19:\"([0-9]{4})/embed/?$\";s:37:\"index.php?year=$matches[1]&embed=true\";s:31:\"([0-9]{4})/page/?([0-9]{1,})/?$\";s:44:\"index.php?year=$matches[1]&paged=$matches[2]\";s:13:\"([0-9]{4})/?$\";s:26:\"index.php?year=$matches[1]\";s:27:\".?.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\".?.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\".?.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"(.?.+?)/embed/?$\";s:41:\"index.php?pagename=$matches[1]&embed=true\";s:20:\"(.?.+?)/trackback/?$\";s:35:\"index.php?pagename=$matches[1]&tb=1\";s:40:\"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:35:\"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:47:\"index.php?pagename=$matches[1]&feed=$matches[2]\";s:28:\"(.?.+?)/page/?([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&paged=$matches[2]\";s:35:\"(.?.+?)/comment-page-([0-9]{1,})/?$\";s:48:\"index.php?pagename=$matches[1]&cpage=$matches[2]\";s:24:\"(.?.+?)(?:/([0-9]+))?/?$\";s:47:\"index.php?pagename=$matches[1]&page=$matches[2]\";s:51:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:61:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:81:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:76:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:76:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:57:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:46:\"([^/]+)/(.+?)/([0-9]{4})/([0-9]{1,2})/embed/?$\";s:101:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&monthnum=$matches[4]&embed=true\";s:50:\"([^/]+)/(.+?)/([0-9]{4})/([0-9]{1,2})/trackback/?$\";s:95:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&monthnum=$matches[4]&tb=1\";s:70:\"([^/]+)/(.+?)/([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:107:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&monthnum=$matches[4]&feed=$matches[5]\";s:65:\"([^/]+)/(.+?)/([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$\";s:107:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&monthnum=$matches[4]&feed=$matches[5]\";s:58:\"([^/]+)/(.+?)/([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$\";s:108:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&monthnum=$matches[4]&paged=$matches[5]\";s:65:\"([^/]+)/(.+?)/([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$\";s:108:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&monthnum=$matches[4]&cpage=$matches[5]\";s:54:\"([^/]+)/(.+?)/([0-9]{4})/([0-9]{1,2})(?:/([0-9]+))?/?$\";s:107:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&monthnum=$matches[4]&page=$matches[5]\";s:40:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:50:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:70:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:46:\"[^/]+/.+?/[0-9]{4}/[0-9]{1,2}/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:40:\"[^/]+/.+?/[0-9]{4}/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:50:\"[^/]+/.+?/[0-9]{4}/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:70:\"[^/]+/.+?/[0-9]{4}/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"[^/]+/.+?/[0-9]{4}/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:65:\"[^/]+/.+?/[0-9]{4}/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:46:\"[^/]+/.+?/[0-9]{4}/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:33:\"([^/]+)/(.+?)/([0-9]{4})/embed/?$\";s:80:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&embed=true\";s:37:\"([^/]+)/(.+?)/([0-9]{4})/trackback/?$\";s:74:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&tb=1\";s:57:\"([^/]+)/(.+?)/([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$\";s:86:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&feed=$matches[4]\";s:52:\"([^/]+)/(.+?)/([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$\";s:86:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&feed=$matches[4]\";s:45:\"([^/]+)/(.+?)/([0-9]{4})/page/?([0-9]{1,})/?$\";s:87:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&paged=$matches[4]\";s:52:\"([^/]+)/(.+?)/([0-9]{4})/comment-page-([0-9]{1,})/?$\";s:87:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&cpage=$matches[4]\";s:41:\"([^/]+)/(.+?)/([0-9]{4})(?:/([0-9]+))?/?$\";s:86:\"index.php?name=$matches[1]&category_name=$matches[2]&year=$matches[3]&page=$matches[4]\";s:29:\"[^/]+/.+?/[0-9]{4}/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:39:\"[^/]+/.+?/[0-9]{4}/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:59:\"[^/]+/.+?/[0-9]{4}/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"[^/]+/.+?/[0-9]{4}/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:54:\"[^/]+/.+?/[0-9]{4}/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:35:\"[^/]+/.+?/[0-9]{4}/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:31:\"[^/]+/.+?/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:41:\"[^/]+/.+?/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:61:\"[^/]+/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"[^/]+/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:56:\"[^/]+/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:37:\"[^/]+/.+?/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:22:\"([^/]+)/(.+?)/embed/?$\";s:63:\"index.php?name=$matches[1]&category_name=$matches[2]&embed=true\";s:26:\"([^/]+)/(.+?)/trackback/?$\";s:57:\"index.php?name=$matches[1]&category_name=$matches[2]&tb=1\";s:46:\"([^/]+)/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?name=$matches[1]&category_name=$matches[2]&feed=$matches[3]\";s:41:\"([^/]+)/(.+?)/(feed|rdf|rss|rss2|atom)/?$\";s:69:\"index.php?name=$matches[1]&category_name=$matches[2]&feed=$matches[3]\";s:34:\"([^/]+)/(.+?)/page/?([0-9]{1,})/?$\";s:70:\"index.php?name=$matches[1]&category_name=$matches[2]&paged=$matches[3]\";s:41:\"([^/]+)/(.+?)/comment-page-([0-9]{1,})/?$\";s:70:\"index.php?name=$matches[1]&category_name=$matches[2]&cpage=$matches[3]\";s:30:\"([^/]+)/(.+?)(?:/([0-9]+))?/?$\";s:69:\"index.php?name=$matches[1]&category_name=$matches[2]&page=$matches[3]\";s:20:\"[^/]+/.+?/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:30:\"[^/]+/.+?/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:50:\"[^/]+/.+?/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\"[^/]+/.+?/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:45:\"[^/]+/.+?/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:26:\"[^/]+/.+?/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:27:\"[^/]+/attachment/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:37:\"[^/]+/attachment/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:57:\"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:52:\"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:33:\"[^/]+/attachment/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";s:16:\"([^/]+)/embed/?$\";s:37:\"index.php?name=$matches[1]&embed=true\";s:20:\"([^/]+)/trackback/?$\";s:31:\"index.php?name=$matches[1]&tb=1\";s:40:\"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:35:\"([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:43:\"index.php?name=$matches[1]&feed=$matches[2]\";s:28:\"([^/]+)/page/?([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&paged=$matches[2]\";s:35:\"([^/]+)/comment-page-([0-9]{1,})/?$\";s:44:\"index.php?name=$matches[1]&cpage=$matches[2]\";s:24:\"([^/]+)(?:/([0-9]+))?/?$\";s:43:\"index.php?name=$matches[1]&page=$matches[2]\";s:16:\"[^/]+/([^/]+)/?$\";s:32:\"index.php?attachment=$matches[1]\";s:26:\"[^/]+/([^/]+)/trackback/?$\";s:37:\"index.php?attachment=$matches[1]&tb=1\";s:46:\"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$\";s:49:\"index.php?attachment=$matches[1]&feed=$matches[2]\";s:41:\"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$\";s:50:\"index.php?attachment=$matches[1]&cpage=$matches[2]\";s:22:\"[^/]+/([^/]+)/embed/?$\";s:43:\"index.php?attachment=$matches[1]&embed=true\";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:4:{i:0;s:30:\"advanced-custom-fields/acf.php\";i:1;s:36:\"contact-form-7/wp-contact-form-7.php\";i:2;s:43:\"custom-post-type-ui/custom-post-type-ui.php\";i:3;s:67:\"what-template-file-am-i-viewing/what-template-file-am-i-viewing.php\";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'bootstrap2wordpress', 'yes'),
(41, 'stylesheet', 'bootstrap2wordpress-child', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '38590', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:\"title\";s:0:\"\";s:5:\"count\";i:0;s:12:\"hierarchical\";i:0;s:8:\"dropdown\";i:0;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(79, 'widget_text', 'a:4:{i:1;a:0:{}i:4;a:4:{s:5:\"title\";s:18:\"Join our mail list\";s:4:\"text\";s:244:\"<p>Keep up to date with our letest news, and we will <strong>sent you something specisl as a thank you!</strong></p>\r\n\r\n<button class=\"btn btn-success btn-lg btn-block\" data-toggle=\"modal\" data-target=\"#myModal\">Click here to Subscribe</button>\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}s:12:\"_multiwidget\";i:1;i:6;a:4:{s:5:\"title\";s:28:\"About Bootstrap to Wordpress\";s:4:\"text\";s:156:\"Lorem ipsum dolor sit amet consectetur adipisicing elit. Cum voluptate cupiditate odio quas asperiores vel quaerat reprehenderit provident minus voluptatum.\";s:6:\"filter\";b:1;s:6:\"visual\";b:1;}}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:\"_multiwidget\";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '140', 'yes'),
(84, 'page_on_front', '11', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'wp_page_for_privacy_policy', '3', 'yes'),
(92, 'show_comments_cookies_opt_in', '0', 'yes'),
(93, 'initial_db_version', '38590', 'yes'),
(94, 'bs2wp_user_roles', 'a:5:{s:13:\"administrator\";a:2:{s:4:\"name\";s:13:\"Administrator\";s:12:\"capabilities\";a:61:{s:13:\"switch_themes\";b:1;s:11:\"edit_themes\";b:1;s:16:\"activate_plugins\";b:1;s:12:\"edit_plugins\";b:1;s:10:\"edit_users\";b:1;s:10:\"edit_files\";b:1;s:14:\"manage_options\";b:1;s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:6:\"import\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:8:\"level_10\";b:1;s:7:\"level_9\";b:1;s:7:\"level_8\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;s:12:\"delete_users\";b:1;s:12:\"create_users\";b:1;s:17:\"unfiltered_upload\";b:1;s:14:\"edit_dashboard\";b:1;s:14:\"update_plugins\";b:1;s:14:\"delete_plugins\";b:1;s:15:\"install_plugins\";b:1;s:13:\"update_themes\";b:1;s:14:\"install_themes\";b:1;s:11:\"update_core\";b:1;s:10:\"list_users\";b:1;s:12:\"remove_users\";b:1;s:13:\"promote_users\";b:1;s:18:\"edit_theme_options\";b:1;s:13:\"delete_themes\";b:1;s:6:\"export\";b:1;}}s:6:\"editor\";a:2:{s:4:\"name\";s:6:\"Editor\";s:12:\"capabilities\";a:34:{s:17:\"moderate_comments\";b:1;s:17:\"manage_categories\";b:1;s:12:\"manage_links\";b:1;s:12:\"upload_files\";b:1;s:15:\"unfiltered_html\";b:1;s:10:\"edit_posts\";b:1;s:17:\"edit_others_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:10:\"edit_pages\";b:1;s:4:\"read\";b:1;s:7:\"level_7\";b:1;s:7:\"level_6\";b:1;s:7:\"level_5\";b:1;s:7:\"level_4\";b:1;s:7:\"level_3\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:17:\"edit_others_pages\";b:1;s:20:\"edit_published_pages\";b:1;s:13:\"publish_pages\";b:1;s:12:\"delete_pages\";b:1;s:19:\"delete_others_pages\";b:1;s:22:\"delete_published_pages\";b:1;s:12:\"delete_posts\";b:1;s:19:\"delete_others_posts\";b:1;s:22:\"delete_published_posts\";b:1;s:20:\"delete_private_posts\";b:1;s:18:\"edit_private_posts\";b:1;s:18:\"read_private_posts\";b:1;s:20:\"delete_private_pages\";b:1;s:18:\"edit_private_pages\";b:1;s:18:\"read_private_pages\";b:1;}}s:6:\"author\";a:2:{s:4:\"name\";s:6:\"Author\";s:12:\"capabilities\";a:10:{s:12:\"upload_files\";b:1;s:10:\"edit_posts\";b:1;s:20:\"edit_published_posts\";b:1;s:13:\"publish_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_2\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;s:22:\"delete_published_posts\";b:1;}}s:11:\"contributor\";a:2:{s:4:\"name\";s:11:\"Contributor\";s:12:\"capabilities\";a:5:{s:10:\"edit_posts\";b:1;s:4:\"read\";b:1;s:7:\"level_1\";b:1;s:7:\"level_0\";b:1;s:12:\"delete_posts\";b:1;}}s:10:\"subscriber\";a:2:{s:4:\"name\";s:10:\"Subscriber\";s:12:\"capabilities\";a:2:{s:4:\"read\";b:1;s:7:\"level_0\";b:1;}}}', 'yes'),
(95, 'fresh_site', '0', 'yes'),
(96, 'widget_search', 'a:2:{i:2;a:1:{s:5:\"title\";s:0:\"\";}s:12:\"_multiwidget\";i:1;}', 'yes'),
(97, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:\"title\";s:0:\"\";s:6:\"number\";i:5;}s:12:\"_multiwidget\";i:1;}', 'yes'),
(98, 'widget_recent-comments', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(99, 'widget_archives', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(100, 'widget_meta', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(101, 'sidebars_widgets', 'a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-2\";a:2:{i:0;s:14:\"recent-posts-2\";i:1;s:12:\"categories-2\";}s:9:\"sidebar-1\";a:3:{i:0;s:6:\"text-4\";i:1;s:8:\"search-2\";i:2;s:6:\"text-6\";}s:13:\"array_version\";i:3;}', 'yes'),
(102, 'widget_pages', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(103, 'widget_calendar', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(104, 'widget_media_audio', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(105, 'widget_media_image', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(106, 'widget_media_gallery', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(107, 'widget_media_video', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(108, 'widget_tag_cloud', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(109, 'widget_nav_menu', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(110, 'widget_custom_html', 'a:1:{s:12:\"_multiwidget\";i:1;}', 'yes'),
(111, 'cron', 'a:6:{i:1556994096;a:1:{s:34:\"wp_privacy_delete_old_export_files\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:6:\"hourly\";s:4:\"args\";a:0:{}s:8:\"interval\";i:3600;}}}i:1556997699;a:1:{s:16:\"wp_version_check\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1557033696;a:2:{s:17:\"wp_update_plugins\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}s:16:\"wp_update_themes\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:10:\"twicedaily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:43200;}}}i:1557057583;a:1:{s:30:\"wp_scheduled_auto_draft_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}i:1557077045;a:2:{s:19:\"wp_scheduled_delete\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}s:25:\"delete_expired_transients\";a:1:{s:32:\"40cd750bba9870f18aada2478b24840a\";a:3:{s:8:\"schedule\";s:5:\"daily\";s:4:\"args\";a:0:{}s:8:\"interval\";i:86400;}}}s:7:\"version\";i:2;}', 'yes'),
(112, 'theme_mods_twentyseventeen', 'a:2:{s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1553102651;s:4:\"data\";a:4:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}s:9:\"sidebar-2\";a:0:{}s:9:\"sidebar-3\";a:0:{}}}}', 'yes'),
(116, '_site_transient_update_core', 'O:8:\"stdClass\":4:{s:7:\"updates\";a:3:{i:0;O:8:\"stdClass\":10:{s:8:\"response\";s:7:\"upgrade\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.1.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.1.1\";s:7:\"version\";s:5:\"5.1.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";}i:1;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.1.1.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.1.1-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.1.1-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.1.1\";s:7:\"version\";s:5:\"5.1.1\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}i:2;O:8:\"stdClass\":11:{s:8:\"response\";s:10:\"autoupdate\";s:8:\"download\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.4.zip\";s:6:\"locale\";s:5:\"en_US\";s:8:\"packages\";O:8:\"stdClass\":5:{s:4:\"full\";s:59:\"https://downloads.wordpress.org/release/wordpress-5.0.4.zip\";s:10:\"no_content\";s:70:\"https://downloads.wordpress.org/release/wordpress-5.0.4-no-content.zip\";s:11:\"new_bundled\";s:71:\"https://downloads.wordpress.org/release/wordpress-5.0.4-new-bundled.zip\";s:7:\"partial\";b:0;s:8:\"rollback\";b:0;}s:7:\"current\";s:5:\"5.0.4\";s:7:\"version\";s:5:\"5.0.4\";s:11:\"php_version\";s:5:\"5.2.4\";s:13:\"mysql_version\";s:3:\"5.0\";s:11:\"new_bundled\";s:3:\"5.0\";s:15:\"partial_version\";s:0:\"\";s:9:\"new_files\";s:1:\"1\";}}s:12:\"last_checked\";i:1556993941;s:15:\"version_checked\";s:6:\"4.9.10\";s:12:\"translations\";a:0:{}}', 'no'),
(126, 'can_compress_scripts', '1', 'no'),
(141, 'current_theme', 'Bootstrap to WordPress Child', 'yes'),
(142, 'theme_mods_bootstrap2wordpress', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:0:{}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1553278555;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(143, 'theme_switched', '', 'yes'),
(145, 'theme_mods_bootstrap2wordpress-child', 'a:4:{i:0;b:0;s:18:\"nav_menu_locations\";a:2:{s:6:\"menu-1\";i:2;s:6:\"menu-2\";i:4;}s:18:\"custom_css_post_id\";i:-1;s:16:\"sidebars_widgets\";a:2:{s:4:\"time\";i:1553274036;s:4:\"data\";a:2:{s:19:\"wp_inactive_widgets\";a:0:{}s:9:\"sidebar-1\";a:6:{i:0;s:8:\"search-2\";i:1;s:14:\"recent-posts-2\";i:2;s:17:\"recent-comments-2\";i:3;s:10:\"archives-2\";i:4;s:12:\"categories-2\";i:5;s:6:\"meta-2\";}}}}', 'yes'),
(148, 'recently_activated', 'a:0:{}', 'yes'),
(159, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:\"auto_add\";a:1:{i:0;i:2;}}', 'yes'),
(185, 'WPLANG', '', 'yes'),
(186, 'new_admin_email', 'mehedi00014@gmail.com', 'yes'),
(201, '_site_transient_update_plugins', 'O:8:\"stdClass\":5:{s:12:\"last_checked\";i:1556993946;s:7:\"checked\";a:4:{s:30:\"advanced-custom-fields/acf.php\";s:6:\"5.7.12\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:5:\"5.1.1\";s:43:\"custom-post-type-ui/custom-post-type-ui.php\";s:5:\"1.6.1\";s:67:\"what-template-file-am-i-viewing/what-template-file-am-i-viewing.php\";s:3:\"1.2\";}s:8:\"response\";a:0:{}s:12:\"translations\";a:0:{}s:9:\"no_update\";a:4:{s:30:\"advanced-custom-fields/acf.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:36:\"w.org/plugins/advanced-custom-fields\";s:4:\"slug\";s:22:\"advanced-custom-fields\";s:6:\"plugin\";s:30:\"advanced-custom-fields/acf.php\";s:11:\"new_version\";s:6:\"5.7.12\";s:3:\"url\";s:53:\"https://wordpress.org/plugins/advanced-custom-fields/\";s:7:\"package\";s:72:\"https://downloads.wordpress.org/plugin/advanced-custom-fields.5.7.12.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-256x256.png?rev=1082746\";s:2:\"1x\";s:75:\"https://ps.w.org/advanced-custom-fields/assets/icon-128x128.png?rev=1082746\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:78:\"https://ps.w.org/advanced-custom-fields/assets/banner-1544x500.jpg?rev=1729099\";s:2:\"1x\";s:77:\"https://ps.w.org/advanced-custom-fields/assets/banner-772x250.jpg?rev=1729102\";}s:11:\"banners_rtl\";a:0:{}}s:36:\"contact-form-7/wp-contact-form-7.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:28:\"w.org/plugins/contact-form-7\";s:4:\"slug\";s:14:\"contact-form-7\";s:6:\"plugin\";s:36:\"contact-form-7/wp-contact-form-7.php\";s:11:\"new_version\";s:5:\"5.1.1\";s:3:\"url\";s:45:\"https://wordpress.org/plugins/contact-form-7/\";s:7:\"package\";s:63:\"https://downloads.wordpress.org/plugin/contact-form-7.5.1.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-256x256.png?rev=984007\";s:2:\"1x\";s:66:\"https://ps.w.org/contact-form-7/assets/icon-128x128.png?rev=984007\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:69:\"https://ps.w.org/contact-form-7/assets/banner-1544x500.png?rev=860901\";s:2:\"1x\";s:68:\"https://ps.w.org/contact-form-7/assets/banner-772x250.png?rev=880427\";}s:11:\"banners_rtl\";a:0:{}}s:43:\"custom-post-type-ui/custom-post-type-ui.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:33:\"w.org/plugins/custom-post-type-ui\";s:4:\"slug\";s:19:\"custom-post-type-ui\";s:6:\"plugin\";s:43:\"custom-post-type-ui/custom-post-type-ui.php\";s:11:\"new_version\";s:5:\"1.6.1\";s:3:\"url\";s:50:\"https://wordpress.org/plugins/custom-post-type-ui/\";s:7:\"package\";s:68:\"https://downloads.wordpress.org/plugin/custom-post-type-ui.1.6.1.zip\";s:5:\"icons\";a:2:{s:2:\"2x\";s:72:\"https://ps.w.org/custom-post-type-ui/assets/icon-256x256.png?rev=1069557\";s:2:\"1x\";s:72:\"https://ps.w.org/custom-post-type-ui/assets/icon-128x128.png?rev=1069557\";}s:7:\"banners\";a:2:{s:2:\"2x\";s:75:\"https://ps.w.org/custom-post-type-ui/assets/banner-1544x500.png?rev=1069557\";s:2:\"1x\";s:74:\"https://ps.w.org/custom-post-type-ui/assets/banner-772x250.png?rev=1069557\";}s:11:\"banners_rtl\";a:0:{}}s:67:\"what-template-file-am-i-viewing/what-template-file-am-i-viewing.php\";O:8:\"stdClass\":9:{s:2:\"id\";s:45:\"w.org/plugins/what-template-file-am-i-viewing\";s:4:\"slug\";s:31:\"what-template-file-am-i-viewing\";s:6:\"plugin\";s:67:\"what-template-file-am-i-viewing/what-template-file-am-i-viewing.php\";s:11:\"new_version\";s:3:\"1.2\";s:3:\"url\";s:62:\"https://wordpress.org/plugins/what-template-file-am-i-viewing/\";s:7:\"package\";s:78:\"https://downloads.wordpress.org/plugin/what-template-file-am-i-viewing.1.2.zip\";s:5:\"icons\";a:1:{s:7:\"default\";s:82:\"https://s.w.org/plugins/geopattern-icon/what-template-file-am-i-viewing_9a9488.svg\";}s:7:\"banners\";a:1:{s:2:\"1x\";s:85:\"https://ps.w.org/what-template-file-am-i-viewing/assets/banner-772x250.png?rev=546775\";}s:11:\"banners_rtl\";a:0:{}}}}', 'no'),
(202, 'acf_version', '5.7.12', 'yes'),
(242, 'cptui_new_install', 'false', 'yes');
INSERT INTO `bs2wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(251, 'cptui_post_types', 'a:4:{s:15:\"course_features\";a:29:{s:4:\"name\";s:15:\"course_features\";s:5:\"label\";s:25:\"Home Page Course Features\";s:14:\"singular_label\";s:24:\"Home Page Course Feature\";s:11:\"description\";s:38:\"Only for place the icon and icon title\";s:6:\"public\";s:4:\"true\";s:18:\"publicly_queryable\";s:4:\"true\";s:7:\"show_ui\";s:4:\"true\";s:17:\"show_in_nav_menus\";s:4:\"true\";s:12:\"show_in_rest\";s:4:\"true\";s:9:\"rest_base\";s:0:\"\";s:21:\"rest_controller_class\";s:0:\"\";s:11:\"has_archive\";s:5:\"false\";s:18:\"has_archive_string\";s:0:\"\";s:19:\"exclude_from_search\";s:5:\"false\";s:15:\"capability_type\";s:4:\"post\";s:12:\"hierarchical\";s:5:\"false\";s:7:\"rewrite\";s:4:\"true\";s:12:\"rewrite_slug\";s:0:\"\";s:17:\"rewrite_withfront\";s:4:\"true\";s:9:\"query_var\";s:4:\"true\";s:14:\"query_var_slug\";s:0:\"\";s:13:\"menu_position\";s:0:\"\";s:12:\"show_in_menu\";s:4:\"true\";s:19:\"show_in_menu_string\";s:0:\"\";s:9:\"menu_icon\";s:65:\"http://localhost/b2w/wp-content/uploads/2019/04/icon-features.png\";s:8:\"supports\";a:1:{i:0;s:5:\"title\";}s:10:\"taxonomies\";a:0:{}s:6:\"labels\";a:24:{s:9:\"menu_name\";s:0:\"\";s:9:\"all_items\";s:0:\"\";s:7:\"add_new\";s:0:\"\";s:12:\"add_new_item\";s:0:\"\";s:9:\"edit_item\";s:0:\"\";s:8:\"new_item\";s:0:\"\";s:9:\"view_item\";s:0:\"\";s:10:\"view_items\";s:0:\"\";s:12:\"search_items\";s:0:\"\";s:9:\"not_found\";s:0:\"\";s:18:\"not_found_in_trash\";s:0:\"\";s:17:\"parent_item_colon\";s:0:\"\";s:14:\"featured_image\";s:0:\"\";s:18:\"set_featured_image\";s:0:\"\";s:21:\"remove_featured_image\";s:0:\"\";s:18:\"use_featured_image\";s:0:\"\";s:8:\"archives\";s:0:\"\";s:16:\"insert_into_item\";s:0:\"\";s:21:\"uploaded_to_this_item\";s:0:\"\";s:17:\"filter_items_list\";s:0:\"\";s:21:\"items_list_navigation\";s:0:\"\";s:10:\"items_list\";s:0:\"\";s:10:\"attributes\";s:0:\"\";s:14:\"name_admin_bar\";s:0:\"\";}s:15:\"custom_supports\";s:0:\"\";}s:16:\"project_features\";a:29:{s:4:\"name\";s:16:\"project_features\";s:5:\"label\";s:26:\"Home Page Project Features\";s:14:\"singular_label\";s:25:\"Home Page Project Feature\";s:11:\"description\";s:45:\"Add Project feature Image title and text here\";s:6:\"public\";s:4:\"true\";s:18:\"publicly_queryable\";s:4:\"true\";s:7:\"show_ui\";s:4:\"true\";s:17:\"show_in_nav_menus\";s:4:\"true\";s:12:\"show_in_rest\";s:4:\"true\";s:9:\"rest_base\";s:0:\"\";s:21:\"rest_controller_class\";s:0:\"\";s:11:\"has_archive\";s:5:\"false\";s:18:\"has_archive_string\";s:0:\"\";s:19:\"exclude_from_search\";s:5:\"false\";s:15:\"capability_type\";s:4:\"post\";s:12:\"hierarchical\";s:5:\"false\";s:7:\"rewrite\";s:4:\"true\";s:12:\"rewrite_slug\";s:0:\"\";s:17:\"rewrite_withfront\";s:4:\"true\";s:9:\"query_var\";s:4:\"true\";s:14:\"query_var_slug\";s:0:\"\";s:13:\"menu_position\";s:0:\"\";s:12:\"show_in_menu\";s:4:\"true\";s:19:\"show_in_menu_string\";s:0:\"\";s:9:\"menu_icon\";s:65:\"http://localhost/b2w/wp-content/uploads/2019/04/icon-features.png\";s:8:\"supports\";a:3:{i:0;s:5:\"title\";i:1;s:6:\"editor\";i:2;s:9:\"thumbnail\";}s:10:\"taxonomies\";a:0:{}s:6:\"labels\";a:24:{s:9:\"menu_name\";s:0:\"\";s:9:\"all_items\";s:0:\"\";s:7:\"add_new\";s:0:\"\";s:12:\"add_new_item\";s:0:\"\";s:9:\"edit_item\";s:0:\"\";s:8:\"new_item\";s:0:\"\";s:9:\"view_item\";s:0:\"\";s:10:\"view_items\";s:0:\"\";s:12:\"search_items\";s:0:\"\";s:9:\"not_found\";s:0:\"\";s:18:\"not_found_in_trash\";s:0:\"\";s:17:\"parent_item_colon\";s:0:\"\";s:14:\"featured_image\";s:0:\"\";s:18:\"set_featured_image\";s:0:\"\";s:21:\"remove_featured_image\";s:0:\"\";s:18:\"use_featured_image\";s:0:\"\";s:8:\"archives\";s:0:\"\";s:16:\"insert_into_item\";s:0:\"\";s:21:\"uploaded_to_this_item\";s:0:\"\";s:17:\"filter_items_list\";s:0:\"\";s:21:\"items_list_navigation\";s:0:\"\";s:10:\"items_list\";s:0:\"\";s:10:\"attributes\";s:0:\"\";s:14:\"name_admin_bar\";s:0:\"\";}s:15:\"custom_supports\";s:0:\"\";}s:11:\"testimonial\";a:29:{s:4:\"name\";s:11:\"testimonial\";s:5:\"label\";s:22:\"Home Page Testimonials\";s:14:\"singular_label\";s:21:\"Home Page Testimonial\";s:11:\"description\";s:0:\"\";s:6:\"public\";s:4:\"true\";s:18:\"publicly_queryable\";s:4:\"true\";s:7:\"show_ui\";s:4:\"true\";s:17:\"show_in_nav_menus\";s:4:\"true\";s:12:\"show_in_rest\";s:4:\"true\";s:9:\"rest_base\";s:0:\"\";s:21:\"rest_controller_class\";s:0:\"\";s:11:\"has_archive\";s:5:\"false\";s:18:\"has_archive_string\";s:0:\"\";s:19:\"exclude_from_search\";s:5:\"false\";s:15:\"capability_type\";s:4:\"post\";s:12:\"hierarchical\";s:5:\"false\";s:7:\"rewrite\";s:4:\"true\";s:12:\"rewrite_slug\";s:0:\"\";s:17:\"rewrite_withfront\";s:4:\"true\";s:9:\"query_var\";s:4:\"true\";s:14:\"query_var_slug\";s:0:\"\";s:13:\"menu_position\";s:0:\"\";s:12:\"show_in_menu\";s:4:\"true\";s:19:\"show_in_menu_string\";s:0:\"\";s:9:\"menu_icon\";s:65:\"http://localhost/b2w/wp-content/uploads/2019/04/icon-features.png\";s:8:\"supports\";a:3:{i:0;s:5:\"title\";i:1;s:6:\"editor\";i:2;s:9:\"thumbnail\";}s:10:\"taxonomies\";a:0:{}s:6:\"labels\";a:24:{s:9:\"menu_name\";s:0:\"\";s:9:\"all_items\";s:0:\"\";s:7:\"add_new\";s:0:\"\";s:12:\"add_new_item\";s:0:\"\";s:9:\"edit_item\";s:0:\"\";s:8:\"new_item\";s:0:\"\";s:9:\"view_item\";s:0:\"\";s:10:\"view_items\";s:0:\"\";s:12:\"search_items\";s:0:\"\";s:9:\"not_found\";s:0:\"\";s:18:\"not_found_in_trash\";s:0:\"\";s:17:\"parent_item_colon\";s:0:\"\";s:14:\"featured_image\";s:0:\"\";s:18:\"set_featured_image\";s:0:\"\";s:21:\"remove_featured_image\";s:0:\"\";s:18:\"use_featured_image\";s:0:\"\";s:8:\"archives\";s:0:\"\";s:16:\"insert_into_item\";s:0:\"\";s:21:\"uploaded_to_this_item\";s:0:\"\";s:17:\"filter_items_list\";s:0:\"\";s:21:\"items_list_navigation\";s:0:\"\";s:10:\"items_list\";s:0:\"\";s:10:\"attributes\";s:0:\"\";s:14:\"name_admin_bar\";s:0:\"\";}s:15:\"custom_supports\";s:0:\"\";}s:8:\"resource\";a:29:{s:4:\"name\";s:8:\"resource\";s:5:\"label\";s:9:\"Resources\";s:14:\"singular_label\";s:8:\"Resource\";s:11:\"description\";s:0:\"\";s:6:\"public\";s:4:\"true\";s:18:\"publicly_queryable\";s:4:\"true\";s:7:\"show_ui\";s:4:\"true\";s:17:\"show_in_nav_menus\";s:4:\"true\";s:12:\"show_in_rest\";s:4:\"true\";s:9:\"rest_base\";s:0:\"\";s:21:\"rest_controller_class\";s:0:\"\";s:11:\"has_archive\";s:5:\"false\";s:18:\"has_archive_string\";s:0:\"\";s:19:\"exclude_from_search\";s:4:\"true\";s:15:\"capability_type\";s:4:\"post\";s:12:\"hierarchical\";s:5:\"false\";s:7:\"rewrite\";s:4:\"true\";s:12:\"rewrite_slug\";s:0:\"\";s:17:\"rewrite_withfront\";s:4:\"true\";s:9:\"query_var\";s:4:\"true\";s:14:\"query_var_slug\";s:0:\"\";s:13:\"menu_position\";s:0:\"\";s:12:\"show_in_menu\";s:4:\"true\";s:19:\"show_in_menu_string\";s:0:\"\";s:9:\"menu_icon\";s:66:\"http://localhost/b2w/wp-content/uploads/2019/04/icon-resources.png\";s:8:\"supports\";a:2:{i:0;s:5:\"title\";i:1;s:6:\"editor\";}s:10:\"taxonomies\";a:0:{}s:6:\"labels\";a:24:{s:9:\"menu_name\";s:0:\"\";s:9:\"all_items\";s:0:\"\";s:7:\"add_new\";s:0:\"\";s:12:\"add_new_item\";s:0:\"\";s:9:\"edit_item\";s:0:\"\";s:8:\"new_item\";s:0:\"\";s:9:\"view_item\";s:0:\"\";s:10:\"view_items\";s:0:\"\";s:12:\"search_items\";s:0:\"\";s:9:\"not_found\";s:0:\"\";s:18:\"not_found_in_trash\";s:0:\"\";s:17:\"parent_item_colon\";s:0:\"\";s:14:\"featured_image\";s:0:\"\";s:18:\"set_featured_image\";s:0:\"\";s:21:\"remove_featured_image\";s:0:\"\";s:18:\"use_featured_image\";s:0:\"\";s:8:\"archives\";s:0:\"\";s:16:\"insert_into_item\";s:0:\"\";s:21:\"uploaded_to_this_item\";s:0:\"\";s:17:\"filter_items_list\";s:0:\"\";s:21:\"items_list_navigation\";s:0:\"\";s:10:\"items_list\";s:0:\"\";s:10:\"attributes\";s:0:\"\";s:14:\"name_admin_bar\";s:0:\"\";}s:15:\"custom_supports\";s:0:\"\";}}', 'yes'),
(371, 'category_children', 'a:0:{}', 'yes'),
(396, 'wpcf7', 'a:2:{s:7:\"version\";s:5:\"5.1.1\";s:13:\"bulk_validate\";a:4:{s:9:\"timestamp\";i:1555435203;s:7:\"version\";s:5:\"5.1.1\";s:11:\"count_valid\";i:1;s:13:\"count_invalid\";i:0;}}', 'yes'),
(417, '_site_transient_timeout_browser_5ac71600cc9c7fa82bbc370cd02eb16b', '1557421787', 'no'),
(418, '_site_transient_browser_5ac71600cc9c7fa82bbc370cd02eb16b', 'a:10:{s:4:\"name\";s:7:\"Firefox\";s:7:\"version\";s:4:\"67.0\";s:8:\"platform\";s:7:\"Windows\";s:10:\"update_url\";s:24:\"https://www.firefox.com/\";s:7:\"img_src\";s:44:\"http://s.w.org/images/browsers/firefox.png?1\";s:11:\"img_src_ssl\";s:45:\"https://s.w.org/images/browsers/firefox.png?1\";s:15:\"current_version\";s:2:\"56\";s:7:\"upgrade\";b:0;s:8:\"insecure\";b:0;s:6:\"mobile\";b:0;}', 'no'),
(468, '_site_transient_timeout_theme_roots', '1556995729', 'no'),
(469, '_site_transient_theme_roots', 'a:5:{s:25:\"bootstrap2wordpress-child\";s:7:\"/themes\";s:19:\"bootstrap2wordpress\";s:7:\"/themes\";s:13:\"twentyfifteen\";s:7:\"/themes\";s:15:\"twentyseventeen\";s:7:\"/themes\";s:13:\"twentysixteen\";s:7:\"/themes\";}', 'no'),
(471, '_site_transient_update_themes', 'O:8:\"stdClass\":4:{s:12:\"last_checked\";i:1556993954;s:7:\"checked\";a:5:{s:25:\"bootstrap2wordpress-child\";s:5:\"1.0.0\";s:19:\"bootstrap2wordpress\";s:5:\"1.0.0\";s:13:\"twentyfifteen\";s:3:\"2.0\";s:15:\"twentyseventeen\";s:3:\"1.7\";s:13:\"twentysixteen\";s:3:\"1.5\";}s:8:\"response\";a:3:{s:13:\"twentyfifteen\";a:4:{s:5:\"theme\";s:13:\"twentyfifteen\";s:11:\"new_version\";s:3:\"2.4\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentyfifteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentyfifteen.2.4.zip\";}s:15:\"twentyseventeen\";a:4:{s:5:\"theme\";s:15:\"twentyseventeen\";s:11:\"new_version\";s:3:\"2.1\";s:3:\"url\";s:45:\"https://wordpress.org/themes/twentyseventeen/\";s:7:\"package\";s:61:\"https://downloads.wordpress.org/theme/twentyseventeen.2.1.zip\";}s:13:\"twentysixteen\";a:4:{s:5:\"theme\";s:13:\"twentysixteen\";s:11:\"new_version\";s:3:\"1.9\";s:3:\"url\";s:43:\"https://wordpress.org/themes/twentysixteen/\";s:7:\"package\";s:59:\"https://downloads.wordpress.org/theme/twentysixteen.1.9.zip\";}}s:12:\"translations\";a:0:{}}', 'no');

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_postmeta`
--

CREATE TABLE `bs2wp_postmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bs2wp_postmeta`
--

INSERT INTO `bs2wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(35, 3, '_edit_lock', '1553602116:1'),
(36, 3, '_edit_last', '1'),
(37, 11, '_edit_last', '1'),
(38, 11, '_edit_lock', '1554412973:1'),
(39, 13, '_menu_item_type', 'post_type'),
(40, 13, '_menu_item_menu_item_parent', '0'),
(41, 13, '_menu_item_object_id', '11'),
(42, 13, '_menu_item_object', 'page'),
(43, 13, '_menu_item_target', ''),
(44, 13, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(45, 13, '_menu_item_xfn', ''),
(46, 13, '_menu_item_url', ''),
(57, 11, '_wp_page_template', 'page-custom_home_page.php'),
(58, 11, 'pre_launch_price', '$149'),
(59, 11, 'launch_price', '$299'),
(60, 11, 'final_price', '$399'),
(61, 11, 'course_url', 'https://www.facebook.com/mehedi0013'),
(62, 11, 'button_text', 'Enroll &raquo;'),
(63, 11, 'optin_text', '<strong>Subscribe to our mailing list </strong>We will sent something special as a thank you.'),
(64, 11, 'optin_button_text', 'Click here to subscribe'),
(65, 17, '_edit_last', '1'),
(66, 17, '_edit_lock', '1554142900:1'),
(67, 27, '_wp_attached_file', '2019/04/aj.png'),
(68, 27, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:200;s:6:\"height\";i:200;s:4:\"file\";s:14:\"2019/04/aj.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:14:\"aj-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(69, 28, '_wp_attached_file', '2019/04/ben.png'),
(70, 28, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:200;s:6:\"height\";i:200;s:4:\"file\";s:15:\"2019/04/ben.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"ben-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(71, 29, '_wp_attached_file', '2019/04/brad.png'),
(72, 29, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:696;s:6:\"height\";i:726;s:4:\"file\";s:16:\"2019/04/brad.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:16:\"brad-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:16:\"brad-288x300.png\";s:5:\"width\";i:288;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(73, 30, '_wp_attached_file', '2019/04/brad-elvis.png'),
(74, 30, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:530;s:6:\"height\";i:1000;s:4:\"file\";s:22:\"2019/04/brad-elvis.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"brad-elvis-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"brad-elvis-159x300.png\";s:5:\"width\";i:159;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(75, 31, '_wp_attached_file', '2019/04/brennan.jpg'),
(76, 31, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:200;s:6:\"height\";i:200;s:4:\"file\";s:19:\"2019/04/brennan.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"brennan-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(77, 32, '_wp_attached_file', '2019/04/coda2-logo.jpg'),
(78, 32, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:342;s:6:\"height\";i:200;s:4:\"file\";s:22:\"2019/04/coda2-logo.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"coda2-logo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"coda2-logo-300x175.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:175;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(79, 33, '_wp_attached_file', '2019/04/dark-bg.jpg'),
(80, 33, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:250;s:6:\"height\";i:250;s:4:\"file\";s:19:\"2019/04/dark-bg.jpg\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"dark-bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(81, 34, '_wp_attached_file', '2019/04/dropbox-logo.jpg'),
(82, 34, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:342;s:6:\"height\";i:200;s:4:\"file\";s:24:\"2019/04/dropbox-logo.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:24:\"dropbox-logo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"dropbox-logo-300x175.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:175;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(83, 35, '_wp_attached_file', '2019/04/ernest.png'),
(84, 35, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:200;s:6:\"height\";i:200;s:4:\"file\";s:18:\"2019/04/ernest.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"ernest-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(85, 36, '_wp_attached_file', '2019/04/facebook.jpg'),
(86, 36, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:342;s:6:\"height\";i:200;s:4:\"file\";s:20:\"2019/04/facebook.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"facebook-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"facebook-300x175.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:175;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(87, 37, '_wp_attached_file', '2019/04/favicon.png'),
(88, 37, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:16;s:6:\"height\";i:16;s:4:\"file\";s:19:\"2019/04/favicon.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(89, 38, '_wp_attached_file', '2019/04/generic-bg.jpg'),
(90, 38, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2000;s:6:\"height\";i:896;s:4:\"file\";s:22:\"2019/04/generic-bg.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"generic-bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"generic-bg-300x134.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:134;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:22:\"generic-bg-768x344.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:344;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:23:\"generic-bg-1024x459.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:459;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(91, 39, '_wp_attached_file', '2019/04/google.jpg'),
(92, 39, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:342;s:6:\"height\";i:200;s:4:\"file\";s:18:\"2019/04/google.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"google-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"google-300x175.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:175;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(93, 40, '_wp_attached_file', '2019/04/hero-bg.jpg'),
(94, 40, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2000;s:6:\"height\";i:724;s:4:\"file\";s:19:\"2019/04/hero-bg.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"hero-bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"hero-bg-300x109.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:109;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:19:\"hero-bg-768x278.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:278;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:20:\"hero-bg-1024x371.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:371;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(95, 41, '_wp_attached_file', '2019/04/hipster-stuff.jpg'),
(96, 41, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1440;s:6:\"height\";i:1015;s:4:\"file\";s:25:\"2019/04/hipster-stuff.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"hipster-stuff-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"hipster-stuff-300x211.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:211;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"hipster-stuff-768x541.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:541;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"hipster-stuff-1024x722.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:722;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(97, 42, '_wp_attached_file', '2019/04/icon-boost.png'),
(98, 42, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:140;s:6:\"height\";i:140;s:4:\"file\";s:22:\"2019/04/icon-boost.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(99, 43, '_wp_attached_file', '2019/04/icon-cms.png'),
(100, 43, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:140;s:6:\"height\";i:140;s:4:\"file\";s:20:\"2019/04/icon-cms.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(101, 44, '_wp_attached_file', '2019/04/icon-code.png'),
(102, 44, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:140;s:6:\"height\";i:140;s:4:\"file\";s:21:\"2019/04/icon-code.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(103, 45, '_wp_attached_file', '2019/04/icon-computer.png'),
(104, 45, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:40;s:6:\"height\";i:40;s:4:\"file\";s:25:\"2019/04/icon-computer.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(105, 46, '_wp_attached_file', '2019/04/icon-design.png'),
(106, 46, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:140;s:6:\"height\";i:140;s:4:\"file\";s:23:\"2019/04/icon-design.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(107, 47, '_wp_attached_file', '2019/04/icon-features.png'),
(108, 47, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:18;s:6:\"height\";i:18;s:4:\"file\";s:25:\"2019/04/icon-features.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(109, 48, '_wp_attached_file', '2019/04/icon-pad.png'),
(110, 48, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:140;s:6:\"height\";i:140;s:4:\"file\";s:20:\"2019/04/icon-pad.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(111, 49, '_wp_attached_file', '2019/04/icon-resources.png'),
(112, 49, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:18;s:6:\"height\";i:15;s:4:\"file\";s:26:\"2019/04/icon-resources.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(113, 50, '_wp_attached_file', '2019/04/icon-rocket.png'),
(114, 50, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:140;s:6:\"height\";i:140;s:4:\"file\";s:23:\"2019/04/icon-rocket.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(115, 51, '_wp_attached_file', '2019/04/icon-sprite.png'),
(116, 51, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:240;s:6:\"height\";i:40;s:4:\"file\";s:23:\"2019/04/icon-sprite.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"icon-sprite-150x40.png\";s:5:\"width\";i:150;s:6:\"height\";i:40;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(117, 52, '_wp_attached_file', '2019/04/icon-testimonials.png'),
(118, 52, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:18;s:6:\"height\";i:17;s:4:\"file\";s:29:\"2019/04/icon-testimonials.png\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(119, 53, '_wp_attached_file', '2019/04/justhost-logo.jpg'),
(120, 53, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:342;s:6:\"height\";i:200;s:4:\"file\";s:25:\"2019/04/justhost-logo.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"justhost-logo-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:25:\"justhost-logo-300x175.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:175;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(121, 54, '_wp_attached_file', '2019/04/logo.png'),
(122, 54, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:166;s:6:\"height\";i:19;s:4:\"file\";s:16:\"2019/04/logo.png\";s:5:\"sizes\";a:1:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:15:\"logo-150x19.png\";s:5:\"width\";i:150;s:6:\"height\";i:19;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(123, 55, '_wp_attached_file', '2019/04/logo-badge.png'),
(124, 55, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:500;s:6:\"height\";i:383;s:4:\"file\";s:22:\"2019/04/logo-badge.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:22:\"logo-badge-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:22:\"logo-badge-300x230.png\";s:5:\"width\";i:300;s:6:\"height\";i:230;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(125, 56, '_wp_attached_file', '2019/04/mehedi.jpg'),
(126, 56, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:1600;s:6:\"height\";i:1200;s:4:\"file\";s:18:\"2019/04/mehedi.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mehedi-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mehedi-300x225.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:225;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:18:\"mehedi-768x576.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:576;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:19:\"mehedi-1024x768.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:768;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:3:\"2.8\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:14:\"HUAWEI LUA-U22\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:10:\"1530469680\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:3:\"3.5\";s:3:\"iso\";s:3:\"125\";s:13:\"shutter_speed\";s:8:\"0.007134\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"1\";s:8:\"keywords\";a:0:{}}}'),
(127, 57, '_wp_attached_file', '2019/04/mehedi.png'),
(128, 57, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:472;s:6:\"height\";i:591;s:4:\"file\";s:18:\"2019/04/mehedi.png\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:18:\"mehedi-150x150.png\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:9:\"image/png\";}s:6:\"medium\";a:4:{s:4:\"file\";s:18:\"mehedi-240x300.png\";s:5:\"width\";i:240;s:6:\"height\";i:300;s:9:\"mime-type\";s:9:\"image/png\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(129, 58, '_wp_attached_file', '2019/04/mehedi_bg.jpg'),
(130, 58, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:530;s:6:\"height\";i:1000;s:4:\"file\";s:21:\"2019/04/mehedi_bg.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:21:\"mehedi_bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:21:\"mehedi_bg-159x300.jpg\";s:5:\"width\";i:159;s:6:\"height\";i:300;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(131, 59, '_wp_attached_file', '2019/04/stuff-bg.jpg'),
(132, 59, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2000;s:6:\"height\";i:1333;s:4:\"file\";s:20:\"2019/04/stuff-bg.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:20:\"stuff-bg-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:20:\"stuff-bg-300x200.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:200;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:20:\"stuff-bg-768x512.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:512;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:21:\"stuff-bg-1024x682.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:682;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(133, 60, '_wp_attached_file', '2019/04/stuff-feature.jpg'),
(134, 60, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:2000;s:6:\"height\";i:564;s:4:\"file\";s:25:\"2019/04/stuff-feature.jpg\";s:5:\"sizes\";a:4:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:25:\"stuff-feature-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:24:\"stuff-feature-300x85.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:85;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:12:\"medium_large\";a:4:{s:4:\"file\";s:25:\"stuff-feature-768x217.jpg\";s:5:\"width\";i:768;s:6:\"height\";i:217;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:5:\"large\";a:4:{s:4:\"file\";s:26:\"stuff-feature-1024x289.jpg\";s:5:\"width\";i:1024;s:6:\"height\";i:289;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(135, 61, '_wp_attached_file', '2019/04/tile.jpg'),
(136, 61, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:149;s:6:\"height\";i:149;s:4:\"file\";s:16:\"2019/04/tile.jpg\";s:5:\"sizes\";a:0:{}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(137, 62, '_wp_attached_file', '2019/04/youtube.jpg'),
(138, 62, '_wp_attachment_metadata', 'a:5:{s:5:\"width\";i:342;s:6:\"height\";i:200;s:4:\"file\";s:19:\"2019/04/youtube.jpg\";s:5:\"sizes\";a:2:{s:9:\"thumbnail\";a:4:{s:4:\"file\";s:19:\"youtube-150x150.jpg\";s:5:\"width\";i:150;s:6:\"height\";i:150;s:9:\"mime-type\";s:10:\"image/jpeg\";}s:6:\"medium\";a:4:{s:4:\"file\";s:19:\"youtube-300x175.jpg\";s:5:\"width\";i:300;s:6:\"height\";i:175;s:9:\"mime-type\";s:10:\"image/jpeg\";}}s:10:\"image_meta\";a:12:{s:8:\"aperture\";s:1:\"0\";s:6:\"credit\";s:0:\"\";s:6:\"camera\";s:0:\"\";s:7:\"caption\";s:0:\"\";s:17:\"created_timestamp\";s:1:\"0\";s:9:\"copyright\";s:0:\"\";s:12:\"focal_length\";s:1:\"0\";s:3:\"iso\";s:1:\"0\";s:13:\"shutter_speed\";s:1:\"0\";s:5:\"title\";s:0:\"\";s:11:\"orientation\";s:1:\"0\";s:8:\"keywords\";a:0:{}}}'),
(139, 42, '_wp_attachment_image_alt', 'Boost Your Income'),
(140, 11, 'boost_your__income_banner_image', '42'),
(141, 11, '_boost_your__income_banner_image', 'field_5ca10a224a62e'),
(142, 11, 'boost_your_income_title', 'How you can boost your income'),
(143, 11, '_boost_your_income_title', 'field_5ca10bea4a62f'),
(144, 11, 'boost_your_income_description', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur cupiditate pariatur eaque molestiae earum quo architecto aut? Expedita officiis perferendis temporibus reprehenderit assumenda molestias saepe commodi quam incidunt, vero consectetur.'),
(145, 11, '_boost_your_income_description', 'field_5ca10ca54a630'),
(146, 11, 'boost_your_income_reasone_one_title', 'Make money on the site'),
(147, 11, '_boost_your_income_reasone_one_title', 'field_5ca10d5c4a631'),
(148, 11, 'boost_your_income_reasone_one_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(149, 11, '_boost_your_income_reasone_one_description', 'field_5ca10d914a632'),
(150, 11, 'boost_your_income_reasone_two_title', 'Create a full time income'),
(151, 11, '_boost_your_income_reasone_two_title', 'field_5ca10de44a633'),
(152, 11, 'boost_your_income_reasone_two_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(153, 11, '_boost_your_income_reasone_two_description', 'field_5ca10e094a634'),
(154, 63, 'boost_your__income_banner_image', '42'),
(155, 63, '_boost_your__income_banner_image', 'field_5ca10a224a62e'),
(156, 63, 'boost_your_income_title', 'How you can boost your income'),
(157, 63, '_boost_your_income_title', 'field_5ca10bea4a62f'),
(158, 63, 'boost_your_income_description', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur cupiditate pariatur eaque molestiae earum quo architecto aut? Expedita officiis perferendis temporibus reprehenderit assumenda molestias saepe commodi quam incidunt, vero consectetur.'),
(159, 63, '_boost_your_income_description', 'field_5ca10ca54a630'),
(160, 63, 'boost_your_income_reasone_one_title', 'Make money on the site'),
(161, 63, '_boost_your_income_reasone_one_title', 'field_5ca10d5c4a631'),
(162, 63, 'boost_your_income_reasone_one_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(163, 63, '_boost_your_income_reasone_one_description', 'field_5ca10d914a632'),
(164, 63, 'boost_your_income_reasone_two_title', 'Create a full time income'),
(165, 63, '_boost_your_income_reasone_two_title', 'field_5ca10de44a633'),
(166, 63, 'boost_your_income_reasone_two_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(167, 63, '_boost_your_income_reasone_two_description', 'field_5ca10e094a634'),
(168, 64, '_edit_last', '1'),
(169, 64, '_edit_lock', '1554144096:1'),
(170, 48, '_wp_attachment_image_alt', 'Who Should Take This Course'),
(171, 11, 'who_should_take_this_course_bannse_image', '48'),
(172, 11, '_who_should_take_this_course_bannse_image', 'field_5ca255a541cd7'),
(173, 11, 'who_should_take_this_course_title', 'Who should take this course'),
(174, 11, '_who_should_take_this_course_title', 'field_5ca2561041cd8'),
(175, 11, 'who_should_take_this_course_deseription', '<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.'),
(176, 11, '_who_should_take_this_course_deseription', 'field_5ca2563a41cd9'),
(177, 68, 'boost_your__income_banner_image', '42'),
(178, 68, '_boost_your__income_banner_image', 'field_5ca10a224a62e'),
(179, 68, 'boost_your_income_title', 'How you can boost your income'),
(180, 68, '_boost_your_income_title', 'field_5ca10bea4a62f'),
(181, 68, 'boost_your_income_description', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur cupiditate pariatur eaque molestiae earum quo architecto aut? Expedita officiis perferendis temporibus reprehenderit assumenda molestias saepe commodi quam incidunt, vero consectetur.'),
(182, 68, '_boost_your_income_description', 'field_5ca10ca54a630'),
(183, 68, 'boost_your_income_reasone_one_title', 'Make money on the site'),
(184, 68, '_boost_your_income_reasone_one_title', 'field_5ca10d5c4a631'),
(185, 68, 'boost_your_income_reasone_one_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(186, 68, '_boost_your_income_reasone_one_description', 'field_5ca10d914a632'),
(187, 68, 'boost_your_income_reasone_two_title', 'Create a full time income'),
(188, 68, '_boost_your_income_reasone_two_title', 'field_5ca10de44a633'),
(189, 68, 'boost_your_income_reasone_two_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(190, 68, '_boost_your_income_reasone_two_description', 'field_5ca10e094a634'),
(191, 68, 'who_should_take_this_course_bannse_image', '48'),
(192, 68, '_who_should_take_this_course_bannse_image', 'field_5ca255a541cd7'),
(193, 68, 'who_should_take_this_course_title', 'Who should take this course'),
(194, 68, '_who_should_take_this_course_title', 'field_5ca2561041cd8'),
(195, 68, 'who_should_take_this_course_deseription', '<div class=\"col-sm-8 offset-sm-2\">\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n\r\n</div>'),
(196, 68, '_who_should_take_this_course_deseription', 'field_5ca2563a41cd9'),
(197, 69, 'boost_your__income_banner_image', '42'),
(198, 69, '_boost_your__income_banner_image', 'field_5ca10a224a62e'),
(199, 69, 'boost_your_income_title', 'How you can boost your income'),
(200, 69, '_boost_your_income_title', 'field_5ca10bea4a62f'),
(201, 69, 'boost_your_income_description', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur cupiditate pariatur eaque molestiae earum quo architecto aut? Expedita officiis perferendis temporibus reprehenderit assumenda molestias saepe commodi quam incidunt, vero consectetur.'),
(202, 69, '_boost_your_income_description', 'field_5ca10ca54a630'),
(203, 69, 'boost_your_income_reasone_one_title', 'Make money on the site'),
(204, 69, '_boost_your_income_reasone_one_title', 'field_5ca10d5c4a631'),
(205, 69, 'boost_your_income_reasone_one_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(206, 69, '_boost_your_income_reasone_one_description', 'field_5ca10d914a632'),
(207, 69, 'boost_your_income_reasone_two_title', 'Create a full time income'),
(208, 69, '_boost_your_income_reasone_two_title', 'field_5ca10de44a633'),
(209, 69, 'boost_your_income_reasone_two_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(210, 69, '_boost_your_income_reasone_two_description', 'field_5ca10e094a634'),
(211, 69, 'who_should_take_this_course_bannse_image', '48'),
(212, 69, '_who_should_take_this_course_bannse_image', 'field_5ca255a541cd7'),
(213, 69, 'who_should_take_this_course_title', 'Who should take this course'),
(214, 69, '_who_should_take_this_course_title', 'field_5ca2561041cd8'),
(215, 69, 'who_should_take_this_course_deseription', '<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.'),
(216, 69, '_who_should_take_this_course_deseription', 'field_5ca2563a41cd9'),
(217, 73, '_edit_last', '1'),
(218, 73, '_edit_lock', '1554314721:1'),
(219, 76, '_edit_last', '1'),
(220, 76, '_edit_lock', '1554317769:1'),
(261, 85, '_edit_last', '1'),
(262, 85, '_edit_lock', '1554313767:1'),
(263, 85, 'course_features_icon', 'ci ci-computer'),
(264, 85, '_course_features_icon', 'field_5ca4e3f8227f8'),
(265, 86, '_edit_last', '1'),
(266, 86, '_edit_lock', '1554313798:1'),
(267, 86, 'course_features_icon', 'ci ci-watch'),
(268, 86, '_course_features_icon', 'field_5ca4e3f8227f8'),
(269, 87, '_edit_last', '1'),
(270, 87, '_edit_lock', '1554313822:1'),
(271, 87, 'course_features_icon', 'ci ci-calender'),
(272, 87, '_course_features_icon', 'field_5ca4e3f8227f8'),
(273, 88, '_edit_last', '1'),
(274, 88, '_edit_lock', '1554313834:1'),
(275, 88, 'course_features_icon', 'ci ci-community'),
(276, 88, '_course_features_icon', 'field_5ca4e3f8227f8'),
(277, 89, '_edit_last', '1'),
(278, 89, '_edit_lock', '1554313902:1'),
(279, 89, 'course_features_icon', 'ci ci-instructor'),
(280, 89, '_course_features_icon', 'field_5ca4e3f8227f8'),
(281, 90, '_edit_last', '1'),
(282, 90, '_edit_lock', '1554316913:1'),
(283, 90, 'course_features_icon', 'ci ci-device'),
(284, 90, '_course_features_icon', 'field_5ca4e3f8227f8'),
(285, 50, '_wp_attachment_image_alt', 'Course Features'),
(286, 11, 'home_page_course_features_banner_image', '50'),
(287, 11, '_home_page_course_features_banner_image', 'field_5ca4e231a0874'),
(288, 11, 'home_page_course_features_title', 'Course Features'),
(289, 11, '_home_page_course_features_title', 'field_5ca4e299a0875'),
(290, 92, 'boost_your__income_banner_image', '42'),
(291, 92, '_boost_your__income_banner_image', 'field_5ca10a224a62e'),
(292, 92, 'boost_your_income_title', 'How you can boost your income'),
(293, 92, '_boost_your_income_title', 'field_5ca10bea4a62f'),
(294, 92, 'boost_your_income_description', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur cupiditate pariatur eaque molestiae earum quo architecto aut? Expedita officiis perferendis temporibus reprehenderit assumenda molestias saepe commodi quam incidunt, vero consectetur.'),
(295, 92, '_boost_your_income_description', 'field_5ca10ca54a630'),
(296, 92, 'boost_your_income_reasone_one_title', 'Make money on the site'),
(297, 92, '_boost_your_income_reasone_one_title', 'field_5ca10d5c4a631'),
(298, 92, 'boost_your_income_reasone_one_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(299, 92, '_boost_your_income_reasone_one_description', 'field_5ca10d914a632'),
(300, 92, 'boost_your_income_reasone_two_title', 'Create a full time income'),
(301, 92, '_boost_your_income_reasone_two_title', 'field_5ca10de44a633'),
(302, 92, 'boost_your_income_reasone_two_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(303, 92, '_boost_your_income_reasone_two_description', 'field_5ca10e094a634'),
(304, 92, 'who_should_take_this_course_bannse_image', '48'),
(305, 92, '_who_should_take_this_course_bannse_image', 'field_5ca255a541cd7'),
(306, 92, 'who_should_take_this_course_title', 'Who should take this course'),
(307, 92, '_who_should_take_this_course_title', 'field_5ca2561041cd8');
INSERT INTO `bs2wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(308, 92, 'who_should_take_this_course_deseription', '<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.'),
(309, 92, '_who_should_take_this_course_deseription', 'field_5ca2563a41cd9'),
(310, 92, 'home_page_course_features_banner_image', '50'),
(311, 92, '_home_page_course_features_banner_image', 'field_5ca4e231a0874'),
(312, 92, 'home_page_course_features_title', 'Course Features'),
(313, 92, '_home_page_course_features_title', 'field_5ca4e299a0875'),
(314, 93, '_edit_last', '1'),
(315, 93, '_edit_lock', '1554318286:1'),
(316, 11, 'final_project_feature_title', 'Final Project Features'),
(317, 11, '_final_project_feature_title', 'field_5ca502786bc3f'),
(318, 11, 'final_project_feature_desc', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab, debitis voluptatem! Ullam, esse modi dolor culpa, quasi ab at, quisquam illum fuga minima quo omnis repellat natus odio maxime! Esse asperiores tenetur nulla harum unde odio voluptatibus odit ea vero perferendis nesciunt eum cupiditate, earum dolorum labore laborum dignissimos ab.'),
(319, 11, '_final_project_feature_desc', 'field_5ca5029c6bc40'),
(320, 96, 'boost_your__income_banner_image', '42'),
(321, 96, '_boost_your__income_banner_image', 'field_5ca10a224a62e'),
(322, 96, 'boost_your_income_title', 'How you can boost your income'),
(323, 96, '_boost_your_income_title', 'field_5ca10bea4a62f'),
(324, 96, 'boost_your_income_description', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur cupiditate pariatur eaque molestiae earum quo architecto aut? Expedita officiis perferendis temporibus reprehenderit assumenda molestias saepe commodi quam incidunt, vero consectetur.'),
(325, 96, '_boost_your_income_description', 'field_5ca10ca54a630'),
(326, 96, 'boost_your_income_reasone_one_title', 'Make money on the site'),
(327, 96, '_boost_your_income_reasone_one_title', 'field_5ca10d5c4a631'),
(328, 96, 'boost_your_income_reasone_one_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(329, 96, '_boost_your_income_reasone_one_description', 'field_5ca10d914a632'),
(330, 96, 'boost_your_income_reasone_two_title', 'Create a full time income'),
(331, 96, '_boost_your_income_reasone_two_title', 'field_5ca10de44a633'),
(332, 96, 'boost_your_income_reasone_two_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(333, 96, '_boost_your_income_reasone_two_description', 'field_5ca10e094a634'),
(334, 96, 'who_should_take_this_course_bannse_image', '48'),
(335, 96, '_who_should_take_this_course_bannse_image', 'field_5ca255a541cd7'),
(336, 96, 'who_should_take_this_course_title', 'Who should take this course'),
(337, 96, '_who_should_take_this_course_title', 'field_5ca2561041cd8'),
(338, 96, 'who_should_take_this_course_deseription', '<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.'),
(339, 96, '_who_should_take_this_course_deseription', 'field_5ca2563a41cd9'),
(340, 96, 'home_page_course_features_banner_image', '50'),
(341, 96, '_home_page_course_features_banner_image', 'field_5ca4e231a0874'),
(342, 96, 'home_page_course_features_title', 'Course Features'),
(343, 96, '_home_page_course_features_title', 'field_5ca4e299a0875'),
(344, 96, 'final_project_feature_title', 'Final Project Features'),
(345, 96, '_final_project_feature_title', 'field_5ca502786bc3f'),
(346, 96, 'final_project_feature_desc', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab, debitis voluptatem! Ullam, esse modi dolor culpa, quasi ab at, quisquam illum fuga minima quo omnis repellat natus odio maxime! Esse asperiores tenetur nulla harum unde odio voluptatibus odit ea vero perferendis nesciunt eum cupiditate, earum dolorum labore laborum dignissimos ab.'),
(347, 96, '_final_project_feature_desc', 'field_5ca5029c6bc40'),
(348, 97, '_edit_last', '1'),
(349, 97, '_edit_lock', '1554318672:1'),
(350, 97, '_thumbnail_id', '46'),
(351, 98, '_edit_last', '1'),
(352, 98, '_edit_lock', '1554318707:1'),
(353, 98, '_thumbnail_id', '44'),
(354, 99, '_edit_last', '1'),
(355, 99, '_edit_lock', '1554318745:1'),
(356, 99, '_thumbnail_id', '46'),
(357, 100, '_edit_last', '1'),
(358, 100, '_edit_lock', '1554401504:1'),
(359, 11, 'home_page_video_features_video', 'https://www.youtube.com/embed/l2BooJEP8aM?start=15'),
(360, 11, '_home_page_video_features_video', 'field_5ca644dccf189'),
(361, 102, 'boost_your__income_banner_image', '42'),
(362, 102, '_boost_your__income_banner_image', 'field_5ca10a224a62e'),
(363, 102, 'boost_your_income_title', 'How you can boost your income'),
(364, 102, '_boost_your_income_title', 'field_5ca10bea4a62f'),
(365, 102, 'boost_your_income_description', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur cupiditate pariatur eaque molestiae earum quo architecto aut? Expedita officiis perferendis temporibus reprehenderit assumenda molestias saepe commodi quam incidunt, vero consectetur.'),
(366, 102, '_boost_your_income_description', 'field_5ca10ca54a630'),
(367, 102, 'boost_your_income_reasone_one_title', 'Make money on the site'),
(368, 102, '_boost_your_income_reasone_one_title', 'field_5ca10d5c4a631'),
(369, 102, 'boost_your_income_reasone_one_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(370, 102, '_boost_your_income_reasone_one_description', 'field_5ca10d914a632'),
(371, 102, 'boost_your_income_reasone_two_title', 'Create a full time income'),
(372, 102, '_boost_your_income_reasone_two_title', 'field_5ca10de44a633'),
(373, 102, 'boost_your_income_reasone_two_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(374, 102, '_boost_your_income_reasone_two_description', 'field_5ca10e094a634'),
(375, 102, 'who_should_take_this_course_bannse_image', '48'),
(376, 102, '_who_should_take_this_course_bannse_image', 'field_5ca255a541cd7'),
(377, 102, 'who_should_take_this_course_title', 'Who should take this course'),
(378, 102, '_who_should_take_this_course_title', 'field_5ca2561041cd8'),
(379, 102, 'who_should_take_this_course_deseription', '<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.'),
(380, 102, '_who_should_take_this_course_deseription', 'field_5ca2563a41cd9'),
(381, 102, 'home_page_course_features_banner_image', '50'),
(382, 102, '_home_page_course_features_banner_image', 'field_5ca4e231a0874'),
(383, 102, 'home_page_course_features_title', 'Course Features'),
(384, 102, '_home_page_course_features_title', 'field_5ca4e299a0875'),
(385, 102, 'final_project_feature_title', 'Final Project Features'),
(386, 102, '_final_project_feature_title', 'field_5ca502786bc3f'),
(387, 102, 'final_project_feature_desc', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab, debitis voluptatem! Ullam, esse modi dolor culpa, quasi ab at, quisquam illum fuga minima quo omnis repellat natus odio maxime! Esse asperiores tenetur nulla harum unde odio voluptatibus odit ea vero perferendis nesciunt eum cupiditate, earum dolorum labore laborum dignissimos ab.'),
(388, 102, '_final_project_feature_desc', 'field_5ca5029c6bc40'),
(389, 102, 'home_page_video_features_video', 'https://www.youtube.com/embed/l2BooJEP8aM?start=15'),
(390, 102, '_home_page_video_features_video', 'field_5ca644dccf189'),
(391, 103, '_edit_last', '1'),
(392, 103, '_edit_lock', '1554406005:1'),
(393, 11, 'home_page_your_instructor_title', 'Your Instructore'),
(394, 11, '_home_page_your_instructor_title', 'field_5ca64993a8057'),
(395, 11, 'home_page_your_instructor_name', 'Mehedi Hassan'),
(396, 11, '_home_page_your_instructor_name', 'field_5ca649f9a8058'),
(397, 11, 'home_page_your_instructor_facebook_link', 'https://www.facebook.com/mehedi0013'),
(398, 11, '_home_page_your_instructor_facebook_link', 'field_5ca64a17a8059'),
(399, 11, 'home_page_your_instructor_twitter_link', 'https://www.facebook.com/mehedi0013'),
(400, 11, '_home_page_your_instructor_twitter_link', 'field_5ca64a59a805a'),
(401, 11, 'home_page_your_instructor_google_plus_link', 'https://www.facebook.com/mehedi0013'),
(402, 11, '_home_page_your_instructor_google_plus_link', 'field_5ca64a8ba805b'),
(403, 11, 'home_page_your_instructor_bio_short', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem magnam iure totam deleniti deserunt saepe repellendus quam, voluptatum minus, impedit odit maiores corrupti, omnis ex dignissimos qui! Aliquid, aspernatur fuga!'),
(404, 11, '_home_page_your_instructor_bio_short', 'field_5ca64b10a805e'),
(405, 11, 'home_page_your_instructor_bio_long', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis doloribus, reiciendis laborum a inventore non amet minus consectetur deserunt aliquam quos, expedita modi optio repellat, assumenda est quibusdam recusandae! Dolorum, cum. Aut nulla, aspernatur hic temporibus debitis, ea, illo ipsum quo ratione quas obcaecati dolorem doloremque quod. Sint, ipsam est!\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Laborum saepe obcaecati eum quasi voluptas harum illum fugiat delectus, officiis corrupti amet nemo! Error est numquam dolorum exercitationem sapiente ut molestias velit, aut deleniti unde voluptatum?\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur, magnam! Neque beatae fugit quam veniam totam? Dolorum temporibus ipsum neque laborum consequuntur ab, repellat placeat doloribus voluptate corrupti animi, beatae illum, accusantium enim laudantium mollitia quae incidunt! Iure et quas temporibus libero ullam assumenda. Explicabo?'),
(406, 11, '_home_page_your_instructor_bio_long', 'field_5ca64b46a805f'),
(407, 11, 'home_page_your_instructor_student_count', '41,000+'),
(408, 11, '_home_page_your_instructor_student_count', 'field_5ca64bafa8061'),
(409, 11, 'home_page_your_instructor_revious_count', '786 '),
(410, 11, '_home_page_your_instructor_revious_count', 'field_5ca64be6a8063'),
(411, 11, 'home_page_your_instructor_course_count', '10+'),
(412, 11, '_home_page_your_instructor_course_count', 'field_5ca64be5a8062'),
(413, 117, 'boost_your__income_banner_image', '42'),
(414, 117, '_boost_your__income_banner_image', 'field_5ca10a224a62e'),
(415, 117, 'boost_your_income_title', 'How you can boost your income'),
(416, 117, '_boost_your_income_title', 'field_5ca10bea4a62f'),
(417, 117, 'boost_your_income_description', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur cupiditate pariatur eaque molestiae earum quo architecto aut? Expedita officiis perferendis temporibus reprehenderit assumenda molestias saepe commodi quam incidunt, vero consectetur.'),
(418, 117, '_boost_your_income_description', 'field_5ca10ca54a630'),
(419, 117, 'boost_your_income_reasone_one_title', 'Make money on the site'),
(420, 117, '_boost_your_income_reasone_one_title', 'field_5ca10d5c4a631'),
(421, 117, 'boost_your_income_reasone_one_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(422, 117, '_boost_your_income_reasone_one_description', 'field_5ca10d914a632'),
(423, 117, 'boost_your_income_reasone_two_title', 'Create a full time income'),
(424, 117, '_boost_your_income_reasone_two_title', 'field_5ca10de44a633'),
(425, 117, 'boost_your_income_reasone_two_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(426, 117, '_boost_your_income_reasone_two_description', 'field_5ca10e094a634'),
(427, 117, 'who_should_take_this_course_bannse_image', '48'),
(428, 117, '_who_should_take_this_course_bannse_image', 'field_5ca255a541cd7'),
(429, 117, 'who_should_take_this_course_title', 'Who should take this course'),
(430, 117, '_who_should_take_this_course_title', 'field_5ca2561041cd8'),
(431, 117, 'who_should_take_this_course_deseription', '<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.'),
(432, 117, '_who_should_take_this_course_deseription', 'field_5ca2563a41cd9'),
(433, 117, 'home_page_course_features_banner_image', '50'),
(434, 117, '_home_page_course_features_banner_image', 'field_5ca4e231a0874'),
(435, 117, 'home_page_course_features_title', 'Course Features'),
(436, 117, '_home_page_course_features_title', 'field_5ca4e299a0875'),
(437, 117, 'final_project_feature_title', 'Final Project Features'),
(438, 117, '_final_project_feature_title', 'field_5ca502786bc3f'),
(439, 117, 'final_project_feature_desc', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab, debitis voluptatem! Ullam, esse modi dolor culpa, quasi ab at, quisquam illum fuga minima quo omnis repellat natus odio maxime! Esse asperiores tenetur nulla harum unde odio voluptatibus odit ea vero perferendis nesciunt eum cupiditate, earum dolorum labore laborum dignissimos ab.'),
(440, 117, '_final_project_feature_desc', 'field_5ca5029c6bc40'),
(441, 117, 'home_page_video_features_video', 'https://www.youtube.com/embed/l2BooJEP8aM?start=15'),
(442, 117, '_home_page_video_features_video', 'field_5ca644dccf189'),
(443, 117, 'home_page_your_instructor_title', 'Your Instructore'),
(444, 117, '_home_page_your_instructor_title', 'field_5ca64993a8057'),
(445, 117, 'home_page_your_instructor_name', 'Mehedi Hassan'),
(446, 117, '_home_page_your_instructor_name', 'field_5ca649f9a8058'),
(447, 117, 'home_page_your_instructor_facebook_link', 'https://www.facebook.com/mehedi0013'),
(448, 117, '_home_page_your_instructor_facebook_link', 'field_5ca64a17a8059'),
(449, 117, 'home_page_your_instructor_twitter_link', 'https://www.facebook.com/mehedi0013'),
(450, 117, '_home_page_your_instructor_twitter_link', 'field_5ca64a59a805a'),
(451, 117, 'home_page_your_instructor_google_plus_link', 'https://www.facebook.com/mehedi0013'),
(452, 117, '_home_page_your_instructor_google_plus_link', 'field_5ca64a8ba805b'),
(453, 117, 'home_page_your_instructor_bio_short', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem magnam iure totam deleniti deserunt saepe repellendus quam, voluptatum minus, impedit odit maiores corrupti, omnis ex dignissimos qui! Aliquid, aspernatur fuga!'),
(454, 117, '_home_page_your_instructor_bio_short', 'field_5ca64b10a805e'),
(455, 117, 'home_page_your_instructor_bio_long', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis doloribus, reiciendis laborum a inventore non amet minus consectetur deserunt aliquam quos, expedita modi optio repellat, assumenda est quibusdam recusandae! Dolorum, cum. Aut nulla, aspernatur hic temporibus debitis, ea, illo ipsum quo ratione quas obcaecati dolorem doloremque quod. Sint, ipsam est!\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Laborum saepe obcaecati eum quasi voluptas harum illum fugiat delectus, officiis corrupti amet nemo! Error est numquam dolorum exercitationem sapiente ut molestias velit, aut deleniti unde voluptatum?\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur, magnam! Neque beatae fugit quam veniam totam? Dolorum temporibus ipsum neque laborum consequuntur ab, repellat placeat doloribus voluptate corrupti animi, beatae illum, accusantium enim laudantium mollitia quae incidunt! Iure et quas temporibus libero ullam assumenda. Explicabo?'),
(456, 117, '_home_page_your_instructor_bio_long', 'field_5ca64b46a805f'),
(457, 117, 'home_page_your_instructor_student_count', '41,000+'),
(458, 117, '_home_page_your_instructor_student_count', 'field_5ca64bafa8061'),
(459, 117, 'home_page_your_instructor_revious_count', '786 '),
(460, 117, '_home_page_your_instructor_revious_count', 'field_5ca64be6a8063'),
(461, 117, 'home_page_your_instructor_course_count', '10+'),
(462, 117, '_home_page_your_instructor_course_count', 'field_5ca64be5a8062'),
(463, 118, '_edit_last', '1'),
(464, 118, '_edit_lock', '1554406449:1'),
(465, 11, 'home_page_testimonial_title', 'What people saying about Mehedi'),
(466, 11, '_home_page_testimonial_title', 'field_5ca65b255eff4'),
(467, 120, 'boost_your__income_banner_image', '42'),
(468, 120, '_boost_your__income_banner_image', 'field_5ca10a224a62e'),
(469, 120, 'boost_your_income_title', 'How you can boost your income'),
(470, 120, '_boost_your_income_title', 'field_5ca10bea4a62f'),
(471, 120, 'boost_your_income_description', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur cupiditate pariatur eaque molestiae earum quo architecto aut? Expedita officiis perferendis temporibus reprehenderit assumenda molestias saepe commodi quam incidunt, vero consectetur.'),
(472, 120, '_boost_your_income_description', 'field_5ca10ca54a630'),
(473, 120, 'boost_your_income_reasone_one_title', 'Make money on the site'),
(474, 120, '_boost_your_income_reasone_one_title', 'field_5ca10d5c4a631'),
(475, 120, 'boost_your_income_reasone_one_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(476, 120, '_boost_your_income_reasone_one_description', 'field_5ca10d914a632'),
(477, 120, 'boost_your_income_reasone_two_title', 'Create a full time income'),
(478, 120, '_boost_your_income_reasone_two_title', 'field_5ca10de44a633'),
(479, 120, 'boost_your_income_reasone_two_description', 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Modi voluptates reprehenderit incidunt, quas sed quisquam, sit sequi velit consequatur fugiat voluptate numquam, amet dolor vero distinctio labore similique! Reprehenderit rerum totam consectetur, veritatis maxime exercitationem. Expedita eaque cupiditate odio suscipit.'),
(480, 120, '_boost_your_income_reasone_two_description', 'field_5ca10e094a634'),
(481, 120, 'who_should_take_this_course_bannse_image', '48'),
(482, 120, '_who_should_take_this_course_bannse_image', 'field_5ca255a541cd7'),
(483, 120, 'who_should_take_this_course_title', 'Who should take this course'),
(484, 120, '_who_should_take_this_course_title', 'field_5ca2561041cd8'),
(485, 120, 'who_should_take_this_course_deseription', '<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.\r\n<h3>Lorem ipsum dolor sit amet consectetur.</h3>\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Pariatur asperiores repellendus eveniet iusto unde ullam sit enim deserunt ratione. Pariatur nulla deserunt quidem cupiditate recusandae?\r\n<h3>Lorem, ipsum dolor sit amet consectetur adipisicing elit.</h3>\r\nLorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor, ut esse aut est ipsum error labore excepturi dolores reprehenderit iure commodi odio! Tempora, nobis itaque sequi dolore quia ea! Natus vero itaque commodi iusto!\r\n<h3>Lorem ipsum dolor sit amet.</h3>\r\nLorem ipsum dolor sit amet consectetur, adipisicing elit. Dolorum omnis laudantium a id non obcaecati nobis sit corrupti minus, tenetur libero rerum suscipit! Temporibus nulla animi quaerat quod minima itaque id maxime nostrum fugiat cum? Accusamus quis, error adipisci ipsum itaque aspernatur dolore eos repudiandae.'),
(486, 120, '_who_should_take_this_course_deseription', 'field_5ca2563a41cd9'),
(487, 120, 'home_page_course_features_banner_image', '50'),
(488, 120, '_home_page_course_features_banner_image', 'field_5ca4e231a0874'),
(489, 120, 'home_page_course_features_title', 'Course Features'),
(490, 120, '_home_page_course_features_title', 'field_5ca4e299a0875'),
(491, 120, 'final_project_feature_title', 'Final Project Features'),
(492, 120, '_final_project_feature_title', 'field_5ca502786bc3f'),
(493, 120, 'final_project_feature_desc', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ab, debitis voluptatem! Ullam, esse modi dolor culpa, quasi ab at, quisquam illum fuga minima quo omnis repellat natus odio maxime! Esse asperiores tenetur nulla harum unde odio voluptatibus odit ea vero perferendis nesciunt eum cupiditate, earum dolorum labore laborum dignissimos ab.'),
(494, 120, '_final_project_feature_desc', 'field_5ca5029c6bc40'),
(495, 120, 'home_page_video_features_video', 'https://www.youtube.com/embed/l2BooJEP8aM?start=15'),
(496, 120, '_home_page_video_features_video', 'field_5ca644dccf189'),
(497, 120, 'home_page_your_instructor_title', 'Your Instructore'),
(498, 120, '_home_page_your_instructor_title', 'field_5ca64993a8057'),
(499, 120, 'home_page_your_instructor_name', 'Mehedi Hassan'),
(500, 120, '_home_page_your_instructor_name', 'field_5ca649f9a8058'),
(501, 120, 'home_page_your_instructor_facebook_link', 'https://www.facebook.com/mehedi0013'),
(502, 120, '_home_page_your_instructor_facebook_link', 'field_5ca64a17a8059'),
(503, 120, 'home_page_your_instructor_twitter_link', 'https://www.facebook.com/mehedi0013'),
(504, 120, '_home_page_your_instructor_twitter_link', 'field_5ca64a59a805a'),
(505, 120, 'home_page_your_instructor_google_plus_link', 'https://www.facebook.com/mehedi0013'),
(506, 120, '_home_page_your_instructor_google_plus_link', 'field_5ca64a8ba805b'),
(507, 120, 'home_page_your_instructor_bio_short', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem magnam iure totam deleniti deserunt saepe repellendus quam, voluptatum minus, impedit odit maiores corrupti, omnis ex dignissimos qui! Aliquid, aspernatur fuga!'),
(508, 120, '_home_page_your_instructor_bio_short', 'field_5ca64b10a805e'),
(509, 120, 'home_page_your_instructor_bio_long', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Perspiciatis doloribus, reiciendis laborum a inventore non amet minus consectetur deserunt aliquam quos, expedita modi optio repellat, assumenda est quibusdam recusandae! Dolorum, cum. Aut nulla, aspernatur hic temporibus debitis, ea, illo ipsum quo ratione quas obcaecati dolorem doloremque quod. Sint, ipsam est!\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Laborum saepe obcaecati eum quasi voluptas harum illum fugiat delectus, officiis corrupti amet nemo! Error est numquam dolorum exercitationem sapiente ut molestias velit, aut deleniti unde voluptatum?\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Aspernatur, magnam! Neque beatae fugit quam veniam totam? Dolorum temporibus ipsum neque laborum consequuntur ab, repellat placeat doloribus voluptate corrupti animi, beatae illum, accusantium enim laudantium mollitia quae incidunt! Iure et quas temporibus libero ullam assumenda. Explicabo?'),
(510, 120, '_home_page_your_instructor_bio_long', 'field_5ca64b46a805f'),
(511, 120, 'home_page_your_instructor_student_count', '41,000+'),
(512, 120, '_home_page_your_instructor_student_count', 'field_5ca64bafa8061'),
(513, 120, 'home_page_your_instructor_revious_count', '786 '),
(514, 120, '_home_page_your_instructor_revious_count', 'field_5ca64be6a8063'),
(515, 120, 'home_page_your_instructor_course_count', '10+'),
(516, 120, '_home_page_your_instructor_course_count', 'field_5ca64be5a8062'),
(517, 120, 'home_page_testimonial_title', 'What people saying about Mehedi'),
(518, 120, '_home_page_testimonial_title', 'field_5ca65b255eff4'),
(519, 121, '_edit_last', '1'),
(520, 121, '_edit_lock', '1554406830:1'),
(521, 121, '_thumbnail_id', '28'),
(522, 122, '_edit_last', '1'),
(523, 122, '_edit_lock', '1554406892:1'),
(524, 122, '_thumbnail_id', '35'),
(525, 123, '_edit_last', '1'),
(526, 123, '_edit_lock', '1554406950:1'),
(527, 123, '_thumbnail_id', '56'),
(528, 124, '_edit_last', '1'),
(529, 124, '_edit_lock', '1554412969:1'),
(530, 124, '_thumbnail_id', '57'),
(531, 3, '_wp_trash_meta_status', 'publish'),
(532, 3, '_wp_trash_meta_time', '1554441082'),
(533, 3, '_wp_desired_post_slug', 'privacy-policy'),
(534, 2, '_wp_trash_meta_status', 'publish'),
(535, 2, '_wp_trash_meta_time', '1554441082'),
(536, 2, '_wp_desired_post_slug', 'sample-page'),
(537, 127, '_edit_last', '1'),
(538, 127, '_wp_page_template', 'page-custom_resources_page.php'),
(539, 127, '_edit_lock', '1554485691:1'),
(540, 129, '_menu_item_type', 'post_type'),
(541, 129, '_menu_item_menu_item_parent', '0'),
(542, 129, '_menu_item_object_id', '127'),
(543, 129, '_menu_item_object', 'page'),
(544, 129, '_menu_item_target', ''),
(545, 129, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(546, 129, '_menu_item_xfn', ''),
(547, 129, '_menu_item_url', ''),
(550, 127, '_thumbnail_id', '59'),
(551, 131, '_edit_last', '1'),
(552, 131, '_edit_lock', '1554488150:1'),
(553, 136, '_edit_last', '1'),
(554, 136, '_edit_lock', '1554486753:1'),
(555, 136, 'resources_image', '36'),
(556, 136, '_resources_image', 'field_5ca7936ad0c89'),
(557, 136, 'resources_url', 'https://www.facebook.com/mehedi0013'),
(558, 136, '_resources_url', 'field_5ca7938ed0c8a'),
(559, 136, 'add_button', '1'),
(560, 136, '_add_button', 'field_5ca793d4d0c8b'),
(561, 136, 'button_text', 'Get Start In Facebook'),
(562, 136, '_button_text', 'field_5ca79496d0c8c'),
(563, 137, '_edit_last', '1'),
(564, 137, '_edit_lock', '1554486837:1'),
(565, 137, 'resources_image', '39'),
(566, 137, '_resources_image', 'field_5ca7936ad0c89'),
(567, 137, 'resources_url', 'https://www.google.com/'),
(568, 137, '_resources_url', 'field_5ca7938ed0c8a'),
(569, 137, 'add_button', '1'),
(570, 137, '_add_button', 'field_5ca793d4d0c8b'),
(571, 137, 'button_text', 'Get Start In Google'),
(572, 137, '_button_text', 'field_5ca79496d0c8c'),
(573, 138, '_edit_last', '1'),
(574, 138, '_edit_lock', '1554486908:1'),
(575, 138, 'resources_image', '62'),
(576, 138, '_resources_image', 'field_5ca7936ad0c89'),
(577, 138, 'resources_url', 'https://www.youtube.com/'),
(578, 138, '_resources_url', 'field_5ca7938ed0c8a'),
(579, 138, 'add_button', '1'),
(580, 138, '_add_button', 'field_5ca793d4d0c8b'),
(581, 138, 'button_text', 'Get Start In Youtube'),
(582, 138, '_button_text', 'field_5ca79496d0c8c'),
(583, 140, '_edit_last', '1'),
(584, 140, '_wp_page_template', 'default'),
(585, 140, '_edit_lock', '1554573613:1'),
(586, 142, '_menu_item_type', 'post_type'),
(587, 142, '_menu_item_menu_item_parent', '0'),
(588, 142, '_menu_item_object_id', '140'),
(589, 142, '_menu_item_object', 'page'),
(590, 142, '_menu_item_target', ''),
(591, 142, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(592, 142, '_menu_item_xfn', ''),
(593, 142, '_menu_item_url', ''),
(595, 1, '_edit_lock', '1554665267:1'),
(596, 1, '_edit_last', '1'),
(600, 1, '_thumbnail_id', '40'),
(602, 147, '_edit_last', '1'),
(603, 147, '_edit_lock', '1554582646:1'),
(604, 147, '_thumbnail_id', '40'),
(605, 151, '_edit_last', '1'),
(606, 151, '_edit_lock', '1555616605:1'),
(607, 151, '_wp_page_template', 'page-custom_contact_page.php'),
(608, 153, '_menu_item_type', 'post_type'),
(609, 153, '_menu_item_menu_item_parent', '0'),
(610, 153, '_menu_item_object_id', '151'),
(611, 153, '_menu_item_object', 'page'),
(612, 153, '_menu_item_target', ''),
(613, 153, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(614, 153, '_menu_item_xfn', ''),
(615, 153, '_menu_item_url', ''),
(618, 151, '_thumbnail_id', '60'),
(619, 156, '_form', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit \"Send\"]'),
(620, 156, '_mail', 'a:8:{s:7:\"subject\";s:38:\"Bootstrap 2 Wordpress \"[your-subject]\"\";s:6:\"sender\";s:45:\"Bootstrap 2 Wordpress <mehedi00014@gmail.com>\";s:4:\"body\";s:180:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Bootstrap 2 Wordpress (http://localhost/b2w)\";s:9:\"recipient\";s:21:\"mehedi00014@gmail.com\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}'),
(621, 156, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:38:\"Bootstrap 2 Wordpress \"[your-subject]\"\";s:6:\"sender\";s:45:\"Bootstrap 2 Wordpress <mehedi00014@gmail.com>\";s:4:\"body\";s:122:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Bootstrap 2 Wordpress (http://localhost/b2w)\";s:9:\"recipient\";s:12:\"[your-email]\";s:18:\"additional_headers\";s:31:\"Reply-To: mehedi00014@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";i:0;s:13:\"exclude_blank\";i:0;}'),
(622, 156, '_messages', 'a:8:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";}'),
(623, 156, '_additional_settings', NULL),
(624, 156, '_locale', 'en_US'),
(625, 160, '_form', '<form action=\"\" class=\"clearfix\">\n            <div class=\"row\">\n              <div class=\"col-sm-6\">\n                <div class=\"form-group\">\n                  <label for=\"contact-name\" class=\"sr-only\">Name</label>\n                  [text* text-630 id:contact-name class:form-control class:input-lg placeholder \"Your name\"]\n                </div> <!-- form-group -->\n              </div> <!-- col-sm-6 -->\n              <div class=\"col-sm-6\">\n                <div class=\"form-group\">\n                  <label for=\"contact-email\" class=\"sr-only\">Email</label>\n                  [email* your-email email-687 id:contact-email class:form-control class:input-lg placeholder \"Your email\"]\n                </div> <!-- form-group -->\n              </div> <!-- col-sm-6 -->\n              <div class=\"col-sm-12\">\n                <div class=\"form-group\">\n                  <label for=\"contact-words\" class=\"sr-only\">Message</label>\n                  [textarea* textarea-603 id:contact-words class:from-control class:input-lg placeholder \"&quot;Your message\"]\n                </div> <!-- form-group -->\n              </div> <!-- col-sm-12 -->\n            </div> <!-- row -->\n            [submit class:btn class:btn-info class:btn-lg class:float-right \"Get in touch &raquo;\"]\n          </form> <!-- clearfix -->'),
(626, 160, '_mail', 'a:9:{s:6:\"active\";b:1;s:7:\"subject\";s:38:\"Bootstrap 2 Wordpress \"[your-subject]\"\";s:6:\"sender\";s:45:\"Bootstrap 2 Wordpress <mehedi00014@gmail.com>\";s:9:\"recipient\";s:21:\"mehedi00014@gmail.com\";s:4:\"body\";s:180:\"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Bootstrap 2 Wordpress (http://localhost/b2w)\";s:18:\"additional_headers\";s:22:\"Reply-To: [your-email]\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(627, 160, '_mail_2', 'a:9:{s:6:\"active\";b:0;s:7:\"subject\";s:38:\"Bootstrap 2 Wordpress \"[your-subject]\"\";s:6:\"sender\";s:45:\"Bootstrap 2 Wordpress <mehedi00014@gmail.com>\";s:9:\"recipient\";s:12:\"[your-email]\";s:4:\"body\";s:122:\"Message Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Bootstrap 2 Wordpress (http://localhost/b2w)\";s:18:\"additional_headers\";s:31:\"Reply-To: mehedi00014@gmail.com\";s:11:\"attachments\";s:0:\"\";s:8:\"use_html\";b:0;s:13:\"exclude_blank\";b:0;}'),
(628, 160, '_messages', 'a:23:{s:12:\"mail_sent_ok\";s:45:\"Thank you for your message. It has been sent.\";s:12:\"mail_sent_ng\";s:71:\"There was an error trying to send your message. Please try again later.\";s:16:\"validation_error\";s:61:\"One or more fields have an error. Please check and try again.\";s:4:\"spam\";s:71:\"There was an error trying to send your message. Please try again later.\";s:12:\"accept_terms\";s:69:\"You must accept the terms and conditions before sending your message.\";s:16:\"invalid_required\";s:22:\"The field is required.\";s:16:\"invalid_too_long\";s:22:\"The field is too long.\";s:17:\"invalid_too_short\";s:23:\"The field is too short.\";s:12:\"invalid_date\";s:29:\"The date format is incorrect.\";s:14:\"date_too_early\";s:44:\"The date is before the earliest one allowed.\";s:13:\"date_too_late\";s:41:\"The date is after the latest one allowed.\";s:13:\"upload_failed\";s:46:\"There was an unknown error uploading the file.\";s:24:\"upload_file_type_invalid\";s:49:\"You are not allowed to upload files of this type.\";s:21:\"upload_file_too_large\";s:20:\"The file is too big.\";s:23:\"upload_failed_php_error\";s:38:\"There was an error uploading the file.\";s:14:\"invalid_number\";s:29:\"The number format is invalid.\";s:16:\"number_too_small\";s:47:\"The number is smaller than the minimum allowed.\";s:16:\"number_too_large\";s:46:\"The number is larger than the maximum allowed.\";s:23:\"quiz_answer_not_correct\";s:36:\"The answer to the quiz is incorrect.\";s:17:\"captcha_not_match\";s:31:\"Your entered code is incorrect.\";s:13:\"invalid_email\";s:38:\"The e-mail address entered is invalid.\";s:11:\"invalid_url\";s:19:\"The URL is invalid.\";s:11:\"invalid_tel\";s:32:\"The telephone number is invalid.\";}'),
(629, 160, '_additional_settings', ''),
(630, 160, '_locale', 'en_US'),
(634, 164, '_edit_lock', '1555620969:1'),
(635, 164, '_wp_trash_meta_status', 'publish'),
(636, 164, '_wp_trash_meta_time', '1555620971'),
(637, 165, '_edit_lock', '1555621424:1'),
(638, 165, '_wp_trash_meta_status', 'publish'),
(639, 165, '_wp_trash_meta_time', '1555621426'),
(640, 166, '_edit_lock', '1555621456:1'),
(641, 166, '_wp_trash_meta_status', 'publish'),
(642, 166, '_wp_trash_meta_time', '1555621460'),
(643, 168, '_menu_item_type', 'post_type'),
(644, 168, '_menu_item_menu_item_parent', '0'),
(645, 168, '_menu_item_object_id', '151'),
(646, 168, '_menu_item_object', 'page'),
(647, 168, '_menu_item_target', ''),
(648, 168, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(649, 168, '_menu_item_xfn', ''),
(650, 168, '_menu_item_url', ''),
(652, 169, '_menu_item_type', 'post_type'),
(653, 169, '_menu_item_menu_item_parent', '0'),
(654, 169, '_menu_item_object_id', '140'),
(655, 169, '_menu_item_object', 'page'),
(656, 169, '_menu_item_target', ''),
(657, 169, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(658, 169, '_menu_item_xfn', ''),
(659, 169, '_menu_item_url', ''),
(661, 170, '_menu_item_type', 'post_type'),
(662, 170, '_menu_item_menu_item_parent', '0'),
(663, 170, '_menu_item_object_id', '127'),
(664, 170, '_menu_item_object', 'page'),
(665, 170, '_menu_item_target', ''),
(666, 170, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(667, 170, '_menu_item_xfn', ''),
(668, 170, '_menu_item_url', ''),
(670, 171, '_menu_item_type', 'post_type'),
(671, 171, '_menu_item_menu_item_parent', '0'),
(672, 171, '_menu_item_object_id', '11'),
(673, 171, '_menu_item_object', 'page'),
(674, 171, '_menu_item_target', ''),
(675, 171, '_menu_item_classes', 'a:1:{i:0;s:0:\"\";}'),
(676, 171, '_menu_item_xfn', ''),
(677, 171, '_menu_item_url', ''),
(679, 172, '_menu_item_type', 'custom'),
(680, 172, '_menu_item_menu_item_parent', '0'),
(681, 172, '_menu_item_object_id', '172'),
(682, 172, '_menu_item_object', 'custom'),
(683, 172, '_menu_item_target', ''),
(684, 172, '_menu_item_classes', 'a:1:{i:0;s:11:\"signup-link\";}'),
(685, 172, '_menu_item_xfn', ''),
(686, 172, '_menu_item_url', 'https://google.com');

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_posts`
--

CREATE TABLE `bs2wp_posts` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `post_author` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bs2wp_posts`
--

INSERT INTO `bs2wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2019-03-20 17:21:32', '2019-03-20 17:21:32', '<h3 class=\"faqheader\">About this Lorem Ipsum generator</h3>\r\nYes, there are a lot of Lorem Ipsum generators already. Even when we started with this one in 2009. But all others lack features, or are too limited. Here\'s what Loripsum.net has to offer:\r\n<dl>\r\n 	<dt>API</dt>\r\n 	<dd>Loripsum.net has an API to generate placeholder text to insert it in whatever software/webapp you want. See below for details.</dd>\r\n 	<dt>Customization</dt>\r\n 	<dd>Most generators only output some paragraphs of about the same length. Sometimes you need lists, headings, long paragraphs, etc. The website/magazine that you\'re designing probably isn\'t going to be filled with happy uniform paragraphs, so your placeholder text should reflect that.</dd>\r\n 	<dt>Different text, all the time</dt>\r\n 	<dd>Most generators output the same results every time you request some text. Loripsum.net uses the full text of Cicero\'s \"De finibus bonorum et malorum\" to make sure you get a different placeholder text every single time.</dd>\r\n</dl>', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2019-04-07 19:27:35', '2019-04-07 19:27:35', '', 0, 'http://localhost/b2w/?p=1', 0, 'post', '', 4),
(2, 1, '2019-03-20 17:21:32', '2019-03-20 17:21:32', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://localhost/b2w/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'trash', 'closed', 'open', '', 'sample-page__trashed', '', '', '2019-04-05 05:11:22', '2019-04-05 05:11:22', '', 0, 'http://localhost/b2w/?page_id=2', 0, 'page', '', 0),
(3, 1, '2019-03-20 17:21:32', '2019-03-20 17:21:32', '<h2>Who we are</h2>\r\nOur website address is: http://localhost/b2w.\r\n<h2>What personal data we collect and why we collect it</h2>\r\n<h3>Comments</h3>\r\nWhen visitors leave comments on the site we collect the data shown in the comments form, and also the visitor’s IP address and browser user agent string to help spam detection.\r\n\r\nAn anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.\r\n<h3>Media</h3>\r\nIf you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.\r\n<h3>Contact forms</h3>\r\n<h3>Cookies</h3>\r\nIf you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.\r\n\r\nIf you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.\r\n\r\nWhen you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select \"Remember Me\", your login will persist for two weeks. If you log out of your account, the login cookies will be removed.\r\n\r\nIf you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.\r\n<h3>Embedded content from other websites</h3>\r\nArticles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.\r\n\r\nThese websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.\r\n<h3>Analytics</h3>\r\n<h2>Who we share your data with</h2>\r\n<h2>How long we retain your data</h2>\r\nIf you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.\r\n\r\nFor users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.\r\n<h2>What rights you have over your data</h2>\r\nIf you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.\r\n<h2>Where we send your data</h2>\r\nVisitor comments may be checked through an automated spam detection service.\r\n<h2>Your contact information</h2>\r\n<h2>Additional information</h2>\r\n<h3>How we protect your data</h3>\r\n<h3>What data breach procedures we have in place</h3>\r\n<h3>What third parties we receive data from</h3>\r\n<h3>What automated decision making and/or profiling we do with user data</h3>\r\n<h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'trash', 'closed', 'open', '', 'privacy-policy__trashed', '', '', '2019-04-05 05:11:22', '2019-04-05 05:11:22', '', 0, 'http://localhost/b2w/?page_id=3', 0, 'page', '', 0),
(10, 1, '2019-03-26 12:10:57', '2019-03-26 12:10:57', '<h2>Who we are</h2>\r\nOur website address is: http://localhost/b2w.\r\n<h2>What personal data we collect and why we collect it</h2>\r\n<h3>Comments</h3>\r\nWhen visitors leave comments on the site we collect the data shown in the comments form, and also the visitor’s IP address and browser user agent string to help spam detection.\r\n\r\nAn anonymized string created from your email address (also called a hash) may be provided to the Gravatar service to see if you are using it. The Gravatar service privacy policy is available here: https://automattic.com/privacy/. After approval of your comment, your profile picture is visible to the public in the context of your comment.\r\n<h3>Media</h3>\r\nIf you upload images to the website, you should avoid uploading images with embedded location data (EXIF GPS) included. Visitors to the website can download and extract any location data from images on the website.\r\n<h3>Contact forms</h3>\r\n<h3>Cookies</h3>\r\nIf you leave a comment on our site you may opt-in to saving your name, email address and website in cookies. These are for your convenience so that you do not have to fill in your details again when you leave another comment. These cookies will last for one year.\r\n\r\nIf you have an account and you log in to this site, we will set a temporary cookie to determine if your browser accepts cookies. This cookie contains no personal data and is discarded when you close your browser.\r\n\r\nWhen you log in, we will also set up several cookies to save your login information and your screen display choices. Login cookies last for two days, and screen options cookies last for a year. If you select \"Remember Me\", your login will persist for two weeks. If you log out of your account, the login cookies will be removed.\r\n\r\nIf you edit or publish an article, an additional cookie will be saved in your browser. This cookie includes no personal data and simply indicates the post ID of the article you just edited. It expires after 1 day.\r\n<h3>Embedded content from other websites</h3>\r\nArticles on this site may include embedded content (e.g. videos, images, articles, etc.). Embedded content from other websites behaves in the exact same way as if the visitor has visited the other website.\r\n\r\nThese websites may collect data about you, use cookies, embed additional third-party tracking, and monitor your interaction with that embedded content, including tracking your interaction with the embedded content if you have an account and are logged in to that website.\r\n<h3>Analytics</h3>\r\n<h2>Who we share your data with</h2>\r\n<h2>How long we retain your data</h2>\r\nIf you leave a comment, the comment and its metadata are retained indefinitely. This is so we can recognize and approve any follow-up comments automatically instead of holding them in a moderation queue.\r\n\r\nFor users that register on our website (if any), we also store the personal information they provide in their user profile. All users can see, edit, or delete their personal information at any time (except they cannot change their username). Website administrators can also see and edit that information.\r\n<h2>What rights you have over your data</h2>\r\nIf you have an account on this site, or have left comments, you can request to receive an exported file of the personal data we hold about you, including any data you have provided to us. You can also request that we erase any personal data we hold about you. This does not include any data we are obliged to keep for administrative, legal, or security purposes.\r\n<h2>Where we send your data</h2>\r\nVisitor comments may be checked through an automated spam detection service.\r\n<h2>Your contact information</h2>\r\n<h2>Additional information</h2>\r\n<h3>How we protect your data</h3>\r\n<h3>What data breach procedures we have in place</h3>\r\n<h3>What third parties we receive data from</h3>\r\n<h3>What automated decision making and/or profiling we do with user data</h3>\r\n<h3>Industry regulatory disclosure requirements</h3>', 'Privacy Policy', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2019-03-26 12:10:57', '2019-03-26 12:10:57', '', 3, 'http://localhost/b2w/3-revision-v1/uncategorized/2019/03/', 0, 'revision', '', 0),
(11, 1, '2019-03-26 12:11:22', '2019-03-26 12:11:22', '', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2019-04-04 19:34:46', '2019-04-04 19:34:46', '', 0, 'http://localhost/b2w/?page_id=11', 0, 'page', '', 0),
(12, 1, '2019-03-26 12:11:22', '2019-03-26 12:11:22', '', 'Home', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2019-03-26 12:11:22', '2019-03-26 12:11:22', '', 11, 'http://localhost/b2w/11-revision-v1/uncategorized/2019/03/', 0, 'revision', '', 0),
(13, 1, '2019-03-26 12:11:46', '2019-03-26 12:11:46', ' ', '', '', 'publish', 'closed', 'closed', '', '13', '', '', '2019-05-02 17:24:58', '2019-05-02 17:24:58', '', 0, 'http://localhost/b2w/?p=13', 1, 'nav_menu_item', '', 0),
(17, 1, '2019-03-28 18:14:11', '2019-03-28 18:14:11', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"11\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:4:\"left\";s:21:\"instruction_placement\";s:5:\"field\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";}', 'Home page How you can boost your income Section', 'home-page-how-you-can-boost-your-income-section', 'publish', 'closed', 'closed', '', 'group_5c9d0dcd70250', '', '', '2019-04-01 18:16:36', '2019-04-01 18:16:36', '', 0, 'http://localhost/b2w/?post_type=acf-field-group&#038;p=17', 0, 'acf-field-group', '', 0),
(18, 1, '2019-03-31 19:00:03', '2019-03-31 19:00:03', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:28:\"Upload Your Image For Banner\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Boost Your  Income Banner Image', 'boost_your__income_banner_image', 'publish', 'closed', 'closed', '', 'field_5ca10a224a62e', '', '', '2019-03-31 19:00:03', '2019-03-31 19:00:03', '', 17, 'http://localhost/b2w/?post_type=acf-field&p=18', 0, 'acf-field', '', 0),
(19, 1, '2019-03-31 19:00:03', '2019-03-31 19:00:03', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:21:\"Input Your Title Here\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Boost Your Income Title', 'boost_your_income_title', 'publish', 'closed', 'closed', '', 'field_5ca10bea4a62f', '', '', '2019-03-31 19:00:03', '2019-03-31 19:00:03', '', 17, 'http://localhost/b2w/?post_type=acf-field&p=19', 1, 'acf-field', '', 0),
(20, 1, '2019-03-31 19:00:04', '2019-03-31 19:00:04', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";i:5;s:9:\"new_lines\";s:2:\"br\";}', 'Boost Your Income Description', 'boost_your_income_description', 'publish', 'closed', 'closed', '', 'field_5ca10ca54a630', '', '', '2019-03-31 19:00:04', '2019-03-31 19:00:04', '', 17, 'http://localhost/b2w/?post_type=acf-field&p=20', 2, 'acf-field', '', 0),
(21, 1, '2019-03-31 19:00:04', '2019-03-31 19:00:04', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Boost Your Income Reasone One Title', 'boost_your_income_reasone_one_title', 'publish', 'closed', 'closed', '', 'field_5ca10d5c4a631', '', '', '2019-04-01 17:23:50', '2019-04-01 17:23:50', '', 17, 'http://localhost/b2w/?post_type=acf-field&#038;p=21', 4, 'acf-field', '', 0),
(22, 1, '2019-03-31 19:00:04', '2019-03-31 19:00:04', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Boost Your Income Reasone Two Title', 'boost_your_income_reasone_two_title', 'publish', 'closed', 'closed', '', 'field_5ca10de44a633', '', '', '2019-04-01 17:23:50', '2019-04-01 17:23:50', '', 17, 'http://localhost/b2w/?post_type=acf-field&#038;p=22', 7, 'acf-field', '', 0),
(23, 1, '2019-03-31 19:00:04', '2019-03-31 19:00:04', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";i:4;s:9:\"new_lines\";s:2:\"br\";}', 'Boost Your Income Reasone One Description', 'boost_your_income_reasone_one_description', 'publish', 'closed', 'closed', '', 'field_5ca10d914a632', '', '', '2019-04-01 17:23:50', '2019-04-01 17:23:50', '', 17, 'http://localhost/b2w/?post_type=acf-field&#038;p=23', 5, 'acf-field', '', 0),
(24, 1, '2019-03-31 19:00:04', '2019-03-31 19:00:04', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";i:5;s:9:\"new_lines\";s:2:\"br\";}', 'Boost Your Income Reasone Two Description', 'boost_your_income_reasone_two_description', 'publish', 'closed', 'closed', '', 'field_5ca10e094a634', '', '', '2019-04-01 17:23:50', '2019-04-01 17:23:50', '', 17, 'http://localhost/b2w/?post_type=acf-field&#038;p=24', 8, 'acf-field', '', 0),
(25, 1, '2019-04-01 17:23:49', '2019-04-01 17:23:49', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Reasone #1', 'reasone_1', 'publish', 'closed', 'closed', '', 'field_5ca24885f4180', '', '', '2019-04-01 17:23:49', '2019-04-01 17:23:49', '', 17, 'http://localhost/b2w/?post_type=acf-field&p=25', 3, 'acf-field', '', 0),
(26, 1, '2019-04-01 17:23:50', '2019-04-01 17:23:50', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Reasone #2', 'reasone_2', 'publish', 'closed', 'closed', '', 'field_5ca248edf4181', '', '', '2019-04-01 17:23:50', '2019-04-01 17:23:50', '', 17, 'http://localhost/b2w/?post_type=acf-field&p=26', 6, 'acf-field', '', 0),
(27, 1, '2019-04-01 17:26:51', '2019-04-01 17:26:51', '', 'aj', '', 'inherit', 'open', 'closed', '', 'aj', '', '', '2019-04-01 17:26:51', '2019-04-01 17:26:51', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/aj.png', 0, 'attachment', 'image/png', 0),
(28, 1, '2019-04-01 17:26:52', '2019-04-01 17:26:52', '', 'ben', '', 'inherit', 'open', 'closed', '', 'ben', '', '', '2019-04-01 17:26:52', '2019-04-01 17:26:52', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/ben.png', 0, 'attachment', 'image/png', 0),
(29, 1, '2019-04-01 17:26:53', '2019-04-01 17:26:53', '', 'brad', '', 'inherit', 'open', 'closed', '', 'brad', '', '', '2019-04-01 17:26:53', '2019-04-01 17:26:53', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/brad.png', 0, 'attachment', 'image/png', 0),
(30, 1, '2019-04-01 17:26:54', '2019-04-01 17:26:54', '', 'brad-elvis', '', 'inherit', 'open', 'closed', '', 'brad-elvis', '', '', '2019-04-01 17:26:54', '2019-04-01 17:26:54', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/brad-elvis.png', 0, 'attachment', 'image/png', 0),
(31, 1, '2019-04-01 17:26:55', '2019-04-01 17:26:55', '', 'brennan', '', 'inherit', 'open', 'closed', '', 'brennan', '', '', '2019-04-01 17:26:55', '2019-04-01 17:26:55', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/brennan.jpg', 0, 'attachment', 'image/jpeg', 0),
(32, 1, '2019-04-01 17:26:55', '2019-04-01 17:26:55', '', 'coda2-logo', '', 'inherit', 'open', 'closed', '', 'coda2-logo', '', '', '2019-04-01 17:26:55', '2019-04-01 17:26:55', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/coda2-logo.jpg', 0, 'attachment', 'image/jpeg', 0),
(33, 1, '2019-04-01 17:26:56', '2019-04-01 17:26:56', '', 'dark-bg', '', 'inherit', 'open', 'closed', '', 'dark-bg', '', '', '2019-04-01 17:26:56', '2019-04-01 17:26:56', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/dark-bg.jpg', 0, 'attachment', 'image/jpeg', 0),
(34, 1, '2019-04-01 17:26:57', '2019-04-01 17:26:57', '', 'dropbox-logo', '', 'inherit', 'open', 'closed', '', 'dropbox-logo', '', '', '2019-04-01 17:26:57', '2019-04-01 17:26:57', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/dropbox-logo.jpg', 0, 'attachment', 'image/jpeg', 0),
(35, 1, '2019-04-01 17:26:57', '2019-04-01 17:26:57', '', 'ernest', '', 'inherit', 'open', 'closed', '', 'ernest', '', '', '2019-04-01 17:26:57', '2019-04-01 17:26:57', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/ernest.png', 0, 'attachment', 'image/png', 0),
(36, 1, '2019-04-01 17:26:58', '2019-04-01 17:26:58', '', 'facebook', '', 'inherit', 'open', 'closed', '', 'facebook', '', '', '2019-04-01 17:26:58', '2019-04-01 17:26:58', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/facebook.jpg', 0, 'attachment', 'image/jpeg', 0),
(37, 1, '2019-04-01 17:26:59', '2019-04-01 17:26:59', '', 'favicon', '', 'inherit', 'open', 'closed', '', 'favicon', '', '', '2019-04-01 17:26:59', '2019-04-01 17:26:59', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/favicon.png', 0, 'attachment', 'image/png', 0),
(38, 1, '2019-04-01 17:26:59', '2019-04-01 17:26:59', '', 'generic-bg', '', 'inherit', 'open', 'closed', '', 'generic-bg', '', '', '2019-04-01 17:26:59', '2019-04-01 17:26:59', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/generic-bg.jpg', 0, 'attachment', 'image/jpeg', 0),
(39, 1, '2019-04-01 17:27:01', '2019-04-01 17:27:01', '', 'google', '', 'inherit', 'open', 'closed', '', 'google', '', '', '2019-04-01 17:27:01', '2019-04-01 17:27:01', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/google.jpg', 0, 'attachment', 'image/jpeg', 0),
(40, 1, '2019-04-01 17:27:01', '2019-04-01 17:27:01', '', 'hero-bg', '', 'inherit', 'open', 'closed', '', 'hero-bg', '', '', '2019-04-01 17:27:01', '2019-04-01 17:27:01', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/hero-bg.jpg', 0, 'attachment', 'image/jpeg', 0),
(41, 1, '2019-04-01 17:27:03', '2019-04-01 17:27:03', '', 'hipster-stuff', '', 'inherit', 'open', 'closed', '', 'hipster-stuff', '', '', '2019-04-01 17:27:03', '2019-04-01 17:27:03', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/hipster-stuff.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 1, '2019-04-01 17:27:04', '2019-04-01 17:27:04', '', 'Boost Your Income Banner Icon', '', 'inherit', 'open', 'closed', '', 'icon-boost', '', '', '2019-04-01 17:29:33', '2019-04-01 17:29:33', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/icon-boost.png', 0, 'attachment', 'image/png', 0),
(43, 1, '2019-04-01 17:27:05', '2019-04-01 17:27:05', '', 'icon-cms', '', 'inherit', 'open', 'closed', '', 'icon-cms', '', '', '2019-04-01 17:27:05', '2019-04-01 17:27:05', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/icon-cms.png', 0, 'attachment', 'image/png', 0),
(44, 1, '2019-04-01 17:27:05', '2019-04-01 17:27:05', '', 'icon-code', '', 'inherit', 'open', 'closed', '', 'icon-code', '', '', '2019-04-01 17:27:05', '2019-04-01 17:27:05', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/icon-code.png', 0, 'attachment', 'image/png', 0),
(45, 1, '2019-04-01 17:27:06', '2019-04-01 17:27:06', '', 'icon-computer', '', 'inherit', 'open', 'closed', '', 'icon-computer', '', '', '2019-04-01 17:27:06', '2019-04-01 17:27:06', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/icon-computer.png', 0, 'attachment', 'image/png', 0),
(46, 1, '2019-04-01 17:27:07', '2019-04-01 17:27:07', '', 'icon-design', '', 'inherit', 'open', 'closed', '', 'icon-design', '', '', '2019-04-01 17:27:07', '2019-04-01 17:27:07', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/icon-design.png', 0, 'attachment', 'image/png', 0),
(47, 1, '2019-04-01 17:27:08', '2019-04-01 17:27:08', '', 'icon-features', '', 'inherit', 'open', 'closed', '', 'icon-features', '', '', '2019-04-01 17:27:08', '2019-04-01 17:27:08', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/icon-features.png', 0, 'attachment', 'image/png', 0),
(48, 1, '2019-04-01 17:27:08', '2019-04-01 17:27:08', '', 'Who Should Take This Course Banner Image', '', 'inherit', 'open', 'closed', '', 'icon-pad', '', '', '2019-04-01 18:22:00', '2019-04-01 18:22:00', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/icon-pad.png', 0, 'attachment', 'image/png', 0),
(49, 1, '2019-04-01 17:27:09', '2019-04-01 17:27:09', '', 'icon-resources', '', 'inherit', 'open', 'closed', '', 'icon-resources', '', '', '2019-04-01 17:27:09', '2019-04-01 17:27:09', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/icon-resources.png', 0, 'attachment', 'image/png', 0),
(50, 1, '2019-04-01 17:27:09', '2019-04-01 17:27:09', '', 'course_features', '', 'inherit', 'open', 'closed', '', 'icon-rocket', '', '', '2019-04-03 17:57:12', '2019-04-03 17:57:12', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/icon-rocket.png', 0, 'attachment', 'image/png', 0),
(51, 1, '2019-04-01 17:27:10', '2019-04-01 17:27:10', '', 'icon-sprite', '', 'inherit', 'open', 'closed', '', 'icon-sprite', '', '', '2019-04-01 17:27:10', '2019-04-01 17:27:10', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/icon-sprite.png', 0, 'attachment', 'image/png', 0),
(52, 1, '2019-04-01 17:27:11', '2019-04-01 17:27:11', '', 'icon-testimonials', '', 'inherit', 'open', 'closed', '', 'icon-testimonials', '', '', '2019-04-01 17:27:11', '2019-04-01 17:27:11', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/icon-testimonials.png', 0, 'attachment', 'image/png', 0),
(53, 1, '2019-04-01 17:27:11', '2019-04-01 17:27:11', '', 'justhost-logo', '', 'inherit', 'open', 'closed', '', 'justhost-logo', '', '', '2019-04-01 17:27:11', '2019-04-01 17:27:11', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/justhost-logo.jpg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2019-04-01 17:27:12', '2019-04-01 17:27:12', '', 'logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2019-04-01 17:27:12', '2019-04-01 17:27:12', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/logo.png', 0, 'attachment', 'image/png', 0),
(55, 1, '2019-04-01 17:27:13', '2019-04-01 17:27:13', '', 'logo-badge', '', 'inherit', 'open', 'closed', '', 'logo-badge', '', '', '2019-04-01 17:27:13', '2019-04-01 17:27:13', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/logo-badge.png', 0, 'attachment', 'image/png', 0),
(56, 1, '2019-04-01 17:27:13', '2019-04-01 17:27:13', '', 'mehedi', '', 'inherit', 'open', 'closed', '', 'mehedi', '', '', '2019-04-01 17:27:13', '2019-04-01 17:27:13', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/mehedi.jpg', 0, 'attachment', 'image/jpeg', 0),
(57, 1, '2019-04-01 17:27:15', '2019-04-01 17:27:15', '', 'mehedi', '', 'inherit', 'open', 'closed', '', 'mehedi-2', '', '', '2019-04-01 17:27:15', '2019-04-01 17:27:15', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/mehedi.png', 0, 'attachment', 'image/png', 0),
(58, 1, '2019-04-01 17:27:16', '2019-04-01 17:27:16', '', 'mehedi_bg', '', 'inherit', 'open', 'closed', '', 'mehedi_bg', '', '', '2019-04-01 17:27:16', '2019-04-01 17:27:16', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/mehedi_bg.jpg', 0, 'attachment', 'image/jpeg', 0),
(59, 1, '2019-04-01 17:27:16', '2019-04-01 17:27:16', '', 'stuff-bg', '', 'inherit', 'open', 'closed', '', 'stuff-bg', '', '', '2019-04-01 17:27:16', '2019-04-01 17:27:16', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/stuff-bg.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2019-04-01 17:27:18', '2019-04-01 17:27:18', '', 'stuff-feature', '', 'inherit', 'open', 'closed', '', 'stuff-feature', '', '', '2019-04-01 17:27:18', '2019-04-01 17:27:18', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/stuff-feature.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2019-04-01 17:27:19', '2019-04-01 17:27:19', '', 'tile', '', 'inherit', 'open', 'closed', '', 'tile', '', '', '2019-04-01 17:27:19', '2019-04-01 17:27:19', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/tile.jpg', 0, 'attachment', 'image/jpeg', 0),
(62, 1, '2019-04-01 17:27:20', '2019-04-01 17:27:20', '', 'youtube', '', 'inherit', 'open', 'closed', '', 'youtube', '', '', '2019-04-01 17:27:20', '2019-04-01 17:27:20', '', 11, 'http://localhost/b2w/wp-content/uploads/2019/04/youtube.jpg', 0, 'attachment', 'image/jpeg', 0),
(63, 1, '2019-04-01 17:30:56', '2019-04-01 17:30:56', '', 'Home', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2019-04-01 17:30:56', '2019-04-01 17:30:56', '', 11, 'http://localhost/b2w/11-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(64, 1, '2019-04-01 18:12:26', '2019-04-01 18:12:26', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"11\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:4:\"left\";s:21:\"instruction_placement\";s:5:\"field\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";}', 'Home Page Who should take this course section', 'home-page-who-should-take-this-course-section', 'publish', 'closed', 'closed', '', 'group_5ca2541ae9049', '', '', '2019-04-01 18:43:55', '2019-04-01 18:43:55', '', 0, 'http://localhost/b2w/?post_type=acf-field-group&#038;p=64', 0, 'acf-field-group', '', 0),
(65, 1, '2019-04-01 18:21:01', '2019-04-01 18:21:01', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Who Should Take This Course Bannse Image', 'who_should_take_this_course_bannse_image', 'publish', 'closed', 'closed', '', 'field_5ca255a541cd7', '', '', '2019-04-01 18:21:01', '2019-04-01 18:21:01', '', 64, 'http://localhost/b2w/?post_type=acf-field&p=65', 0, 'acf-field', '', 0),
(66, 1, '2019-04-01 18:21:01', '2019-04-01 18:21:01', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Who Should Take This Course Title', 'who_should_take_this_course_title', 'publish', 'closed', 'closed', '', 'field_5ca2561041cd8', '', '', '2019-04-01 18:21:01', '2019-04-01 18:21:01', '', 64, 'http://localhost/b2w/?post_type=acf-field&p=66', 1, 'acf-field', '', 0),
(67, 1, '2019-04-01 18:21:02', '2019-04-01 18:21:02', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:5:\"basic\";s:12:\"media_upload\";i:0;s:5:\"delay\";i:0;}', 'Who Should Take This Course Deseription', 'who_should_take_this_course_deseription', 'publish', 'closed', 'closed', '', 'field_5ca2563a41cd9', '', '', '2019-04-01 18:21:02', '2019-04-01 18:21:02', '', 64, 'http://localhost/b2w/?post_type=acf-field&p=67', 2, 'acf-field', '', 0),
(68, 1, '2019-04-01 18:23:58', '2019-04-01 18:23:58', '', 'Home', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2019-04-01 18:23:58', '2019-04-01 18:23:58', '', 11, 'http://localhost/b2w/11-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(69, 1, '2019-04-01 18:40:34', '2019-04-01 18:40:34', '', 'Home', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2019-04-01 18:40:34', '2019-04-01 18:40:34', '', 11, 'http://localhost/b2w/11-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(73, 1, '2019-04-03 16:44:30', '2019-04-03 16:44:30', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"11\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:4:\"left\";s:21:\"instruction_placement\";s:5:\"field\";s:14:\"hide_on_screen\";a:1:{i:0;s:11:\"the_content\";}s:11:\"description\";s:0:\"\";}', 'Home page Course Features Section', 'home-page-course-features-section', 'publish', 'closed', 'closed', '', 'group_5ca4e1e0dcf32', '', '', '2019-04-03 18:03:57', '2019-04-03 18:03:57', '', 0, 'http://localhost/b2w/?post_type=acf-field-group&#038;p=73', 0, 'acf-field-group', '', 0),
(74, 1, '2019-04-03 16:44:30', '2019-04-03 16:44:30', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Home Page Course Features Banner Image', 'home_page_course_features_banner_image', 'publish', 'closed', 'closed', '', 'field_5ca4e231a0874', '', '', '2019-04-03 16:44:30', '2019-04-03 16:44:30', '', 73, 'http://localhost/b2w/?post_type=acf-field&p=74', 0, 'acf-field', '', 0),
(75, 1, '2019-04-03 16:44:30', '2019-04-03 16:44:30', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Home Page Course Features Title', 'home_page_course_features_title', 'publish', 'closed', 'closed', '', 'field_5ca4e299a0875', '', '', '2019-04-03 16:44:30', '2019-04-03 16:44:30', '', 73, 'http://localhost/b2w/?post_type=acf-field&p=75', 1, 'acf-field', '', 0),
(76, 1, '2019-04-03 16:54:58', '2019-04-03 16:54:58', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:15:\"course_features\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:4:\"left\";s:21:\"instruction_placement\";s:5:\"field\";s:14:\"hide_on_screen\";a:15:{i:0;s:9:\"permalink\";i:1;s:11:\"the_content\";i:2;s:7:\"excerpt\";i:3;s:13:\"custom_fields\";i:4;s:10:\"discussion\";i:5;s:8:\"comments\";i:6;s:9:\"revisions\";i:7;s:4:\"slug\";i:8;s:6:\"author\";i:9;s:6:\"format\";i:10;s:15:\"page_attributes\";i:11;s:14:\"featured_image\";i:12;s:10:\"categories\";i:13;s:4:\"tags\";i:14;s:15:\"send-trackbacks\";}s:11:\"description\";s:0:\"\";}', 'Home page Course Features Section For Course Features Post', 'home-page-course-features-section-for-course-features-post', 'publish', 'closed', 'closed', '', 'group_5ca4e3d720e17', '', '', '2019-04-03 18:47:24', '2019-04-03 18:47:24', '', 0, 'http://localhost/b2w/?post_type=acf-field-group&#038;p=76', 0, 'acf-field-group', '', 0),
(77, 1, '2019-04-03 16:54:58', '2019-04-03 16:54:58', 'a:12:{s:4:\"type\";s:5:\"radio\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"choices\";a:6:{s:14:\"ci ci-computer\";s:8:\"Computer\";s:11:\"ci ci-watch\";s:5:\"Watch\";s:14:\"ci ci-calender\";s:8:\"Calender\";s:15:\"ci ci-community\";s:9:\"Community\";s:16:\"ci ci-instructor\";s:10:\"Instructor\";s:12:\"ci ci-device\";s:6:\"Device\";}s:10:\"allow_null\";i:1;s:12:\"other_choice\";i:0;s:13:\"default_value\";s:0:\"\";s:6:\"layout\";s:8:\"vertical\";s:13:\"return_format\";s:5:\"value\";s:17:\"save_other_choice\";i:0;}', 'Course Features Icon', 'course_features_icon', 'publish', 'closed', 'closed', '', 'field_5ca4e3f8227f8', '', '', '2019-04-03 16:57:29', '2019-04-03 16:57:29', '', 76, 'http://localhost/b2w/?post_type=acf-field&#038;p=77', 0, 'acf-field', '', 0),
(85, 1, '2019-04-03 17:51:37', '2019-04-03 17:51:37', '', 'Lifetime access to 80+ courses', '', 'publish', 'closed', 'closed', '', 'lifetime-access-to-80-courses', '', '', '2019-04-03 17:51:37', '2019-04-03 17:51:37', '', 0, 'http://localhost/b2w/?post_type=course_features&#038;p=85', 0, 'course_features', '', 0),
(86, 1, '2019-04-03 17:52:05', '2019-04-03 17:52:05', '', '10+ Hours HD video content', '', 'publish', 'closed', 'closed', '', '10-hours-hd-video-content', '', '', '2019-04-03 17:52:05', '2019-04-03 17:52:05', '', 0, 'http://localhost/b2w/?post_type=course_features&#038;p=86', 0, 'course_features', '', 0),
(87, 1, '2019-04-03 17:52:35', '2019-04-03 17:52:35', '', '30 days money back guarantee', '', 'publish', 'closed', 'closed', '', '30-days-money-back-guarantee', '', '', '2019-04-03 17:52:35', '2019-04-03 17:52:35', '', 0, 'http://localhost/b2w/?post_type=course_features&#038;p=87', 0, 'course_features', '', 0),
(88, 1, '2019-04-03 17:52:54', '2019-04-03 17:52:54', '', 'Access to community of like middle student', '', 'publish', 'closed', 'closed', '', 'access-to-community-of-like-middle-student', '', '', '2019-04-03 17:52:54', '2019-04-03 17:52:54', '', 0, 'http://localhost/b2w/?post_type=course_features&#038;p=88', 0, 'course_features', '', 0),
(89, 1, '2019-04-03 17:53:54', '2019-04-03 17:53:54', '', 'Director Access to the Instructor', '', 'publish', 'closed', 'closed', '', 'director-access-to-the-instructor', '', '', '2019-04-03 17:53:54', '2019-04-03 17:53:54', '', 0, 'http://localhost/b2w/?post_type=course_features&#038;p=89', 0, 'course_features', '', 0),
(90, 1, '2019-04-03 17:54:32', '2019-04-03 17:54:32', '', 'Accessible content to your mobile device', '', 'publish', 'closed', 'closed', '', 'accessible-content-to-your-mobile-device', '', '', '2019-04-03 17:54:32', '2019-04-03 17:54:32', '', 0, 'http://localhost/b2w/?post_type=course_features&#038;p=90', 0, 'course_features', '', 0),
(91, 1, '2019-04-03 17:57:31', '2019-04-03 17:57:31', '', 'Home', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2019-04-03 17:57:31', '2019-04-03 17:57:31', '', 11, 'http://localhost/b2w/11-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(92, 1, '2019-04-03 18:04:34', '2019-04-03 18:04:34', '', 'Home', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2019-04-03 18:04:34', '2019-04-03 18:04:34', '', 11, 'http://localhost/b2w/11-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(93, 1, '2019-04-03 19:01:14', '2019-04-03 19:01:14', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"11\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:4:\"left\";s:21:\"instruction_placement\";s:5:\"field\";s:14:\"hide_on_screen\";a:14:{i:0;s:11:\"the_content\";i:1;s:7:\"excerpt\";i:2;s:13:\"custom_fields\";i:3;s:10:\"discussion\";i:4;s:8:\"comments\";i:5;s:9:\"revisions\";i:6;s:4:\"slug\";i:7;s:6:\"author\";i:8;s:6:\"format\";i:9;s:15:\"page_attributes\";i:10;s:14:\"featured_image\";i:11;s:10:\"categories\";i:12;s:4:\"tags\";i:13;s:15:\"send-trackbacks\";}s:11:\"description\";s:0:\"\";}', 'Home Page Final Project Features Section', 'home-page-final-project-features-section', 'publish', 'closed', 'closed', '', 'group_5ca5025e15182', '', '', '2019-04-03 19:01:15', '2019-04-03 19:01:15', '', 0, 'http://localhost/b2w/?post_type=acf-field-group&#038;p=93', 0, 'acf-field-group', '', 0),
(94, 1, '2019-04-03 19:01:14', '2019-04-03 19:01:14', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Final Project Feature Title', 'final_project_feature_title', 'publish', 'closed', 'closed', '', 'field_5ca502786bc3f', '', '', '2019-04-03 19:01:14', '2019-04-03 19:01:14', '', 93, 'http://localhost/b2w/?post_type=acf-field&p=94', 0, 'acf-field', '', 0),
(95, 1, '2019-04-03 19:01:15', '2019-04-03 19:01:15', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:0:\"\";}', 'Final Project Feature Desc', 'final_project_feature_desc', 'publish', 'closed', 'closed', '', 'field_5ca5029c6bc40', '', '', '2019-04-03 19:01:15', '2019-04-03 19:01:15', '', 93, 'http://localhost/b2w/?post_type=acf-field&p=95', 1, 'acf-field', '', 0),
(96, 1, '2019-04-03 19:03:07', '2019-04-03 19:03:07', '', 'Home', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2019-04-03 19:03:07', '2019-04-03 19:03:07', '', 11, 'http://localhost/b2w/11-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(97, 1, '2019-04-03 19:13:19', '2019-04-03 19:13:19', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, cumque!', 'Sexy and Modren Desing', '', 'publish', 'closed', 'closed', '', 'sexy-and-modren-desing', '', '', '2019-04-03 19:13:19', '2019-04-03 19:13:19', '', 0, 'http://localhost/b2w/?post_type=project_features&#038;p=97', 0, 'project_features', '', 0),
(98, 1, '2019-04-03 19:13:57', '2019-04-03 19:13:57', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, cumque!', 'Quality html5 and css3', '', 'publish', 'closed', 'closed', '', 'quality-html5-and-css3', '', '', '2019-04-03 19:13:57', '2019-04-03 19:13:57', '', 0, 'http://localhost/b2w/?post_type=project_features&#038;p=98', 0, 'project_features', '', 0),
(99, 1, '2019-04-03 19:14:35', '2019-04-03 19:14:35', 'Lorem ipsum dolor sit amet consectetur adipisicing elit. Excepturi, cumque!', 'Easly to Use CMS', '', 'publish', 'closed', 'closed', '', 'easly-to-use-cms', '', '', '2019-04-03 19:14:35', '2019-04-03 19:14:35', '', 0, 'http://localhost/b2w/?post_type=project_features&#038;p=99', 0, 'project_features', '', 0),
(100, 1, '2019-04-04 17:57:12', '2019-04-04 17:57:12', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"11\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:4:\"left\";s:21:\"instruction_placement\";s:5:\"field\";s:14:\"hide_on_screen\";a:14:{i:0;s:11:\"the_content\";i:1;s:7:\"excerpt\";i:2;s:13:\"custom_fields\";i:3;s:10:\"discussion\";i:4;s:8:\"comments\";i:5;s:9:\"revisions\";i:6;s:4:\"slug\";i:7;s:6:\"author\";i:8;s:6:\"format\";i:9;s:15:\"page_attributes\";i:10;s:14:\"featured_image\";i:11;s:10:\"categories\";i:12;s:4:\"tags\";i:13;s:15:\"send-trackbacks\";}s:11:\"description\";s:0:\"\";}', 'Home page video features section', 'home-page-video-features-section', 'publish', 'closed', 'closed', '', 'group_5ca644aeee313', '', '', '2019-04-04 18:01:04', '2019-04-04 18:01:04', '', 0, 'http://localhost/b2w/?post_type=acf-field-group&#038;p=100', 0, 'acf-field-group', '', 0),
(101, 1, '2019-04-04 17:57:12', '2019-04-04 17:57:12', 'a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}', 'Home page video features video', 'home_page_video_features_video', 'publish', 'closed', 'closed', '', 'field_5ca644dccf189', '', '', '2019-04-04 18:01:04', '2019-04-04 18:01:04', '', 100, 'http://localhost/b2w/?post_type=acf-field&#038;p=101', 0, 'acf-field', '', 0),
(102, 1, '2019-04-04 18:01:47', '2019-04-04 18:01:47', '', 'Home', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2019-04-04 18:01:47', '2019-04-04 18:01:47', '', 11, 'http://localhost/b2w/11-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(103, 1, '2019-04-04 18:27:06', '2019-04-04 18:27:06', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"11\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:4:\"left\";s:21:\"instruction_placement\";s:5:\"field\";s:14:\"hide_on_screen\";a:14:{i:0;s:11:\"the_content\";i:1;s:7:\"excerpt\";i:2;s:13:\"custom_fields\";i:3;s:10:\"discussion\";i:4;s:8:\"comments\";i:5;s:9:\"revisions\";i:6;s:4:\"slug\";i:7;s:6:\"author\";i:8;s:6:\"format\";i:9;s:15:\"page_attributes\";i:10;s:14:\"featured_image\";i:11;s:10:\"categories\";i:12;s:4:\"tags\";i:13;s:15:\"send-trackbacks\";}s:11:\"description\";s:0:\"\";}', 'Home Page Your Instructor Section', 'home-page-your-instructor-section', 'publish', 'closed', 'closed', '', 'group_5ca6497c7d794', '', '', '2019-04-04 19:19:34', '2019-04-04 19:19:34', '', 0, 'http://localhost/b2w/?post_type=acf-field-group&#038;p=103', 0, 'acf-field-group', '', 0),
(104, 1, '2019-04-04 18:27:07', '2019-04-04 18:27:07', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Home Page Your Instructor Title', 'home_page_your_instructor_title', 'publish', 'closed', 'closed', '', 'field_5ca64993a8057', '', '', '2019-04-04 18:27:07', '2019-04-04 18:27:07', '', 103, 'http://localhost/b2w/?post_type=acf-field&p=104', 0, 'acf-field', '', 0),
(105, 1, '2019-04-04 18:27:07', '2019-04-04 18:27:07', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Home Page Your Instructor Name', 'home_page_your_instructor_name', 'publish', 'closed', 'closed', '', 'field_5ca649f9a8058', '', '', '2019-04-04 18:27:07', '2019-04-04 18:27:07', '', 103, 'http://localhost/b2w/?post_type=acf-field&p=105', 1, 'acf-field', '', 0),
(106, 1, '2019-04-04 18:27:07', '2019-04-04 18:27:07', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Social Media Link', 'social_media_link', 'publish', 'closed', 'closed', '', 'field_5ca64aa4a805c', '', '', '2019-04-04 18:27:07', '2019-04-04 18:27:07', '', 103, 'http://localhost/b2w/?post_type=acf-field&p=106', 2, 'acf-field', '', 0),
(107, 1, '2019-04-04 18:27:07', '2019-04-04 18:27:07', 'a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}', 'Home Page Your Instructor Facebook Link', 'home_page_your_instructor_facebook_link', 'publish', 'closed', 'closed', '', 'field_5ca64a17a8059', '', '', '2019-04-04 18:27:07', '2019-04-04 18:27:07', '', 103, 'http://localhost/b2w/?post_type=acf-field&p=107', 3, 'acf-field', '', 0),
(108, 1, '2019-04-04 18:27:07', '2019-04-04 18:27:07', 'a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}', 'Home Page Your Instructor Twitter Link', 'home_page_your_instructor_twitter_link', 'publish', 'closed', 'closed', '', 'field_5ca64a59a805a', '', '', '2019-04-04 18:27:07', '2019-04-04 18:27:07', '', 103, 'http://localhost/b2w/?post_type=acf-field&p=108', 4, 'acf-field', '', 0),
(109, 1, '2019-04-04 18:27:07', '2019-04-04 18:27:07', 'a:7:{s:4:\"type\";s:3:\"url\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";}', 'Home Page Your Instructor Google Plus Link', 'home_page_your_instructor_google_plus_link', 'publish', 'closed', 'closed', '', 'field_5ca64a8ba805b', '', '', '2019-04-04 18:27:07', '2019-04-04 18:27:07', '', 103, 'http://localhost/b2w/?post_type=acf-field&p=109', 5, 'acf-field', '', 0);
INSERT INTO `bs2wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(110, 1, '2019-04-04 18:27:08', '2019-04-04 18:27:08', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Home Page Your Instructor Bio', 'home_page_your_instructor_bio', 'publish', 'closed', 'closed', '', 'field_5ca64af8a805d', '', '', '2019-04-04 18:27:08', '2019-04-04 18:27:08', '', 103, 'http://localhost/b2w/?post_type=acf-field&p=110', 6, 'acf-field', '', 0),
(111, 1, '2019-04-04 18:27:08', '2019-04-04 18:27:08', 'a:10:{s:4:\"type\";s:8:\"textarea\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";s:4:\"rows\";s:0:\"\";s:9:\"new_lines\";s:2:\"br\";}', 'Home Page Your Instructor Bio Short', 'home_page_your_instructor_bio_short', 'publish', 'closed', 'closed', '', 'field_5ca64b10a805e', '', '', '2019-04-04 18:27:08', '2019-04-04 18:27:08', '', 103, 'http://localhost/b2w/?post_type=acf-field&p=111', 7, 'acf-field', '', 0),
(112, 1, '2019-04-04 18:27:08', '2019-04-04 18:27:08', 'a:10:{s:4:\"type\";s:7:\"wysiwyg\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:4:\"tabs\";s:3:\"all\";s:7:\"toolbar\";s:4:\"full\";s:12:\"media_upload\";i:1;s:5:\"delay\";i:0;}', 'Home Page Your Instructor Bio Long', 'home_page_your_instructor_bio_long', 'publish', 'closed', 'closed', '', 'field_5ca64b46a805f', '', '', '2019-04-04 18:27:08', '2019-04-04 18:27:08', '', 103, 'http://localhost/b2w/?post_type=acf-field&p=112', 8, 'acf-field', '', 0),
(113, 1, '2019-04-04 18:27:08', '2019-04-04 18:27:08', 'a:7:{s:4:\"type\";s:3:\"tab\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:9:\"placement\";s:3:\"top\";s:8:\"endpoint\";i:0;}', 'Count Number', 'count_number', 'publish', 'closed', 'closed', '', 'field_5ca64b8fa8060', '', '', '2019-04-04 18:27:08', '2019-04-04 18:27:08', '', 103, 'http://localhost/b2w/?post_type=acf-field&p=113', 9, 'acf-field', '', 0),
(114, 1, '2019-04-04 18:27:08', '2019-04-04 18:27:08', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Home Page Your Instructor Student Count', 'home_page_your_instructor_student_count', 'publish', 'closed', 'closed', '', 'field_5ca64bafa8061', '', '', '2019-04-04 19:19:33', '2019-04-04 19:19:33', '', 103, 'http://localhost/b2w/?post_type=acf-field&#038;p=114', 10, 'acf-field', '', 0),
(115, 1, '2019-04-04 18:27:08', '2019-04-04 18:27:08', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Home Page Your Instructor Revious Count', 'home_page_your_instructor_revious_count', 'publish', 'closed', 'closed', '', 'field_5ca64be6a8063', '', '', '2019-04-04 19:19:33', '2019-04-04 19:19:33', '', 103, 'http://localhost/b2w/?post_type=acf-field&#038;p=115', 11, 'acf-field', '', 0),
(116, 1, '2019-04-04 18:27:08', '2019-04-04 18:27:08', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Home Page Your Instructor Course Count', 'home_page_your_instructor_course_count', 'publish', 'closed', 'closed', '', 'field_5ca64be5a8062', '', '', '2019-04-04 19:19:34', '2019-04-04 19:19:34', '', 103, 'http://localhost/b2w/?post_type=acf-field&#038;p=116', 12, 'acf-field', '', 0),
(117, 1, '2019-04-04 19:22:01', '2019-04-04 19:22:01', '', 'Home', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2019-04-04 19:22:01', '2019-04-04 19:22:01', '', 11, 'http://localhost/b2w/11-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(118, 1, '2019-04-04 19:30:13', '2019-04-04 19:30:13', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:4:\"page\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:2:\"11\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:4:\"left\";s:21:\"instruction_placement\";s:5:\"field\";s:14:\"hide_on_screen\";a:14:{i:0;s:11:\"the_content\";i:1;s:7:\"excerpt\";i:2;s:13:\"custom_fields\";i:3;s:10:\"discussion\";i:4;s:8:\"comments\";i:5;s:9:\"revisions\";i:6;s:4:\"slug\";i:7;s:6:\"author\";i:8;s:6:\"format\";i:9;s:15:\"page_attributes\";i:10;s:14:\"featured_image\";i:11;s:10:\"categories\";i:12;s:4:\"tags\";i:13;s:15:\"send-trackbacks\";}s:11:\"description\";s:0:\"\";}', 'Home page testimonial Section', 'home-page-testimonial-section', 'publish', 'closed', 'closed', '', 'group_5ca65b085c276', '', '', '2019-04-04 19:34:37', '2019-04-04 19:34:37', '', 0, 'http://localhost/b2w/?post_type=acf-field-group&#038;p=118', 0, 'acf-field-group', '', 0),
(119, 1, '2019-04-04 19:30:13', '2019-04-04 19:30:13', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Home page testimonial title', 'home_page_testimonial_title', 'publish', 'closed', 'closed', '', 'field_5ca65b255eff4', '', '', '2019-04-04 19:34:37', '2019-04-04 19:34:37', '', 118, 'http://localhost/b2w/?post_type=acf-field&#038;p=119', 0, 'acf-field', '', 0),
(120, 1, '2019-04-04 19:33:39', '2019-04-04 19:33:39', '', 'Home', '', 'inherit', 'closed', 'closed', '', '11-revision-v1', '', '', '2019-04-04 19:33:39', '2019-04-04 19:33:39', '', 11, 'http://localhost/b2w/11-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(121, 1, '2019-04-04 19:42:49', '2019-04-04 19:42:49', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius voluptates sit illo, tenetur sed, magnam, beatae nesciunt quidem neque corporis minima laudantium? Facere eaque commodi eius error ex sed perspiciatis soluta placeat nesciunt natus, harum asperiores recusandae ipsum obcaecati sunt quaerat est nihil dignissimos deleniti iusto magni ut explicabo architecto! Ipsa voluptatum voluptates dolor! Consequatur rem totam facere voluptates temporibus facilis eos omnis eaque porro. Accusamus hic sunt tempora quam?', '— Lorem, ipsum dolor sit amet consectetur adipisicing elit. Error, maxime?', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-consectetur-adipisicing-elit-error-maxime', '', '', '2019-04-04 19:42:49', '2019-04-04 19:42:49', '', 0, 'http://localhost/b2w/?post_type=testimonial&#038;p=121', 0, 'testimonial', '', 0),
(122, 1, '2019-04-04 19:43:48', '2019-04-04 19:43:48', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius voluptates sit illo, tenetur sed, magnam, beatae nesciunt quidem neque corporis minima laudantium? Facere eaque commodi eius error ex sed perspiciatis soluta placeat nesciunt natus, harum asperiores recusandae ipsum obcaecati sunt quaerat est nihil dignissimos deleniti iusto magni ut explicabo architecto! Ipsa voluptatum voluptates dolor! Consequatur rem totam facere voluptates temporibus facilis eos omnis eaque porro. Accusamus hic sunt tempora quam?<cite></cite>', '— Lorem, ipsum dolor sit amet consectetur adipisicing elit. Error, maxime?', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-consectetur-adipisicing-elit-error-maxime-2', '', '', '2019-04-04 19:43:48', '2019-04-04 19:43:48', '', 0, 'http://localhost/b2w/?post_type=testimonial&#038;p=122', 0, 'testimonial', '', 0),
(123, 1, '2019-04-04 19:44:41', '2019-04-04 19:44:41', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius voluptates sit illo, tenetur sed, magnam, beatae nesciunt quidem neque corporis minima laudantium? Facere eaque commodi eius error ex sed perspiciatis soluta placeat nesciunt natus, harum asperiores recusandae ipsum obcaecati sunt quaerat est nihil dignissimos deleniti iusto magni ut explicabo architecto! Ipsa voluptatum voluptates dolor! Consequatur rem totam facere voluptates temporibus facilis eos omnis eaque porro. Accusamus hic sunt tempora quam?<cite></cite>', '— Lorem, ipsum dolor sit amet consectetur adipisicing elit. Error, maxime?', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-consectetur-adipisicing-elit-error-maxime-3', '', '', '2019-04-04 19:44:52', '2019-04-04 19:44:52', '', 0, 'http://localhost/b2w/?post_type=testimonial&#038;p=123', 0, 'testimonial', '', 0),
(124, 1, '2019-04-04 19:45:05', '2019-04-04 19:45:05', 'Lorem ipsum, dolor sit amet consectetur adipisicing elit. Eius voluptates sit illo, tenetur sed, magnam, beatae nesciunt quidem neque corporis minima laudantium? Facere eaque commodi eius error ex sed perspiciatis soluta placeat nesciunt natus, harum asperiores recusandae ipsum obcaecati sunt quaerat est nihil dignissimos deleniti iusto magni ut explicabo architecto! Ipsa voluptatum voluptates dolor! Consequatur rem totam facere voluptates temporibus facilis eos omnis eaque porro. Accusamus hic sunt tempora quam?', '— Lorem, ipsum dolor sit amet consectetur adipisicing elit. Error, maxime?', '', 'publish', 'closed', 'closed', '', 'lorem-ipsum-dolor-sit-amet-consectetur-adipisicing-elit-error-maxime-4', '', '', '2019-04-04 20:28:24', '2019-04-04 20:28:24', '', 0, 'http://localhost/b2w/?post_type=testimonial&#038;p=124', 0, 'testimonial', '', 0),
(126, 1, '2019-04-05 05:11:22', '2019-04-05 05:11:22', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href=\"http://localhost/b2w/wp-admin/\">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'closed', 'closed', '', '2-revision-v1', '', '', '2019-04-05 05:11:22', '2019-04-05 05:11:22', '', 2, 'http://localhost/b2w/2-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(127, 1, '2019-04-05 05:11:35', '2019-04-05 05:11:35', '<p class=\"lead\">Welcome to the bootstrap resources page! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit hic non numquam vitae! Neque rem nam aspernatur repellendus quia est. <strong>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Totam, sapiente?</strong></p>\r\n<em>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi odio illo optio rerum eveniet perspiciatis consequatur provident! Inventore consequatur, et ratione perferendis deserunt laudantium praesentium?</em>', 'Resources', '', 'publish', 'closed', 'closed', '', 'resources', '', '', '2019-04-05 11:25:44', '2019-04-05 11:25:44', '', 0, 'http://localhost/b2w/?page_id=127', 0, 'page', '', 0),
(128, 1, '2019-04-05 05:11:35', '2019-04-05 05:11:35', '', 'Resources', '', 'inherit', 'closed', 'closed', '', '127-revision-v1', '', '', '2019-04-05 05:11:35', '2019-04-05 05:11:35', '', 127, 'http://localhost/b2w/127-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(129, 1, '2019-04-05 05:15:43', '2019-04-05 05:15:43', ' ', '', '', 'publish', 'closed', 'closed', '', '129', '', '', '2019-05-02 17:24:58', '2019-05-02 17:24:58', '', 0, 'http://localhost/b2w/?p=129', 2, 'nav_menu_item', '', 0),
(130, 1, '2019-04-05 11:22:57', '2019-04-05 11:22:57', '<p class=\"lead\">Welcome to the bootstrap resources page! Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sit hic non numquam vitae! Neque rem nam aspernatur repellendus quia est. <strong>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Totam, sapiente?</strong></p>\r\n<em>Lorem ipsum dolor sit amet consectetur adipisicing elit. Animi odio illo optio rerum eveniet perspiciatis consequatur provident! Inventore consequatur, et ratione perferendis deserunt laudantium praesentium?</em>', 'Resources', '', 'inherit', 'closed', 'closed', '', '127-revision-v1', '', '', '2019-04-05 11:22:57', '2019-04-05 11:22:57', '', 127, 'http://localhost/b2w/127-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(131, 1, '2019-04-05 17:50:24', '2019-04-05 17:50:24', 'a:7:{s:8:\"location\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"param\";s:9:\"post_type\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:8:\"resource\";}}}s:8:\"position\";s:6:\"normal\";s:5:\"style\";s:7:\"default\";s:15:\"label_placement\";s:4:\"left\";s:21:\"instruction_placement\";s:5:\"field\";s:14:\"hide_on_screen\";a:13:{i:0;s:9:\"permalink\";i:1;s:7:\"excerpt\";i:2;s:13:\"custom_fields\";i:3;s:10:\"discussion\";i:4;s:8:\"comments\";i:5;s:9:\"revisions\";i:6;s:4:\"slug\";i:7;s:6:\"author\";i:8;s:6:\"format\";i:9;s:15:\"page_attributes\";i:10;s:10:\"categories\";i:11;s:4:\"tags\";i:12;s:15:\"send-trackbacks\";}s:11:\"description\";s:0:\"\";}', 'Resources', 'resources', 'publish', 'closed', 'closed', '', 'group_5ca7935bad980', '', '', '2019-04-05 17:50:25', '2019-04-05 17:50:25', '', 0, 'http://localhost/b2w/?post_type=acf-field-group&#038;p=131', 0, 'acf-field-group', '', 0),
(132, 1, '2019-04-05 17:50:24', '2019-04-05 17:50:24', 'a:15:{s:4:\"type\";s:5:\"image\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"return_format\";s:5:\"array\";s:12:\"preview_size\";s:6:\"medium\";s:7:\"library\";s:3:\"all\";s:9:\"min_width\";s:0:\"\";s:10:\"min_height\";s:0:\"\";s:8:\"min_size\";s:0:\"\";s:9:\"max_width\";s:0:\"\";s:10:\"max_height\";s:0:\"\";s:8:\"max_size\";s:0:\"\";s:10:\"mime_types\";s:0:\"\";}', 'Resources Image', 'resources_image', 'publish', 'closed', 'closed', '', 'field_5ca7936ad0c89', '', '', '2019-04-05 17:50:24', '2019-04-05 17:50:24', '', 131, 'http://localhost/b2w/?post_type=acf-field&p=132', 0, 'acf-field', '', 0),
(133, 1, '2019-04-05 17:50:24', '2019-04-05 17:50:24', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Resources Url', 'resources_url', 'publish', 'closed', 'closed', '', 'field_5ca7938ed0c8a', '', '', '2019-04-05 17:50:24', '2019-04-05 17:50:24', '', 131, 'http://localhost/b2w/?post_type=acf-field&p=133', 1, 'acf-field', '', 0),
(134, 1, '2019-04-05 17:50:25', '2019-04-05 17:50:25', 'a:10:{s:4:\"type\";s:10:\"true_false\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:1;s:17:\"conditional_logic\";i:0;s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:7:\"message\";s:0:\"\";s:13:\"default_value\";i:1;s:2:\"ui\";i:0;s:10:\"ui_on_text\";s:0:\"\";s:11:\"ui_off_text\";s:0:\"\";}', 'Add Button ?', 'add_button', 'publish', 'closed', 'closed', '', 'field_5ca793d4d0c8b', '', '', '2019-04-05 17:50:25', '2019-04-05 17:50:25', '', 131, 'http://localhost/b2w/?post_type=acf-field&p=134', 2, 'acf-field', '', 0),
(135, 1, '2019-04-05 17:50:25', '2019-04-05 17:50:25', 'a:10:{s:4:\"type\";s:4:\"text\";s:12:\"instructions\";s:0:\"\";s:8:\"required\";i:0;s:17:\"conditional_logic\";a:1:{i:0;a:1:{i:0;a:3:{s:5:\"field\";s:19:\"field_5ca793d4d0c8b\";s:8:\"operator\";s:2:\"==\";s:5:\"value\";s:1:\"1\";}}}s:7:\"wrapper\";a:3:{s:5:\"width\";s:0:\"\";s:5:\"class\";s:0:\"\";s:2:\"id\";s:0:\"\";}s:13:\"default_value\";s:0:\"\";s:11:\"placeholder\";s:0:\"\";s:7:\"prepend\";s:0:\"\";s:6:\"append\";s:0:\"\";s:9:\"maxlength\";s:0:\"\";}', 'Button Text', 'button_text', 'publish', 'closed', 'closed', '', 'field_5ca79496d0c8c', '', '', '2019-04-05 17:50:25', '2019-04-05 17:50:25', '', 131, 'http://localhost/b2w/?post_type=acf-field&p=135', 3, 'acf-field', '', 0),
(136, 1, '2019-04-05 17:54:54', '2019-04-05 17:54:54', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. In possimus iure a quae cupiditate labore non alias excepturi fugit at molestiae laudantium reiciendis velit perferendis incidunt culpa reprehenderit cumque iusto, voluptatibus, dolorum ab odio voluptas! Aliquid autem fugiat corporis facere veritatis odio voluptate, dolorum atque reprehenderit dolores magni, delectus eum quis deserunt praesentium libero! Voluptas!\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus eum deleniti natus qui optio sit ex esse eaque iusto animi est quisquam provident facilis, velit doloremque?', 'Facebook', '', 'publish', 'closed', 'closed', '', 'facebook', '', '', '2019-04-05 17:54:54', '2019-04-05 17:54:54', '', 0, 'http://localhost/b2w/?post_type=resource&#038;p=136', 0, 'resource', '', 0),
(137, 1, '2019-04-05 17:56:18', '2019-04-05 17:56:18', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. In possimus iure a quae cupiditate labore non alias excepturi fugit at molestiae laudantium reiciendis velit perferendis incidunt culpa reprehenderit cumque iusto, voluptatibus, dolorum ab odio voluptas! Aliquid autem fugiat corporis facere veritatis odio voluptate, dolorum atque reprehenderit dolores magni, delectus eum quis deserunt praesentium libero! Voluptas!\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus eum deleniti natus qui optio sit ex esse eaque iusto animi est quisquam provident facilis, velit doloremque?', 'Google', '', 'publish', 'closed', 'closed', '', 'google', '', '', '2019-04-05 17:56:18', '2019-04-05 17:56:18', '', 0, 'http://localhost/b2w/?post_type=resource&#038;p=137', 0, 'resource', '', 0),
(138, 1, '2019-04-05 17:57:29', '2019-04-05 17:57:29', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. In possimus iure a quae cupiditate labore non alias excepturi fugit at molestiae laudantium reiciendis velit perferendis incidunt culpa reprehenderit cumque iusto, voluptatibus, dolorum ab odio voluptas! Aliquid autem fugiat corporis facere veritatis odio voluptate, dolorum atque reprehenderit dolores magni, delectus eum quis deserunt praesentium libero! Voluptas!\r\n\r\nLorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus eum deleniti natus qui optio sit ex esse eaque iusto animi est quisquam provident facilis, velit doloremque?', 'Youtube', '', 'publish', 'closed', 'closed', '', 'youtube', '', '', '2019-04-05 17:57:29', '2019-04-05 17:57:29', '', 0, 'http://localhost/b2w/?post_type=resource&#038;p=138', 0, 'resource', '', 0),
(140, 1, '2019-04-06 17:17:45', '2019-04-06 17:17:45', '', 'Blog', '', 'publish', 'closed', 'closed', '', 'blog', '', '', '2019-04-06 17:58:35', '2019-04-06 17:58:35', '', 0, 'http://localhost/b2w/?page_id=140', 0, 'page', '', 0),
(141, 1, '2019-04-06 17:17:45', '2019-04-06 17:17:45', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2019-04-06 17:17:45', '2019-04-06 17:17:45', '', 140, 'http://localhost/b2w/140-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(142, 1, '2019-04-06 17:18:03', '2019-04-06 17:18:03', ' ', '', '', 'publish', 'closed', 'closed', '', '142', '', '', '2019-05-02 17:24:58', '2019-05-02 17:24:58', '', 0, 'http://localhost/b2w/?p=142', 3, 'nav_menu_item', '', 0),
(143, 1, '2019-04-06 17:58:26', '2019-04-06 17:58:26', '', 'Blogs', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2019-04-06 17:58:26', '2019-04-06 17:58:26', '', 140, 'http://localhost/b2w/140-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(144, 1, '2019-04-06 17:58:35', '2019-04-06 17:58:35', '', 'Blog', '', 'inherit', 'closed', 'closed', '', '140-revision-v1', '', '', '2019-04-06 17:58:35', '2019-04-06 17:58:35', '', 140, 'http://localhost/b2w/140-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(145, 1, '2019-04-06 18:02:54', '2019-04-06 18:02:54', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!\r\n\r\n&nbsp;\r\n<h3 class=\"faqheader\">About this Lorem Ipsum generator</h3>\r\nYes, there are a lot of Lorem Ipsum generators already. Even when we started with this one in 2009. But all others lack features, or are too limited. Here\'s what Loripsum.net has to offer:\r\n<dl>\r\n 	<dt>API</dt>\r\n 	<dd>Loripsum.net has an API to generate placeholder text to insert it in whatever software/webapp you want. See below for details.</dd>\r\n 	<dt>Customization</dt>\r\n 	<dd>Most generators only output some paragraphs of about the same length. Sometimes you need lists, headings, long paragraphs, etc. The website/magazine that you\'re designing probably isn\'t going to be filled with happy uniform paragraphs, so your placeholder text should reflect that.</dd>\r\n 	<dt>Different text, all the time</dt>\r\n 	<dd>Most generators output the same results every time you request some text. Loripsum.net uses the full text of Cicero\'s \"De finibus bonorum et malorum\" to make sure you get a different placeholder text every single time.</dd>\r\n</dl>\r\n&nbsp;\r\n\r\n&nbsp;', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-04-06 18:02:54', '2019-04-06 18:02:54', '', 1, 'http://localhost/b2w/1-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(146, 1, '2019-04-06 18:41:27', '2019-04-06 18:41:27', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!\r\n<h3 class=\"faqheader\">About this Lorem Ipsum generator</h3>\r\nYes, there are a lot of Lorem Ipsum generators already. Even when we started with this one in 2009. But all others lack features, or are too limited. Here\'s what Loripsum.net has to offer:\r\n<dl>\r\n 	<dt>API</dt>\r\n 	<dd>Loripsum.net has an API to generate placeholder text to insert it in whatever software/webapp you want. See below for details.</dd>\r\n 	<dt>Customization</dt>\r\n 	<dd>Most generators only output some paragraphs of about the same length. Sometimes you need lists, headings, long paragraphs, etc. The website/magazine that you\'re designing probably isn\'t going to be filled with happy uniform paragraphs, so your placeholder text should reflect that.</dd>\r\n 	<dt>Different text, all the time</dt>\r\n 	<dd>Most generators output the same results every time you request some text. Loripsum.net uses the full text of Cicero\'s \"De finibus bonorum et malorum\" to make sure you get a different placeholder text every single time.</dd>\r\n</dl>\r\n&nbsp;\r\n\r\n&nbsp;', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-04-06 18:41:27', '2019-04-06 18:41:27', '', 1, 'http://localhost/b2w/1-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(147, 1, '2019-04-06 20:29:04', '2019-04-06 20:29:04', '<div>\r\n\r\n<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\r\n\r\n</div>\r\n<div>\r\n<h2>Why do we use it?</h2>\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n\r\n</div>\r\n&nbsp;\r\n<div>\r\n<h2>Where does it come from?</h2>\r\nContrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.\r\n\r\nThe standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.\r\n\r\n</div>\r\n<div>\r\n<h2>Where can I get some?</h2>\r\nThere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\r\n\r\n</div>', 'Another Post For Test', '', 'publish', 'open', 'open', '', 'another-post-for-test', '', '', '2019-04-06 20:33:03', '2019-04-06 20:33:03', '', 0, 'http://localhost/b2w/?p=147', 0, 'post', '', 0),
(148, 1, '2019-04-06 20:29:04', '2019-04-06 20:29:04', '<div>\r\n\r\n<strong>Lorem Ipsum</strong> is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.\r\n\r\n</div>\r\n<div>\r\n<h2>Why do we use it?</h2>\r\nIt is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).\r\n\r\n</div>\r\n&nbsp;\r\n<div>\r\n<h2>Where does it come from?</h2>\r\nContrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32.\r\n\r\nThe standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.\r\n\r\n</div>\r\n<div>\r\n<h2>Where can I get some?</h2>\r\nThere are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don\'t look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn\'t anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. The generated Lorem Ipsum is therefore always free from repetition, injected humour, or non-characteristic words etc.\r\n\r\n</div>', 'Another Post For Test', '', 'inherit', 'closed', 'closed', '', '147-revision-v1', '', '', '2019-04-06 20:29:04', '2019-04-06 20:29:04', '', 147, 'http://localhost/b2w/147-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(149, 1, '2019-04-07 17:10:45', '2019-04-07 17:10:45', '<h3 class=\"faqheader\">About this Lorem Ipsum generator</h3>\r\nYes, there are a lot of Lorem Ipsum generators already. Even when we started with this one in 2009. But all others lack features, or are too limited. Here\'s what Loripsum.net has to offer:\r\n<dl>\r\n 	<dt>API</dt>\r\n 	<dd>Loripsum.net has an API to generate placeholder text to insert it in whatever software/webapp you want. See below for details.</dd>\r\n 	<dt>Customization</dt>\r\n 	<dd>Most generators only output some paragraphs of about the same length. Sometimes you need lists, headings, long paragraphs, etc. The website/magazine that you\'re designing probably isn\'t going to be filled with happy uniform paragraphs, so your placeholder text should reflect that.</dd>\r\n 	<dt>Different text, all the time</dt>\r\n 	<dd>Most generators output the same results every time you request some text. Loripsum.net uses the full text of Cicero\'s \"De finibus bonorum et malorum\" to make sure you get a different placeholder text every single time.</dd>\r\n</dl>\r\n&nbsp;\r\n\r\n&nbsp;', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-04-07 17:10:45', '2019-04-07 17:10:45', '', 1, 'http://localhost/b2w/1-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(150, 1, '2019-04-07 18:09:38', '2019-04-07 18:09:38', '<h3 class=\"faqheader\">About this Lorem Ipsum generator</h3>\r\nYes, there are a lot of Lorem Ipsum generators already. Even when we started with this one in 2009. But all others lack features, or are too limited. Here\'s what Loripsum.net has to offer:\r\n<dl>\r\n 	<dt>API</dt>\r\n 	<dd>Loripsum.net has an API to generate placeholder text to insert it in whatever software/webapp you want. See below for details.</dd>\r\n 	<dt>Customization</dt>\r\n 	<dd>Most generators only output some paragraphs of about the same length. Sometimes you need lists, headings, long paragraphs, etc. The website/magazine that you\'re designing probably isn\'t going to be filled with happy uniform paragraphs, so your placeholder text should reflect that.</dd>\r\n 	<dt>Different text, all the time</dt>\r\n 	<dd>Most generators output the same results every time you request some text. Loripsum.net uses the full text of Cicero\'s \"De finibus bonorum et malorum\" to make sure you get a different placeholder text every single time.</dd>\r\n</dl>', 'Hello world!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2019-04-07 18:09:38', '2019-04-07 18:09:38', '', 1, 'http://localhost/b2w/1-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(151, 1, '2019-04-10 18:18:56', '2019-04-10 18:18:56', '<p class=\"lead\">Have any <strong>question ?</strong> <em>Fell free to get in touch with me.</em></p>\r\n[contact-form-7 id=\"160\" title=\"Primary Contact Form\"]', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2019-04-18 19:45:06', '2019-04-18 19:45:06', '', 0, 'http://localhost/b2w/?page_id=151', 0, 'page', '', 0),
(152, 1, '2019-04-10 18:18:56', '2019-04-10 18:18:56', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '151-revision-v1', '', '', '2019-04-10 18:18:56', '2019-04-10 18:18:56', '', 151, 'http://localhost/b2w/151-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(153, 1, '2019-04-10 18:19:28', '2019-04-10 18:19:28', ' ', '', '', 'publish', 'closed', 'closed', '', '153', '', '', '2019-05-02 17:24:58', '2019-05-02 17:24:58', '', 0, 'http://localhost/b2w/?p=153', 4, 'nav_menu_item', '', 0),
(154, 1, '2019-04-10 18:37:37', '2019-04-10 18:37:37', '<p class=\"lead\">Have any <strong>question ?</strong> <em>Fell free to get in touch with me.</em></p>', 'Contact', '', 'inherit', 'closed', 'closed', '', '151-revision-v1', '', '', '2019-04-10 18:37:37', '2019-04-10 18:37:37', '', 151, 'http://localhost/b2w/151-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(156, 1, '2019-04-16 17:20:02', '2019-04-16 17:20:02', '<label> Your Name (required)\n    [text* your-name] </label>\n\n<label> Your Email (required)\n    [email* your-email] </label>\n\n<label> Subject\n    [text your-subject] </label>\n\n<label> Your Message\n    [textarea your-message] </label>\n\n[submit \"Send\"]\nBootstrap 2 Wordpress \"[your-subject]\"\nBootstrap 2 Wordpress <mehedi00014@gmail.com>\nFrom: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Bootstrap 2 Wordpress (http://localhost/b2w)\nmehedi00014@gmail.com\nReply-To: [your-email]\n\n0\n0\n\nBootstrap 2 Wordpress \"[your-subject]\"\nBootstrap 2 Wordpress <mehedi00014@gmail.com>\nMessage Body:\n[your-message]\n\n-- \nThis e-mail was sent from a contact form on Bootstrap 2 Wordpress (http://localhost/b2w)\n[your-email]\nReply-To: mehedi00014@gmail.com\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2019-04-16 17:20:02', '2019-04-16 17:20:02', '', 0, 'http://localhost/b2w/?post_type=wpcf7_contact_form&p=156', 0, 'wpcf7_contact_form', '', 0),
(158, 1, '2019-04-16 17:51:02', '2019-04-16 17:51:02', '<p class=\"lead\">Have any <strong>question ?</strong> <em>Fell free to get in touch with me.</em></p>\r\n[contact-form-7 id=\"157\" title=\"Primary Contact Form\"]', 'Contact', '', 'inherit', 'closed', 'closed', '', '151-revision-v1', '', '', '2019-04-16 17:51:02', '2019-04-16 17:51:02', '', 151, 'http://localhost/b2w/151-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(159, 1, '2019-04-18 18:55:53', '2019-04-18 18:55:53', '<p class=\"lead\">Have any <strong>question ?</strong> <em>Fell free to get in touch with me.</em></p>', 'Contact', '', 'inherit', 'closed', 'closed', '', '151-revision-v1', '', '', '2019-04-18 18:55:53', '2019-04-18 18:55:53', '', 151, 'http://localhost/b2w/151-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(160, 1, '2019-04-18 19:08:43', '2019-04-18 19:08:43', '<form action=\"\" class=\"clearfix\">\r\n            <div class=\"row\">\r\n              <div class=\"col-sm-6\">\r\n                <div class=\"form-group\">\r\n                  <label for=\"contact-name\" class=\"sr-only\">Name</label>\r\n                  [text* text-630 id:contact-name class:form-control class:input-lg placeholder \"Your name\"]\r\n                </div> <!-- form-group -->\r\n              </div> <!-- col-sm-6 -->\r\n              <div class=\"col-sm-6\">\r\n                <div class=\"form-group\">\r\n                  <label for=\"contact-email\" class=\"sr-only\">Email</label>\r\n                  [email* your-email email-687 id:contact-email class:form-control class:input-lg placeholder \"Your email\"]\r\n                </div> <!-- form-group -->\r\n              </div> <!-- col-sm-6 -->\r\n              <div class=\"col-sm-12\">\r\n                <div class=\"form-group\">\r\n                  <label for=\"contact-words\" class=\"sr-only\">Message</label>\r\n                  [textarea* textarea-603 id:contact-words class:from-control class:input-lg placeholder \"&quot;Your message\"]\r\n                </div> <!-- form-group -->\r\n              </div> <!-- col-sm-12 -->\r\n            </div> <!-- row -->\r\n            [submit class:btn class:btn-info class:btn-lg class:float-right \"Get in touch &raquo;\"]\r\n          </form> <!-- clearfix -->\n1\nBootstrap 2 Wordpress \"[your-subject]\"\nBootstrap 2 Wordpress <mehedi00014@gmail.com>\nmehedi00014@gmail.com\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Bootstrap 2 Wordpress (http://localhost/b2w)\nReply-To: [your-email]\n\n\n\n\nBootstrap 2 Wordpress \"[your-subject]\"\nBootstrap 2 Wordpress <mehedi00014@gmail.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis e-mail was sent from a contact form on Bootstrap 2 Wordpress (http://localhost/b2w)\nReply-To: mehedi00014@gmail.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Primary Contact Form', '', 'publish', 'closed', 'closed', '', 'untitled', '', '', '2019-04-18 19:34:22', '2019-04-18 19:34:22', '', 0, 'http://localhost/b2w/?post_type=wpcf7_contact_form&#038;p=160', 0, 'wpcf7_contact_form', '', 0),
(161, 1, '2019-04-18 19:10:01', '2019-04-18 19:10:01', '<p class=\"lead\">Have any <strong>question ?</strong> <em>Fell free to get in touch with me.</em></p>\r\n[contact-form-7 id=\"160\" title=\"Untitled\"]', 'Contact', '', 'inherit', 'closed', 'closed', '', '151-revision-v1', '', '', '2019-04-18 19:10:01', '2019-04-18 19:10:01', '', 151, 'http://localhost/b2w/151-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(162, 1, '2019-04-18 19:39:22', '2019-04-18 19:39:22', '<p class=\"lead\">Have any <strong>question ?</strong> <em>Fell free to get in touch with me.</em></p>\r\n[contact-form-7 id=\"156\" title=\"Contact form 1\"]', 'Contact', '', 'inherit', 'closed', 'closed', '', '151-revision-v1', '', '', '2019-04-18 19:39:22', '2019-04-18 19:39:22', '', 151, 'http://localhost/b2w/151-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(163, 1, '2019-04-18 19:45:06', '2019-04-18 19:45:06', '<p class=\"lead\">Have any <strong>question ?</strong> <em>Fell free to get in touch with me.</em></p>\r\n[contact-form-7 id=\"160\" title=\"Primary Contact Form\"]', 'Contact', '', 'inherit', 'closed', 'closed', '', '151-revision-v1', '', '', '2019-04-18 19:45:06', '2019-04-18 19:45:06', '', 151, 'http://localhost/b2w/151-revision-v1/uncategorized/2019/04/', 0, 'revision', '', 0),
(164, 1, '2019-04-18 20:56:11', '2019-04-18 20:56:11', '{\n    \"sidebars_widgets[sidebar-1]\": {\n        \"value\": [\n            \"text-3\",\n            \"archives-2\",\n            \"search-2\",\n            \"recent-posts-2\",\n            \"recent-comments-2\",\n            \"categories-2\",\n            \"meta-2\"\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-18 20:54:58\"\n    },\n    \"widget_text[3]\": {\n        \"value\": {\n            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjE4OiJKb2luIG91ciBtYWlsIGxpc3QiO3M6NDoidGV4dCI7czozMTI6IjxkaXY+DQo8ZGl2PiZsdDtwJmd0O0tlZXAgdXAgdG8gZGF0ZSB3aXRoIG91ciBsZXRlc3QgbmV3cywgYW5kIHdlIHdpbGwgJmx0O3N0cm9uZyZndDtzZW50IHlvdSBzb21ldGhpbmcgc3BlY2lzbCBhcyBhIHRoYW5rIHlvdSEmbHQ7L3N0cm9uZyZndDsmbHQ7L3AmZ3Q7PC9kaXY+DQo8ZGl2PiZsdDtidXR0b25jbGFzcz0iYnRuIGJ0bi1zdWNjZXNzIGJ0bi1sZyBidG4tYmxvY2siZGF0YS10b2dnbGU9Im1vZGFsImRhdGEtdGFyZ2V0PSIjbXlNb2RhbCImZ3Q7Q2xpY2sgaGVyZSB0byBTdWJzY3JpYmUmbHQ7L2J1dHRvbiZndDs8L2Rpdj4NCjwvZGl2PiI7czo2OiJmaWx0ZXIiO2I6MTtzOjY6InZpc3VhbCI7YjoxO30=\",\n            \"title\": \"Join our mail list\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"a197e8a41fc2d77a75ca8496bf4a35f6\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-18 20:56:11\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '026169fa-359b-43d5-9e10-cd7c5f4d19a3', '', '', '2019-04-18 20:56:11', '2019-04-18 20:56:11', '', 0, 'http://localhost/b2w/?p=164', 0, 'customize_changeset', '', 0),
(165, 1, '2019-04-18 21:03:45', '2019-04-18 21:03:45', '{\n    \"sidebars_widgets[sidebar-1]\": {\n        \"value\": [\n            \"text-4\",\n            \"search-2\",\n            \"recent-posts-2\",\n            \"categories-2\",\n            \"text-6\"\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-18 21:02:24\"\n    },\n    \"widget_text[6]\": {\n        \"value\": {\n            \"encoded_serialized_instance\": \"YTo0OntzOjU6InRpdGxlIjtzOjI4OiJBYm91dCBCb290c3RyYXAgdG8gV29yZHByZXNzIjtzOjQ6InRleHQiO3M6MTU2OiJMb3JlbSBpcHN1bSBkb2xvciBzaXQgYW1ldCBjb25zZWN0ZXR1ciBhZGlwaXNpY2luZyBlbGl0LiBDdW0gdm9sdXB0YXRlIGN1cGlkaXRhdGUgb2RpbyBxdWFzIGFzcGVyaW9yZXMgdmVsIHF1YWVyYXQgcmVwcmVoZW5kZXJpdCBwcm92aWRlbnQgbWludXMgdm9sdXB0YXR1bS4iO3M6NjoiZmlsdGVyIjtiOjE7czo2OiJ2aXN1YWwiO2I6MTt9\",\n            \"title\": \"About Bootstrap to Wordpress\",\n            \"is_widget_customizer_js_value\": true,\n            \"instance_hash_key\": \"20adda5220c0fb4d6b1f5388a9cdc33b\"\n        },\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-18 21:03:41\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '7d260e39-65f4-4dca-84f0-c7638912e775', '', '', '2019-04-18 21:03:45', '2019-04-18 21:03:45', '', 0, 'http://localhost/b2w/?p=165', 0, 'customize_changeset', '', 0),
(166, 1, '2019-04-18 21:04:19', '2019-04-18 21:04:19', '{\n    \"sidebars_widgets[sidebar-1]\": {\n        \"value\": [\n            \"text-4\",\n            \"search-2\",\n            \"text-6\",\n            \"recent-posts-2\",\n            \"categories-2\"\n        ],\n        \"type\": \"option\",\n        \"user_id\": 1,\n        \"date_modified_gmt\": \"2019-04-18 21:04:15\"\n    }\n}', '', '', 'trash', 'closed', 'closed', '', '7f06bcd2-2ba2-4a5c-8c53-fa8a680352fb', '', '', '2019-04-18 21:04:19', '2019-04-18 21:04:19', '', 0, 'http://localhost/b2w/?p=166', 0, 'customize_changeset', '', 0),
(167, 1, '2019-05-02 17:09:48', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2019-05-02 17:09:48', '0000-00-00 00:00:00', '', 0, 'http://localhost/b2w/?p=167', 0, 'post', '', 0),
(168, 1, '2019-05-02 17:24:00', '2019-05-02 17:24:00', ' ', '', '', 'publish', 'closed', 'closed', '', '168', '', '', '2019-05-02 18:41:52', '2019-05-02 18:41:52', '', 0, 'http://localhost/b2w/?p=168', 4, 'nav_menu_item', '', 0),
(169, 1, '2019-05-02 17:24:00', '2019-05-02 17:24:00', ' ', '', '', 'publish', 'closed', 'closed', '', '169', '', '', '2019-05-02 18:41:51', '2019-05-02 18:41:51', '', 0, 'http://localhost/b2w/?p=169', 3, 'nav_menu_item', '', 0),
(170, 1, '2019-05-02 17:24:00', '2019-05-02 17:24:00', ' ', '', '', 'publish', 'closed', 'closed', '', '170', '', '', '2019-05-02 18:41:51', '2019-05-02 18:41:51', '', 0, 'http://localhost/b2w/?p=170', 2, 'nav_menu_item', '', 0),
(171, 1, '2019-05-02 17:23:59', '2019-05-02 17:23:59', ' ', '', '', 'publish', 'closed', 'closed', '', '171', '', '', '2019-05-02 18:41:51', '2019-05-02 18:41:51', '', 0, 'http://localhost/b2w/?p=171', 1, 'nav_menu_item', '', 0),
(172, 1, '2019-05-02 17:24:01', '2019-05-02 17:24:01', '', 'Sign up now!', '', 'publish', 'closed', 'closed', '', 'sign-up-now', '', '', '2019-05-02 18:41:52', '2019-05-02 18:41:52', '', 0, 'http://localhost/b2w/?p=172', 5, 'nav_menu_item', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_termmeta`
--

CREATE TABLE `bs2wp_termmeta` (
  `meta_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_terms`
--

CREATE TABLE `bs2wp_terms` (
  `term_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bs2wp_terms`
--

INSERT INTO `bs2wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Custom Primary Menu', 'custom-primary-menu', 0),
(3, 'Test_tag', 'test_tag', 0),
(4, 'Custom Footer Menu', 'custom-footer-menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_term_relationships`
--

CREATE TABLE `bs2wp_term_relationships` (
  `object_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bs2wp_term_relationships`
--

INSERT INTO `bs2wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(1, 3, 0),
(13, 2, 0),
(129, 2, 0),
(142, 2, 0),
(147, 1, 0),
(153, 2, 0),
(168, 4, 0),
(169, 4, 0),
(170, 4, 0),
(171, 4, 0),
(172, 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_term_taxonomy`
--

CREATE TABLE `bs2wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL,
  `term_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bs2wp_term_taxonomy`
--

INSERT INTO `bs2wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', 'Its Just test the uncategorized description', 0, 2),
(2, 2, 'nav_menu', '', 0, 4),
(3, 3, 'post_tag', '', 0, 1),
(4, 4, 'nav_menu', '', 0, 5);

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_usermeta`
--

CREATE TABLE `bs2wp_usermeta` (
  `umeta_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bs2wp_usermeta`
--

INSERT INTO `bs2wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', 'Md. Mehedi'),
(3, 1, 'last_name', 'Hassan'),
(4, 1, 'description', 'I like to think simply'),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'bs2wp_capabilities', 'a:1:{s:13:\"administrator\";b:1;}'),
(13, 1, 'bs2wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', 'wp496_privacy,text_widget_custom_html'),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:\"34d76710eac237bf620b8833b3403eafc45eddc33fc1b549c8c884449fa64c9a\";a:4:{s:10:\"expiration\";i:1558026585;s:2:\"ip\";s:3:\"::1\";s:2:\"ua\";s:78:\"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:67.0) Gecko/20100101 Firefox/67.0\";s:5:\"login\";i:1556816985;}}'),
(17, 1, 'bs2wp_dashboard_quick_press_last_post_id', '167'),
(18, 1, 'closedpostboxes_dashboard', 'a:0:{}'),
(19, 1, 'metaboxhidden_dashboard', 'a:3:{i:0;s:18:\"dashboard_activity\";i:1;s:21:\"dashboard_quick_press\";i:2;s:17:\"dashboard_primary\";}'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:\"link-target\";i:1;s:15:\"title-attribute\";i:2;s:11:\"css-classes\";i:3;s:3:\"xfn\";i:4;s:11:\"description\";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:\"add-post_tag\";}'),
(22, 1, 'nav_menu_recently_edited', '4'),
(23, 1, 'closedpostboxes_page', 'a:0:{}'),
(24, 1, 'metaboxhidden_page', 'a:5:{i:0;s:10:\"postcustom\";i:1;s:16:\"commentstatusdiv\";i:2;s:11:\"commentsdiv\";i:3;s:7:\"slugdiv\";i:4;s:9:\"authordiv\";}'),
(25, 1, 'meta-box-order_page', 'a:4:{s:15:\"acf_after_title\";s:0:\"\";s:4:\"side\";s:36:\"submitdiv,pageparentdiv,postimagediv\";s:6:\"normal\";s:238:\"acf-group_5c9d0dcd70250,acf-group_5ca2541ae9049,acf-group_5ca4e1e0dcf32,postcustom,acf-group_5ca5025e15182,acf-group_5ca644aeee313,acf-group_5ca6497c7d794,acf-group_5ca65b085c276,commentstatusdiv,commentsdiv,slugdiv,authordiv,revisionsdiv\";s:8:\"advanced\";s:0:\"\";}'),
(26, 1, 'screen_layout_page', '2'),
(27, 1, 'bs2wp_user-settings', 'editor_expand=on&libraryContent=browse&editor=html&post_dfw=off'),
(28, 1, 'bs2wp_user-settings-time', '1555620999'),
(29, 1, 'wpcf7_hide_welcome_panel_on', 'a:1:{i:0;s:3:\"5.1\";}');

-- --------------------------------------------------------

--
-- Table structure for table `bs2wp_users`
--

CREATE TABLE `bs2wp_users` (
  `ID` bigint(20) UNSIGNED NOT NULL,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bs2wp_users`
--

INSERT INTO `bs2wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BF0R1DoWYG4m/27n7wuVLA.mpmtwd21', 'admin', 'mehedi00014@gmail.com', '', '2019-03-20 17:21:30', '', 0, 'Md. Mehedi Hassan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bs2wp_commentmeta`
--
ALTER TABLE `bs2wp_commentmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `comment_id` (`comment_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `bs2wp_comments`
--
ALTER TABLE `bs2wp_comments`
  ADD PRIMARY KEY (`comment_ID`),
  ADD KEY `comment_post_ID` (`comment_post_ID`),
  ADD KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  ADD KEY `comment_date_gmt` (`comment_date_gmt`),
  ADD KEY `comment_parent` (`comment_parent`),
  ADD KEY `comment_author_email` (`comment_author_email`(10));

--
-- Indexes for table `bs2wp_links`
--
ALTER TABLE `bs2wp_links`
  ADD PRIMARY KEY (`link_id`),
  ADD KEY `link_visible` (`link_visible`);

--
-- Indexes for table `bs2wp_options`
--
ALTER TABLE `bs2wp_options`
  ADD PRIMARY KEY (`option_id`),
  ADD UNIQUE KEY `option_name` (`option_name`);

--
-- Indexes for table `bs2wp_postmeta`
--
ALTER TABLE `bs2wp_postmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `bs2wp_posts`
--
ALTER TABLE `bs2wp_posts`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `post_name` (`post_name`(191)),
  ADD KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  ADD KEY `post_parent` (`post_parent`),
  ADD KEY `post_author` (`post_author`);

--
-- Indexes for table `bs2wp_termmeta`
--
ALTER TABLE `bs2wp_termmeta`
  ADD PRIMARY KEY (`meta_id`),
  ADD KEY `term_id` (`term_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `bs2wp_terms`
--
ALTER TABLE `bs2wp_terms`
  ADD PRIMARY KEY (`term_id`),
  ADD KEY `slug` (`slug`(191)),
  ADD KEY `name` (`name`(191));

--
-- Indexes for table `bs2wp_term_relationships`
--
ALTER TABLE `bs2wp_term_relationships`
  ADD PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  ADD KEY `term_taxonomy_id` (`term_taxonomy_id`);

--
-- Indexes for table `bs2wp_term_taxonomy`
--
ALTER TABLE `bs2wp_term_taxonomy`
  ADD PRIMARY KEY (`term_taxonomy_id`),
  ADD UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  ADD KEY `taxonomy` (`taxonomy`);

--
-- Indexes for table `bs2wp_usermeta`
--
ALTER TABLE `bs2wp_usermeta`
  ADD PRIMARY KEY (`umeta_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `meta_key` (`meta_key`(191));

--
-- Indexes for table `bs2wp_users`
--
ALTER TABLE `bs2wp_users`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `user_login_key` (`user_login`),
  ADD KEY `user_nicename` (`user_nicename`),
  ADD KEY `user_email` (`user_email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bs2wp_commentmeta`
--
ALTER TABLE `bs2wp_commentmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bs2wp_comments`
--
ALTER TABLE `bs2wp_comments`
  MODIFY `comment_ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bs2wp_links`
--
ALTER TABLE `bs2wp_links`
  MODIFY `link_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bs2wp_options`
--
ALTER TABLE `bs2wp_options`
  MODIFY `option_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=472;

--
-- AUTO_INCREMENT for table `bs2wp_postmeta`
--
ALTER TABLE `bs2wp_postmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=687;

--
-- AUTO_INCREMENT for table `bs2wp_posts`
--
ALTER TABLE `bs2wp_posts`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=173;

--
-- AUTO_INCREMENT for table `bs2wp_termmeta`
--
ALTER TABLE `bs2wp_termmeta`
  MODIFY `meta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bs2wp_terms`
--
ALTER TABLE `bs2wp_terms`
  MODIFY `term_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bs2wp_term_taxonomy`
--
ALTER TABLE `bs2wp_term_taxonomy`
  MODIFY `term_taxonomy_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `bs2wp_usermeta`
--
ALTER TABLE `bs2wp_usermeta`
  MODIFY `umeta_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `bs2wp_users`
--
ALTER TABLE `bs2wp_users`
  MODIFY `ID` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
